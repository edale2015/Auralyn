
import express from "express";
import unifiedRoutes from "./routes/unifiedRoutes";

const app = express();
app.use(express.json());

app.use("/api", unifiedRoutes);

app.get("/health", (_, res) => res.send("OK"));

app.listen(3000, () => console.log("Server running on 3000"));
