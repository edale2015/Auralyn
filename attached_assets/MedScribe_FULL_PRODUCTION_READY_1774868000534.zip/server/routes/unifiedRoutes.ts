
import express from "express";
import { runAutonomousPipeline } from "../system/runAutonomousPipeline";

const router = express.Router();

router.post("/run", async (req,res)=>{
  const result = await runAutonomousPipeline(req.body);
  res.json(result);
});

router.get("/control-tower",(req,res)=>{
  res.json({
    status:"ok",
    uptime:process.uptime()
  });
});

router.get("/executive",(req,res)=>{
  res.json({
    system:"MedScribe AI",
    status:"operational"
  });
});

export default router;
