
FULL PRODUCTION READY MEDSCRIBE SYSTEM

Run:
npm install
npm run start

Endpoint:
POST /api/run
