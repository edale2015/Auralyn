# MedScribe additions since Phase 6

This bundle contains only the new additions:
- phase6 control tower feed
- autonomous pipeline wrapper
- unified API route
- executive route
- integration instructions for existing `server/index.ts`

## What to copy into your repo
Copy these files into the matching locations.

## Then patch `server/index.ts`
Add these imports:
```ts
import unifiedRoutes from "./routes/unifiedRoutes.js";
import controlTowerRoutes from "./routes/controlTowerRoutes.js";
import executiveRoutes from "./routes/executiveRoutes.js";
```

Add these route registrations:
```ts
app.use("/api", unifiedRoutes);
app.use("/api", controlTowerRoutes);
app.use("/api", executiveRoutes);
```

## New endpoints
- `POST /api/run`
- `GET /api/control-tower`
- `GET /api/executive`
