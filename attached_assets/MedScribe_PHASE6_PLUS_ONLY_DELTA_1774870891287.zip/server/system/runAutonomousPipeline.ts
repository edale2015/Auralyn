import crypto from "node:crypto";
import { runFullClinicalFlow } from "./runFullClinicalFlow.js";

export async function runAutonomousPipeline(ctx: any) {
  const startedAt = Date.now();

  try {
    const result = await runFullClinicalFlow(ctx?.input ?? ctx);

    return {
      ...result,
      _meta: {
        pipeline: "autonomous",
        requestId: crypto.randomUUID(),
        durationMs: Date.now() - startedAt,
        timestamp: Date.now()
      }
    };
  } catch (error) {
    const err = error as Error;

    return {
      error: "pipeline_failed",
      message: err.message,
      _meta: {
        pipeline: "autonomous",
        failed: true,
        timestamp: Date.now()
      }
    };
  }
}
