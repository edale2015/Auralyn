import { Router } from "express";

const router = Router();

router.get("/executive", (_req, res) => {
  res.json({
    system: "Med-Scribe AI",
    status: "operational",
    uptime: process.uptime(),
    timestamp: Date.now()
  });
});

export default router;
