import { Router } from "express";
import { runAutonomousPipeline } from "../system/runAutonomousPipeline.js";

const router = Router();

router.post("/run", async (req, res) => {
  const result = await runAutonomousPipeline(req.body);
  res.json(result);
});

export default router;
