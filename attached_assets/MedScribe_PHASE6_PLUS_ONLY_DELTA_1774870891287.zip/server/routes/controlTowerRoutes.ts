import { Router } from "express";
import { getControlTowerData } from "../phase6/controlTower/controlTowerFeed.js";

const router = Router();

router.get("/control-tower", (_req, res) => {
  res.json(getControlTowerData());
});

export default router;
