
FULL PRODUCTION SYSTEM

Includes:
- NEWS2 scoring
- Predictive sepsis
- Risk ranking
- ICU allocation
- Autonomous interventions
- RLHF learning stats
- Digital twin load simulation
- WebSocket Control Tower UI
- FHIR stub

RUN:
npm install
npm run dev

Open frontend/index.html
