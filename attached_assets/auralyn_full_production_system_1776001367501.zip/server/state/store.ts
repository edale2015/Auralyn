
let patients:any[] = [];

export function addPatient(p:any){ patients.push(p); }
export function getPatients(){ return patients; }
