
import {calculateNEWS2} from "./engines/news2";
import {calcTrend} from "./engines/trend";
import {predictiveRisk} from "./engines/predictive";
import {rank} from "./engines/ranking";
import {allocate} from "./engines/icu";
import {interventions} from "./engines/intervention";
import {addPatient,getPatients} from "./state/store";
import {simulateLoad} from "./sim/digitalTwin";

export function run(p:any){

  const score = calculateNEWS2(p);
  const trend = calcTrend(p.prevScore||0,score);

  let enriched = {...p,score,trend};

  enriched.risk = predictiveRisk(enriched);

  addPatient(enriched);

  const all = getPatients();
  const ranked = rank(all);
  const icu = allocate(all,5);
  const load = simulateLoad(all);

  const acts = interventions(enriched);

  return {
    patient: enriched,
    ranked,
    icu,
    load,
    actions: acts
  };
}
