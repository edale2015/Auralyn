
export function writeFHIR(p:any){
  console.log("FHIR WRITE:",p);
}
