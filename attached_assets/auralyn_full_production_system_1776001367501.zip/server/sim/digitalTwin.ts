
export function simulateLoad(patients:any[]){
  return {
    ICU: patients.filter(p=>p.risk>=5).length,
    floor: patients.length
  };
}
