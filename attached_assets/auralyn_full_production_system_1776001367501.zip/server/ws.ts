
import { WebSocketServer } from "ws";

export const wss = new WebSocketServer({port:4001});

export function broadcast(data:any){
  wss.clients.forEach(c=>{
    if(c.readyState===1){
      c.send(JSON.stringify(data));
    }
  });
}
