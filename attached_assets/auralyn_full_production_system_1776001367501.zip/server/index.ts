
import express from "express";
import {run} from "./orchestrator";
import {broadcast} from "./ws";
import {getStats} from "./learning/rlhf";

const app = express();
app.use(express.json());

app.post("/triage",(req,res)=>{
  const result = run(req.body);
  broadcast(result);
  res.json(result);
});

app.get("/stats",(req,res)=>{
  res.json(getStats());
});

app.listen(3000,()=>console.log("Running 3000"));
