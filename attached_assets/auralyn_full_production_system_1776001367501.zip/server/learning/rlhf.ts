
let logs:any[]=[];

export function logOutcome(pred:any,actual:any){
  logs.push({pred,actual,correct:pred===actual});
}

export function getStats(){
  const total=logs.length;
  const correct=logs.filter(l=>l.correct).length;
  return {total,accuracy: total?correct/total:0};
}
