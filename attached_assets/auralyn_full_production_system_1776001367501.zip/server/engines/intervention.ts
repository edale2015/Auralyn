
export function interventions(p:any){
  const acts=[];
  if(p.risk>=5){
    acts.push("IV fluids");
    acts.push("Lactate");
    acts.push("Broad antibiotics");
  }
  if(p.score>=6){
    acts.push("Call ICU");
  }
  return acts;
}
