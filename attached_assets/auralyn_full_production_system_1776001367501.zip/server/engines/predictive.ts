
export function predictiveRisk(p:any){
  let r=0;
  if(p.trend>2) r+=2;
  if(p.lactate && p.lactate>2) r+=3;
  if(p.hr>120) r+=1;
  return r;
}
