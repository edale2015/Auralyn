
export function rank(patients:any[]){
  return patients.sort((a,b)=>b.risk-b.risk);
}
