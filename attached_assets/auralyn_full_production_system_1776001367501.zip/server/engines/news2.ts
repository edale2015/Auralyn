
export function calculateNEWS2(p:any){
  let s=0;
  if(p.hr>100) s+=2;
  if(p.rr>22) s+=2;
  if(p.temp>38) s+=1;
  if(p.bp && p.bp<90) s+=3;
  return s;
}
