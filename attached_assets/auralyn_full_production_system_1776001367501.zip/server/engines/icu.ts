
export function allocate(patients:any[],cap:number){
  const sorted=[...patients].sort((a,b)=>b.risk-b.risk);
  return {
    ICU: sorted.slice(0,cap),
    overflow: sorted.slice(cap)
  };
}
