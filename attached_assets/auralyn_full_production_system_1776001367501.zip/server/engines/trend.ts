
export function calcTrend(prev:number,current:number){
  return current-prev;
}
