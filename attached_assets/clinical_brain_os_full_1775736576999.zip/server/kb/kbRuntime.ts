
let cache:any = {
  redFlags: [],
  priors: [],
  treatments: []
};

export function getKbCache() {
  return cache;
}

export async function reloadKbCache() {
  cache = {
    redFlags: [],
    priors: [],
    treatments: []
  };
}
