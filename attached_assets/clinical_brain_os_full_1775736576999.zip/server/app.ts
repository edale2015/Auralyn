
import express from "express";
import http from "http";
import telemedRoutes from "./telemedicine/telemedicineAssistantRoutes";

const app = express();
app.use(express.json());

app.use("/api/telemedicine", telemedRoutes);

app.get("/health", (_, res) => res.json({status:"ok"}));

const server = http.createServer(app);

server.listen(3000, () => {
  console.log("🧠 Clinical Brain OS running on 3000");
});
