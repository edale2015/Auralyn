
import { Router } from "express";
import { runTelemedicineAssistant } from "./telemedicineAssistantService";

const router = Router();

router.post("/assistant", async (req, res) => {
  const result = await runTelemedicineAssistant(req.body);
  res.json(result);
});

export default router;
