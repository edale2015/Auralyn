
# Clinical Brain OS (Integrated)

Run:
npm install
npm start
