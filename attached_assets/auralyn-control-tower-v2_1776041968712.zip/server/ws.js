
const { Server } = require("ws");
const db = require("./db");

function init(server) {
  const wss = new Server({ server });
  wss.on("connection", ws => {
    setInterval(async () => {
      const r = await db("SELECT * FROM reasoning_queries ORDER BY created_at DESC LIMIT 5");
      ws.send(JSON.stringify(r.rows));
    }, 2000);
  });
}
module.exports = init;
