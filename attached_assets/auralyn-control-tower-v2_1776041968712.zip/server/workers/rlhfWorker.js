
const { Worker } = require("bullmq");
const { connection } = require("../queue");
const db = require("../db");

new Worker("rlhf", async job => {
  const { failure } = job.data;
  await db("INSERT INTO rlhf_updates(feature,adjustment,reason) VALUES($1,$2,$3)",
    [failure.feature, 0.01, "auto"]);
}, { connection });
