
const { Worker } = require("bullmq");
const { connection } = require("../queue");
const db = require("../db");

new Worker("golden-cases", async job => {
  const { node } = job.data;
  await db("INSERT INTO golden_cases(complaint,input,expected_output,severity) VALUES($1,$2,$3,$4)",
    [node.title, "Auto case", "Expected", "low"]);
}, { connection });
