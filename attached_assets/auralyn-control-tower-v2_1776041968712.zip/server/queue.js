
const { Queue } = require("bullmq");
const IORedis = require("ioredis");

const connection = new IORedis(process.env.REDIS_URL);

const goldenCaseQueue = new Queue("golden-cases", { connection });
const rlhfQueue = new Queue("rlhf", { connection });

module.exports = { goldenCaseQueue, rlhfQueue, connection };
