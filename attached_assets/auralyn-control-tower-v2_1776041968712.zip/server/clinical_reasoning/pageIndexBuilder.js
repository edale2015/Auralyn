
const fs = require("fs");
const pdfParse = require("pdf-parse");

class PageIndexBuilder {
  async buildTreeFromPDF(path) {
    const buffer = fs.readFileSync(path);
    const data = await pdfParse(buffer);
    const pages = data.text.split("\n\n");
    return pages.map((p, i) => ({
      node_id: "node_" + i,
      title: p.slice(0, 80),
      start_page: i,
      end_page: i,
      content: p
    }));
  }
}

module.exports = PageIndexBuilder;
