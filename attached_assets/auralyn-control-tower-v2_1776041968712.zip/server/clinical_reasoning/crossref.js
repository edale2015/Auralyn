
module.exports = function findRefs(text) {
  return text.match(/Appendix\s?[A-Z0-9]+/gi) || [];
};
