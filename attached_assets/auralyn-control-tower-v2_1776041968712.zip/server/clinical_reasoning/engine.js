
const OpenAI = require("openai");
const db = require("../db");
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class ClinicalEngine {
  async answer(documentId, question) {
    const res = await db("SELECT * FROM document_nodes WHERE document_id=$1", [documentId]);
    const nodes = res.rows;

    let reasoningLog = [];
    let visited = new Set();
    let answer = "";

    for (let step = 0; step < 3; step++) {
      const prompt = `
You are a clinical reasoning agent.

Question: ${question}

Nodes:
${nodes.slice(0,5).map(n => n.title).join("\n")}

Visited: ${Array.from(visited)}

Choose next node id.
`;

      const choice = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }]
      });

      const nodeId = choice.choices[0].message.content.trim();
      const node = nodes.find(n => n.id === nodeId) || nodes[0];

      visited.add(node.id);

      const extract = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "user", content: node.content + "\nAnswer: " + question }
        ]
      });

      const part = extract.choices[0].message.content;
      reasoningLog.push({ node: node.id, part });
      answer += "\n" + part;
    }

    await db(
      "INSERT INTO reasoning_queries(document_id, question, selected_node, answer, confidence) VALUES($1,$2,$3,$4,$5)",
      [documentId, question, "multi", answer, 0.9]
    );

    return { answer, reasoningLog };
  }
}

module.exports = ClinicalEngine;
