
const express = require("express");
const ClinicalEngine = require("./clinical_reasoning/engine");
const router = express.Router();
const engine = new ClinicalEngine();

router.post("/ask", async (req, res) => {
  const { documentId, question } = req.body;
  const out = await engine.answer(documentId, question);
  res.json(out);
});

module.exports = router;
