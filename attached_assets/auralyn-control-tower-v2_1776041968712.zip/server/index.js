
require("dotenv").config();
const express = require("express");
const http = require("http");
const routes = require("./routes");
const wsInit = require("./ws");

const app = express();
app.use(express.json());
app.use("/api", routes);

const server = http.createServer(app);
wsInit(server);

server.listen(process.env.PORT || 3000, () =>
  console.log("Server running")
);
