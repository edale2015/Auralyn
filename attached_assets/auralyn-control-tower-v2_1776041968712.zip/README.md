
# Auralyn Control Tower v2

Full-stack clinical reasoning + Control Tower system.

## Quick start (Docker)
```bash
docker compose up --build
```

- API: http://localhost:3000
- Frontend: http://localhost:5173

## Dev
```bash
npm install
npm run dev
```
