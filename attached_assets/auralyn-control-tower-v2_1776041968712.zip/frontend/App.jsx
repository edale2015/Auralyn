
import React, { useEffect, useState } from "react";

export default function App() {
  const [logs, setLogs] = useState([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    const ws = new WebSocket("ws://localhost:3000");
    ws.onmessage = e => setLogs(JSON.parse(e.data));
  }, []);

  const ask = async () => {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ documentId: 1, question: q })
    });
    const data = await res.json();
    console.log(data);
  };

  return (
    <div style={{padding:20}}>
      <h1>🧠 Control Tower</h1>
      <input value={q} onChange={e=>setQ(e.target.value)} />
      <button onClick={ask}>Ask</button>

      <h2>Live Reasoning Stream</h2>
      {logs.map(l => (
        <div key={l.id} style={{border:"1px solid #ccc", margin:5, padding:5}}>
          <b>{l.question}</b>
          <div>{l.answer}</div>
        </div>
      ))}
    </div>
  );
}
