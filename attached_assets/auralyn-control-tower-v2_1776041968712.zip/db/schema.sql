
CREATE TABLE IF NOT EXISTS clinical_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT,
  source TEXT,
  uploaded_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS document_nodes (
  id TEXT PRIMARY KEY,
  document_id UUID REFERENCES clinical_documents(id),
  title TEXT,
  start_page INT,
  end_page INT,
  summary TEXT,
  content TEXT
);

CREATE TABLE IF NOT EXISTS reasoning_queries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID,
  question TEXT,
  selected_node TEXT,
  answer TEXT,
  confidence FLOAT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cross_reference_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  query_id UUID,
  reference TEXT,
  resolved_node TEXT
);

CREATE TABLE IF NOT EXISTS golden_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint TEXT,
  input TEXT,
  expected_output TEXT,
  severity TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS golden_case_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID,
  model_output TEXT,
  correct BOOLEAN,
  feature TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rlhf_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  feature TEXT,
  adjustment FLOAT,
  reason TEXT,
  created_at TIMESTAMP DEFAULT now()
);
