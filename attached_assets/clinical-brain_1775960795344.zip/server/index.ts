import express from "express";
const app = express();
app.use(express.json());

app.get("/", (_, res) => res.send("Clinical Brain Running"));

app.listen(3001, () => console.log("Server on 3001"));