
const express = require("express");
const db = require("./db");
const { calculateNEWS2, riskLevel } = require("./sepsisEngine");
const { rankPatients } = require("./triage");
const { suggestIntervention } = require("./intervention");

const router = express.Router();

router.post("/patient", async (req, res) => {
  const { name, age, vitals } = req.body;

  const p = await db("INSERT INTO patients(name,age,vitals) VALUES($1,$2,$3) RETURNING *",
    [name, age, vitals]);

  const news = calculateNEWS2(vitals);
  const risk = riskLevel(news);

  await db("INSERT INTO risk_scores(patient_id,news2,risk_level) VALUES($1,$2,$3)",
    [p.rows[0].id, news, risk]);

  const intervention = suggestIntervention(risk);

  await db("INSERT INTO interventions(patient_id,recommendation) VALUES($1,$2)",
    [p.rows[0].id, intervention]);

  res.json({ patient: p.rows[0], news, risk, intervention });
});

router.get("/dashboard", async (req, res) => {
  const ranked = await rankPatients();
  res.json(ranked);
});

module.exports = router;
