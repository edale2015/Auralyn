
function calculateNEWS2(v) {
  let score = 0;
  if (v.respRate > 25) score += 3;
  if (v.o2 < 90) score += 3;
  if (v.temp > 39) score += 2;
  if (v.bp < 90) score += 3;
  return score;
}

function riskLevel(score) {
  if (score >= 7) return "ICU";
  if (score >= 5) return "High";
  return "Moderate";
}

module.exports = { calculateNEWS2, riskLevel };
