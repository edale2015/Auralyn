
const db = require("./db");

async function rankPatients() {
  const patients = await db("SELECT * FROM patients");
  const risks = await db("SELECT * FROM risk_scores");

  return patients.rows.map(p => {
    const r = risks.rows.find(x => x.patient_id === p.id);
    return {
      ...p,
      risk: r?.risk_level || "Unknown"
    };
  }).sort((a,b) => (b.risk === "ICU" ? 1 : 0));
}

module.exports = { rankPatients };
