
function suggestIntervention(risk) {
  if (risk === "ICU") return "Send to ICU, start sepsis bundle";
  if (risk === "High") return "IV fluids, labs, monitor closely";
  return "Outpatient management";
}

module.exports = { suggestIntervention };
