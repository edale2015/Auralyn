
CREATE TABLE patients (
  id SERIAL PRIMARY KEY,
  name TEXT,
  age INT,
  vitals JSONB,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE risk_scores (
  id SERIAL PRIMARY KEY,
  patient_id INT,
  news2 FLOAT,
  lactate FLOAT,
  risk_level TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE interventions (
  id SERIAL PRIMARY KEY,
  patient_id INT,
  recommendation TEXT,
  created_at TIMESTAMP DEFAULT now()
);
