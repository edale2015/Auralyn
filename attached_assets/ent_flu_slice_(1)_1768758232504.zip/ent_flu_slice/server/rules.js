const { buildMedsPlan } = require('./meds');

function computeDerived(answers) {
  const fired = [];

  const rf = ['RF_SOB', 'RF_CP', 'RF_NEURO', 'RF_DEHY'].some(k => answers[k]?.value === true);
  if (rf) fired.push('RF_ANY');

  const onset = answers.ONSET?.value;
  const fever = answers.FEVER?.value === true;
  const aches = answers.ACHES?.value === true;

  // Your current rule: Tamiflu suggested if compatible sx and onset <=2 days
  const tamifluEligible = !!(typeof onset === 'number' && onset <= 2 && fever && aches && !rf);
  if (tamifluEligible) fired.push('AV_TAMIFLU_ELIGIBLE');

  const covidPos = answers.COVID_POS?.value; // 'yes' | 'no' | 'not_tested'
  const paxlovidCandidate = (covidPos === 'yes' && !rf);
  if (paxlovidCandidate) fired.push('AV_PAXLOVID_CANDIDATE');

  // Suggested tests (proposal only, MD must approve)
  const tests = [];
  if (!rf) {
    if (covidPos !== 'yes') tests.push('COVID antigen');
    // Flu test is optional; we propose if fever+aches early in course
    if (fever && aches && typeof onset === 'number' && onset <= 3) tests.push('Flu test');
  }

  const medsPlan = buildMedsPlan(answers);

  const disposition = rf ? 'urgent_or_ed' : 'self_care';

  return {
    derived: {
      red_flag: rf,
      onset_days: typeof onset === 'number' ? onset : null,
      fever,
      aches,
      tamiflu_eligible: tamifluEligible,
      paxlovid_candidate: paxlovidCandidate
    },
    proposal: {
      disposition,
      tests,
      meds: medsPlan.meds,
      avoid: medsPlan.avoid
    },
    rulesFired: fired
  };
}

module.exports = { computeDerived };
