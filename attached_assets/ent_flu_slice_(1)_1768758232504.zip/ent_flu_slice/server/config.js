require('dotenv').config();

function optional(name, fallback = '') {
  return process.env[name] ?? fallback;
}

module.exports = {
  port: Number(optional('PORT', '5050')),

  twilio: {
    accountSid: optional('TWILIO_ACCOUNT_SID'),
    authToken: optional('TWILIO_AUTH_TOKEN'),
    whatsappNumber: optional('TWILIO_WHATSAPP_NUMBER')
  },

  google: {
    credentialsPath: optional('GOOGLE_APPLICATION_CREDENTIALS', './service_account.json'),
    firebaseProjectId: optional('FIREBASE_PROJECT_ID', 'medicalm-dec9d')
  },

  sheets: {
    spreadsheetId: optional('SHEETS_SPREADSHEET_ID'),
    encounterTab: optional('SHEETS_ENCOUNTER_TAB', 'Encounter_Log'),
    qaTab: optional('SHEETS_QA_TAB', 'QA_Log'),
    rulesTab: optional('SHEETS_RULES_TAB', 'Rules_Fired'),
    mdTab: optional('SHEETS_MD_TAB', 'MD_Actions')
  },

  md: {
    password: optional('MD_PASSWORD')
  }
};
