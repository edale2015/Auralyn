const { v4: uuidv4 } = require('uuid');
const twilio = require('twilio');
const config = require('./config');
const { QUESTIONS, parseAnswer, nextQuestionIndex } = require('./flow');
const { computeDerived } = require('./rules');
const { upsertEncounter, findLatestOpenEncounterByFrom, getEncounter } = require('./firestore');
const { appendRow } = require('./sheets');
const { buildNote } = require('./note');

function twimlMessage(msg) {
  const MessagingResponse = twilio.twiml.MessagingResponse;
  const r = new MessagingResponse();
  r.message(msg);
  return r.toString();
}

function now() { return new Date().toISOString(); }

async function ensureEncounter(from) {
  const existing = await findLatestOpenEncounterByFrom(from);
  if (existing) return existing;

  const id = uuidv4();
  const enc = {
    createdAt: new Date(),
    channel: 'whatsapp',
    from,
    system: 'ENT',
    complaint: 'FLU_LIKE_URI',
    status: 'IN_PROGRESS',
    answers: {},
    audit: { questionsAsked: [], rulesFired: [] }
  };
  await upsertEncounter(id, enc);
  return { id, ...enc };
}

async function logQA(encId, q, ans) {
  await appendRow(process.env.SHEETS_QA_TAB || 'QA_Log', [
    encId, now(), q.id, q.text, ans.raw
  ]);
}

async function logRules(encId, rules) {
  for (const r of rules) {
    await appendRow(process.env.SHEETS_RULES_TAB || 'Rules_Fired', [encId, now(), r, 'fired']);
  }
}

async function logEncounterSummary(enc) {
  // One row summary when we hit PENDING_MD (proposal ready)
  await appendRow(process.env.SHEETS_ENCOUNTER_TAB || 'Encounter_Log', [
    enc.id,
    now(),
    enc.from,
    enc.system,
    enc.complaint,
    enc.derived?.onset_days ?? '',
    enc.derived?.red_flag ?? '',
    enc.derived?.tamiflu_eligible ?? '',
    enc.derived?.paxlovid_candidate ?? '',
    enc.proposal?.disposition ?? '',
    (enc.proposal?.tests || []).join(', ')
  ]);
}

function isStartMessage(body) {
  const s = String(body || '').trim().toLowerCase();
  return ['start', 'hi', 'hello', 'hey', 'begin', 'restart', 'reset'].includes(s);
}

async function handleWhatsAppWebhook(req, res) {
  try {
    const from = req.body.From;
    const body = req.body.Body;
    if (!from) {
      res.type('text/xml').send(twimlMessage('Missing sender.'));
      return;
    }

    // Ensure encounter
    let enc = await ensureEncounter(from);
    let encFull = await getEncounter(enc.id);

    // If this is a start message and we already have answers, create a new encounter
    if (isStartMessage(body) && encFull && Object.keys(encFull.answers || {}).length > 0) {
      // create new
      const id = uuidv4();
      const fresh = {
        createdAt: new Date(),
        channel: 'whatsapp',
        from,
        system: 'ENT',
        complaint: 'FLU_LIKE_URI',
        status: 'IN_PROGRESS',
        answers: {},
        audit: { questionsAsked: [], rulesFired: [] }
      };
      await upsertEncounter(id, fresh);
      encFull = { id, ...fresh };
    }

    const answers = encFull.answers || {};

    // Determine which question we are expecting.
    const qIndex = nextQuestionIndex(answers);

    // If we have not asked anything yet, treat first message as a start trigger unless it's clearly a yes/no/number.
    if (qIndex === 0 && !isStartMessage(body)) {
      const trimmed = String(body || '').trim();
      // If they sent a number, we will still start at Q1 rather than mis-assign to RF.
      // Keep it simple: send Q1 and don't record.
      const q0 = QUESTIONS[0];
      await upsertEncounter(encFull.id, {
        status: 'IN_PROGRESS',
        state: { currentQuestionId: q0.id }
      });
      res.type('text/xml').send(twimlMessage(`Quick safety check first. ${q0.text}`));
      return;
    }

    // If we've already asked a question, record answer to the current question.
    if (qIndex < QUESTIONS.length) {
      const q = QUESTIONS[qIndex];
      const parsed = parseAnswer(q, body);
      const patch = {
        answers: { [q.id]: parsed },
        audit: {
          questionsAsked: [...(encFull.audit?.questionsAsked || []), q.id]
        },
        state: { currentQuestionId: q.id }
      };
      await upsertEncounter(encFull.id, patch);
      await logQA(encFull.id, q, parsed);
    }

    // Reload encounter with new answer
    encFull = await getEncounter(encFull.id);

    const nextIndex = nextQuestionIndex(encFull.answers || {});
    if (nextIndex >= QUESTIONS.length) {
      // Completed intake -> compute proposal and send to MD queue
      const computed = computeDerived(encFull.answers || {});
      const updated = {
        status: 'PENDING_MD',
        derived: computed.derived,
        proposal: computed.proposal,
        audit: {
          questionsAsked: encFull.audit?.questionsAsked || [],
          rulesFired: computed.rulesFired
        }
      };
      await upsertEncounter(encFull.id, updated);
      await logRules(encFull.id, computed.rulesFired);
      const finalEnc = await getEncounter(encFull.id);
      await logEncounterSummary(finalEnc);

      res.type('text/xml').send(twimlMessage('Thanks. Your responses were received. Dr. Thomas is reviewing now. If you develop trouble breathing, chest pain/pressure, confusion/fainting, or cannot keep fluids down, seek urgent care/ER immediately.'));
      return;
    }

    const nextQ = QUESTIONS[nextIndex];
    res.type('text/xml').send(twimlMessage(nextQ.text));
  } catch (err) {
    console.error(err);
    res.type('text/xml').send(twimlMessage('Sorry, there was a technical error. Please try again.'));
  }
}

module.exports = { handleWhatsAppWebhook };
