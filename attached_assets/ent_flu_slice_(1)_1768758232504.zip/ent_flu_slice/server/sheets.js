const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');
const config = require('./config');

let _sheets = null;

async function getSheetsClient() {
  if (!config.sheets.spreadsheetId) return null;
  if (_sheets) return _sheets;

  const credPath = path.resolve(__dirname, '..', config.google.credentialsPath);
  const key = JSON.parse(fs.readFileSync(credPath, 'utf8'));

  const auth = new google.auth.GoogleAuth({
    credentials: key,
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });

  const client = await auth.getClient();
  _sheets = google.sheets({ version: 'v4', auth: client });
  return _sheets;
}

async function appendRow(sheetName, row) {
  const sheets = await getSheetsClient();
  if (!sheets) return;

  await sheets.spreadsheets.values.append({
    spreadsheetId: config.sheets.spreadsheetId,
    range: `${sheetName}!A1`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody: {
      values: [row]
    }
  });
}

module.exports = {
  appendRow
};
