function yn(b) {
  if (b === true) return 'Yes';
  if (b === false) return 'No';
  return 'Unknown';
}

function buildNote(enc) {
  const a = enc.answers || {};
  const d = enc.derived || {};
  const f = enc.final || {};
  const p = enc.proposal || {};

  const lines = [];
  lines.push(`CHIEF COMPLAINT: Flu-like upper respiratory symptoms`);
  lines.push('');
  lines.push('HPI:');
  lines.push(`- Onset: ${d.onset_days ?? 'Unknown'} day(s)`);
  lines.push(`- Fever: ${yn(d.fever)}; Body aches/fatigue: ${yn(d.aches)}`);
  lines.push(`- Cough: ${yn(a.COUGH?.value)}; Sore throat: ${yn(a.THROAT?.value)}; Congestion/sinus pressure: ${yn(a.CONGEST?.value)}; Ear pain/fullness: ${yn(a.EAR?.value)}`);
  lines.push(`- Nausea/diarrhea: ${yn(a.GI?.value)}`);
  lines.push(`- Red flags (SOB/chest pain/neuro/dehydration): ${d.red_flag ? 'Present' : 'Denied'}`);
  lines.push('');

  lines.push('ASSESSMENT:');
  lines.push('- Influenza-like illness / viral URI (working impression)');
  if (d.tamiflu_eligible) lines.push('- Antiviral eligibility: Tamiflu eligible based on onset and symptom cluster (requires clinician decision)');
  if (d.paxlovid_candidate) lines.push('- COVID positive reported; Paxlovid candidacy noted (eligibility policy to be confirmed)');
  lines.push('');

  lines.push('PLAN (Clinician-approved):');
  const disp = f.disposition || p.disposition || 'pending';
  lines.push(`- Disposition: ${disp}`);

  const tests = f.tests || p.tests || [];
  if (tests.length) lines.push(`- Tests: ${tests.join(', ')}`);

  const meds = f.meds || p.meds || [];
  if (meds.length) {
    lines.push('- Symptom relief options:');
    meds.forEach(m => lines.push(`  - ${m.name}: ${m.reason}`));
  }

  const avoid = f.avoid || p.avoid || [];
  if (avoid.length) {
    lines.push('- Avoid / caution:');
    avoid.forEach(m => lines.push(`  - ${m.name}: ${m.reason}`));
  }

  lines.push('');
  lines.push('RETURN PRECAUTIONS: Seek urgent care/ER for trouble breathing, chest pain/pressure, confusion/fainting, inability to keep fluids down, or worsening symptoms.');

  return {
    text: lines.join('\n'),
    structured: {
      complaint: 'FLU_LIKE_URI',
      onset_days: d.onset_days ?? null,
      fever: d.fever ?? null,
      aches: d.aches ?? null,
      tamiflu_eligible: d.tamiflu_eligible ?? null,
      paxlovid_candidate: d.paxlovid_candidate ?? null,
      disposition: disp,
      tests
    }
  };
}

module.exports = { buildNote };
