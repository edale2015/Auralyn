const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');
const config = require('./config');

let _db = null;

function initFirestore() {
  if (_db) return _db;

  const credPath = path.resolve(__dirname, '..', config.google.credentialsPath);
  if (!fs.existsSync(credPath)) {
    throw new Error(
      `Service account JSON not found at ${credPath}. ` +
      `Copy your service account json to ent_flu_slice/service_account.json and set GOOGLE_APPLICATION_CREDENTIALS=./service_account.json`
    );
  }

  const serviceAccount = JSON.parse(fs.readFileSync(credPath, 'utf8'));

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: config.google.firebaseProjectId
  });

  _db = admin.firestore();
  return _db;
}

function db() {
  return initFirestore();
}

async function upsertEncounter(encounterId, patch) {
  const ref = db().collection('encounters').doc(encounterId);
  await ref.set({ ...patch }, { merge: true });
}

async function getEncounter(encounterId) {
  const ref = db().collection('encounters').doc(encounterId);
  const snap = await ref.get();
  if (!snap.exists) return null;
  return { id: snap.id, ...snap.data() };
}

async function listPendingEncounters(limit = 50) {
  const snaps = await db()
    .collection('encounters')
    .where('status', '==', 'PENDING_MD')
    .orderBy('createdAt', 'desc')
    .limit(limit)
    .get();
  return snaps.docs.map(d => ({ id: d.id, ...d.data() }));
}

async function findLatestOpenEncounterByFrom(from, hoursBack = 24) {
  const cutoff = new Date(Date.now() - hoursBack * 60 * 60 * 1000);
  // Note: this query requires a Firestore composite index in the console if it errors.
  const snaps = await db()
    .collection('encounters')
    .where('from', '==', from)
    .where('status', 'in', ['IN_PROGRESS', 'NEEDS_PATIENT'])
    .where('createdAt', '>=', cutoff)
    .orderBy('createdAt', 'desc')
    .limit(1)
    .get();
  if (snaps.empty) return null;
  const d = snaps.docs[0];
  return { id: d.id, ...d.data() };
}

module.exports = {
  db,
  upsertEncounter,
  getEncounter,
  listPendingEncounters,
  findLatestOpenEncounterByFrom
};
