const QUESTIONS = [
  { id: 'RF_SOB', text: 'Trouble breathing at rest? (Y/N)', type: 'red_flag', format: 'yesno' },
  { id: 'RF_CP', text: 'Chest pain or pressure? (Y/N)', type: 'red_flag', format: 'yesno' },
  { id: 'RF_NEURO', text: 'Confusion, fainting, or severe weakness? (Y/N)', type: 'red_flag', format: 'yesno' },
  { id: 'RF_DEHY', text: 'Unable to keep fluids down or signs of dehydration? (Y/N)', type: 'red_flag', format: 'yesno' },

  { id: 'ONSET', text: 'How many days since symptoms started? (number)', type: 'core', format: 'number' },
  { id: 'FEVER', text: 'Fever ≥ 100.4F (38C)? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'ACHES', text: 'Body aches or marked fatigue? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'COUGH', text: 'Cough? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'THROAT', text: 'Sore throat? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'CONGEST', text: 'Nasal congestion or sinus pressure? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'EAR', text: 'Ear pain or fullness? (Y/N)', type: 'core', format: 'yesno' },
  { id: 'GI', text: 'Nausea or diarrhea? (Y/N)', type: 'core', format: 'yesno' },

  { id: 'PREG', text: 'Pregnant? (Y/N)', type: 'modifier', format: 'yesno' },
  { id: 'HTN', text: 'High blood pressure? (Y/N)', type: 'modifier', format: 'yesno' },
  { id: 'ANX', text: 'Anxiety/panic or sensitive to stimulants? (Y/N)', type: 'modifier', format: 'yesno' },
  { id: 'SSRI', text: 'On an SSRI/SNRI antidepressant? (Y/N)', type: 'modifier', format: 'yesno' },
  { id: 'ALLERGIES', text: 'Any medication allergies? (brief text, or "none")', type: 'modifier', format: 'text' },

  { id: 'COVID_POS', text: 'COVID test positive? (Y/N/Not tested)', type: 'test', format: 'tri' },
  { id: 'FLU_POS', text: 'Flu test positive? (Y/N/Not tested)', type: 'test', format: 'tri' }
];

function normalizeYesNo(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim().toLowerCase();
  if (['y', 'yes', 'true', 't', '1'].includes(s)) return true;
  if (['n', 'no', 'false', 'f', '0'].includes(s)) return false;
  return null;
}

function normalizeTri(v) {
  const s = String(v || '').trim().toLowerCase();
  if (['y', 'yes', 'positive', 'pos', 'true', 't', '1'].includes(s)) return 'yes';
  if (['n', 'no', 'negative', 'neg', 'false', 'f', '0'].includes(s)) return 'no';
  if (s === '' || s.includes('not')) return 'not_tested';
  return 'not_tested';
}

function parseAnswer(q, raw) {
  switch (q.format) {
    case 'yesno': {
      const b = normalizeYesNo(raw);
      return { raw: String(raw ?? ''), value: b };
    }
    case 'number': {
      const n = Number(String(raw ?? '').trim());
      return { raw: String(raw ?? ''), value: Number.isFinite(n) ? n : null };
    }
    case 'tri': {
      return { raw: String(raw ?? ''), value: normalizeTri(raw) };
    }
    default:
      return { raw: String(raw ?? ''), value: String(raw ?? '').trim() };
  }
}

function nextQuestionIndex(answers) {
  for (let i = 0; i < QUESTIONS.length; i++) {
    if (!(QUESTIONS[i].id in answers)) return i;
  }
  return QUESTIONS.length;
}

module.exports = {
  QUESTIONS,
  parseAnswer,
  nextQuestionIndex
};
