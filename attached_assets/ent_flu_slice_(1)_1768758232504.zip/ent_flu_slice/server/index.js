const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const config = require('./config');
const { handleWhatsAppWebhook } = require('./twilioWebhook');
const { listPendingEncounters, getEncounter, upsertEncounter } = require('./firestore');
const { appendRow } = require('./sheets');
const { buildNote } = require('./note');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

function now() { return new Date().toISOString(); }

function mdAuth(req, res, next) {
  // Very simple protection: if MD_PASSWORD set, require ?p= or header x-md-password
  const pw = config.md.password;
  if (!pw) return next();
  const supplied = req.query.p || req.headers['x-md-password'];
  if (supplied === pw) return next();
  res.status(401).send('Unauthorized');
}

async function sendWhatsApp(to, text) {
  if (!config.twilio.accountSid || !config.twilio.authToken || !config.twilio.whatsappNumber) {
    console.warn('Twilio creds not set; skipping outbound WhatsApp send.');
    return;
  }
  const client = twilio(config.twilio.accountSid, config.twilio.authToken);
  await client.messages.create({
    from: config.twilio.whatsappNumber,
    to,
    body: text
  });
}

// Twilio webhook
app.post('/whatsapp', handleWhatsAppWebhook);

// MD Dashboard
app.get('/md/queue', mdAuth, async (req, res) => {
  const items = await listPendingEncounters(50);
  const rows = items.map(e => {
    const red = e.derived?.red_flag ? '🚨' : '✅';
    const onset = e.derived?.onset_days ?? '';
    const tam = e.derived?.tamiflu_eligible ? 'Tamiflu?' : '';
    const tests = (e.proposal?.tests || []).join(', ');
    return `<tr>
      <td>${new Date(e.createdAt?._seconds ? e.createdAt._seconds*1000 : e.createdAt).toLocaleString()}</td>
      <td>${red}</td>
      <td>${onset}</td>
      <td>${tam}</td>
      <td>${tests}</td>
      <td><a href="/md/review/${e.id}?p=${encodeURIComponent(req.query.p || '')}">Open</a></td>
    </tr>`;
  }).join('\n');

  res.send(`
    <html>
      <head><title>MD Queue</title></head>
      <body style="font-family: Arial; max-width: 900px; margin: 24px auto;">
        <h2>Pending MD Review (ENT Flu-like)</h2>
        <table border="1" cellpadding="8" cellspacing="0">
          <tr><th>Created</th><th>RF</th><th>Onset(d)</th><th>Flags</th><th>Proposed tests</th><th></th></tr>
          ${rows || '<tr><td colspan="6">No pending encounters.</td></tr>'}
        </table>
      </body>
    </html>
  `);
});

app.get('/md/review/:id', mdAuth, async (req, res) => {
  const enc = await getEncounter(req.params.id);
  if (!enc) return res.status(404).send('Not found');

  const p = enc.proposal || {};
  const d = enc.derived || {};
  const a = enc.answers || {};
  const pass = encodeURIComponent(req.query.p || '');

  const testsCsv = (p.tests || []).join(', ');

  res.send(`
    <html>
      <head><title>Review ${enc.id}</title></head>
      <body style="font-family: Arial; max-width: 900px; margin: 24px auto;">
        <a href="/md/queue?p=${pass}">← Back to queue</a>
        <h2>Review Encounter</h2>
        <div style="padding: 12px; border: 1px solid #ccc; border-radius: 8px;">
          <b>From:</b> ${enc.from}<br/>
          <b>Onset days:</b> ${d.onset_days ?? 'Unknown'}<br/>
          <b>Red flags:</b> ${d.red_flag ? '<span style="color:red">PRESENT</span>' : 'Denied'}<br/>
          <b>Tamiflu eligible:</b> ${d.tamiflu_eligible ? 'Yes' : 'No'}<br/>
          <b>COVID test:</b> ${a.COVID_POS?.value || 'not_tested'}<br/>
        </div>

        <h3>Proposal</h3>
        <form method="POST" action="/md/approve/${enc.id}?p=${pass}">
          <label>Disposition:</label>
          <select name="disposition">
            <option value="self_care" ${p.disposition==='self_care'?'selected':''}>Self-care</option>
            <option value="urgent_or_ed" ${p.disposition==='urgent_or_ed'?'selected':''}>Urgent/ED</option>
            <option value="urgent_care" ${p.disposition==='urgent_care'?'selected':''}>Urgent care</option>
          </select>
          <br/><br/>
          <label>Tests (comma-separated):</label><br/>
          <input type="text" name="tests" style="width: 100%" value="${testsCsv}" />
          <br/><br/>
          <label>Message add-on (optional):</label><br/>
          <textarea name="addon" style="width:100%; height:70px"></textarea>
          <br/><br/>
          <button type="submit" style="padding:10px 16px">✅ Approve & Send Plan</button>
        </form>

        <h3>Symptom meds (auto)</h3>
        <ul>
          ${(p.meds||[]).map(m => `<li><b>${m.name}</b> — ${m.reason}</li>`).join('') || '<li>None</li>'}
        </ul>
        <h3>Avoid/Caution</h3>
        <ul>
          ${(p.avoid||[]).map(m => `<li><b>${m.name}</b> — ${m.reason}</li>`).join('') || '<li>None</li>'}
        </ul>

        <details>
          <summary>Raw answers</summary>
          <pre>${JSON.stringify(a, null, 2)}</pre>
        </details>
      </body>
    </html>
  `);
});

app.post('/md/approve/:id', mdAuth, async (req, res) => {
  const enc = await getEncounter(req.params.id);
  if (!enc) return res.status(404).send('Not found');

  const disposition = req.body.disposition;
  const tests = String(req.body.tests || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  const addon = String(req.body.addon || '').trim();

  const final = {
    disposition,
    tests,
    meds: enc.proposal?.meds || [],
    avoid: enc.proposal?.avoid || [],
    approvedAt: new Date(),
    approvedBy: 'Dr'
  };

  // Generate note payload now (Athena note only, stored)
  const notePayload = buildNote({ ...enc, final, derived: enc.derived, proposal: enc.proposal });

  await upsertEncounter(enc.id, {
    status: 'APPROVED',
    final,
    note: notePayload
  });

  // Log MD action to Sheets (if configured)
  await appendRow(process.env.SHEETS_MD_TAB || 'MD_Actions', [
    enc.id, now(), enc.from, 'APPROVE', disposition, tests.join(', ')
  ]);

  // Send plan to patient via WhatsApp
  let msg = `Dr. Thomas reviewed your symptoms. Disposition: ${disposition.replaceAll('_',' ')}.`;
  if (tests.length) msg += ` Tests ordered/arranged: ${tests.join(', ')}.`;
  if (enc.derived?.tamiflu_eligible) msg += ` You may be eligible for antiviral treatment (onset/timing).`;
  msg += ` Symptom relief options: ${(final.meds||[]).slice(0,4).map(m=>m.name).join(', ')}.`;
  if ((final.avoid||[]).length) msg += ` Avoid/caution: ${(final.avoid||[]).map(m=>m.name).join(', ')}.`;
  msg += ` Return precautions: trouble breathing, chest pain/pressure, confusion/fainting, can't keep fluids down, or worsening symptoms.`;
  if (addon) msg += ` ${addon}`;

  await sendWhatsApp(enc.from, msg);

  // Redirect back
  res.redirect(`/md/review/${enc.id}?p=${encodeURIComponent(req.query.p || '')}`);
});

app.get('/health', (_, res) => res.json({ ok: true }));

app.listen(config.port, () => {
  console.log(`ENT flu slice server listening on :${config.port}`);
  console.log(`Twilio webhook: POST /whatsapp`);
  console.log(`MD queue: http://localhost:${config.port}/md/queue`);
});
