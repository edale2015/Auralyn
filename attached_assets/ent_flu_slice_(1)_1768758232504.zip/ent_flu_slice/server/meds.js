function buildMedsPlan(answers) {
  const preg = answers.PREG?.value === true;
  const htn = answers.HTN?.value === true;
  const anx = answers.ANX?.value === true;
  const ssri = answers.SSRI?.value === true;

  const meds = [];
  const avoid = [];

  // Always-OK symptomatic options
  meds.push({ name: 'acetaminophen', reason: 'fever/pain' });
  meds.push({ name: 'saline nasal spray', reason: 'congestion/sinus irritation' });
  meds.push({ name: 'guaifenesin', reason: 'mucus thinning (cough/chest congestion)' });

  // Ibuprofen: optional, but avoid in pregnancy by default
  if (!preg) {
    meds.push({ name: 'ibuprofen', reason: 'pain/inflammation (if no contraindications)' });
  } else {
    avoid.push({ name: 'ibuprofen/NSAIDs', reason: 'avoid in pregnancy unless clinician directs' });
  }

  // Dextromethorphan: avoid with SSRI/SNRI
  if (!ssri) {
    meds.push({ name: 'dextromethorphan', reason: 'cough suppression (short term)' });
  } else {
    avoid.push({ name: 'dextromethorphan', reason: 'avoid with SSRI/SNRI due to serotonergic interaction risk' });
  }

  // Decongestants: avoid with HTN/anxiety
  if (!htn && !anx) {
    meds.push({ name: 'pseudoephedrine', reason: 'short-term congestion relief (if appropriate)' });
  } else {
    avoid.push({ name: 'pseudoephedrine', reason: htn ? 'avoid with hypertension' : 'avoid if anxiety/stimulant sensitivity' });
  }

  return { meds, avoid };
}

module.exports = { buildMedsPlan };
