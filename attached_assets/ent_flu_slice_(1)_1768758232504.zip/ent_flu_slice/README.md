# ENT Flu-like Vertical Slice (WhatsApp -> MD Dashboard -> Firestore + Sheets -> Athena Note Payload)

This is a minimal, working template for **one complaint**: **ENT / Flu-like URI**.

## Security note (important)
You shared a Google service account private key in this chat. Treat that key as exposed and **rotate it in GCP** after you download this bundle.

## What works in this slice
- WhatsApp intake via **Twilio webhook** (`POST /whatsapp`)
- Stores encounter state and answers in **Firestore** (project `medicalm-dec9d`)
- Generates a **proposal** (tests/disposition/meds) but **does not finalize** until MD approves
- MD **web dashboard queue** and **review/approve** actions
- On approval, sends plan back to patient via WhatsApp and stores a generated **Athena-ready note payload** (no Athena API call yet)
- Optional: append logs to Google Sheets if you set `SHEETS_SPREADSHEET_ID`

## Quick start
1) Install dependencies
```bash
npm install
```

2) Copy env file and fill in credentials
```bash
cp .env.example .env
```

3) Run
```bash
npm start
```

4) Set your Twilio WhatsApp webhook to:
- `https://<your-domain>/whatsapp`

5) Open the MD queue:
- `http://localhost:5050/md/queue`
- If you set `MD_PASSWORD`, add `?p=<password>`

## Google Sheets (optional)
If you set `SHEETS_SPREADSHEET_ID`, create 4 tabs:
- Encounter_Log
- QA_Log
- Rules_Fired
- MD_Actions

The service account email must have edit access to the sheet.

## Firestore
This uses Firebase Admin SDK with the bundled service account JSON at `service_account.json`.

## Files to know
- `server/flow.js`: the WhatsApp question list
- `server/rules.js`: proposal logic (red flags, tamiflu, tests)
- `server/meds.js`: symptom meds + pruning logic
- `server/index.js`: Twilio webhook + MD dashboard + approve action
- `server/note.js`: Athena note payload generator
