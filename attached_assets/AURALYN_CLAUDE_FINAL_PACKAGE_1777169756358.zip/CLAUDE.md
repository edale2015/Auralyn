# CLAUDE.md: Auralyn Medical Triage SaaS

Root instructions for Claude Code in this repo. Auralyn is a medical triage/CDS system with PHI, clinic tenancy, AI proposals, physician review, audit trails, WhatsApp/web intake, FHIR/EHR paths, and many startup workers. Patient safety, privacy, authorization, auditability, and small diffs outrank speed or cleverness.

## 1. Working Contract

- Make the smallest correct change. No speculative architecture, broad cleanup, drive-by refactors, or mass formatting.
- Read the relevant files before editing. This repo has duplicate-looking auth, audit, route, and clinical modules; names alone are not enough.
- Surface uncertainty. If clinical, auth, tenant, audit, migration, or PHI behavior is ambiguous, state the assumption before changing code.
- Preserve existing behavior unless the task asks to change it. Do not “improve” adjacent systems casually.
- Define done before coding, then verify. If a check cannot run, report exactly what was not verified.
- Report changed files, checks run, results, and remaining clinical/security risk.

## 2. Absolute Non-Negotiables

- AI output is clinical decision support only. It must not autonomously diagnose, prescribe, discharge, transfer, order, approve, or route a real patient.
- A real physician/admin review action is required before clinical approval. AI must never set approval fields or approval status by itself.
- Never expose PHI/ePHI in logs, errors, metrics labels, WebSocket payloads, prompts, fixtures, screenshots, or test data.
- Never bypass auth, role checks, CSRF, rate limiting, tenant filters, file ownership checks, or webhook signature checks on patient/clinical routes.
- Never delete, mutate, backfill, or silently skip audit-chain entries.
- Never let an LLM downgrade deterministic HIGH/CRITICAL risk or bypass red flags, hard stops, `safetyGate()`, or physician co-signature rules.
- Never invent clinical protocols, red flags, diagnoses, dosing, treatment plans, or disposition rules. Use KB/Sheets, validated deterministic rules, physician-authored rules, or explicit requirements.
- Fail closed for safety, auth, tenant, audit, file, EHR/FHIR, and webhook uncertainty.

## 3. Source-of-Truth Map

| Area | Read first |
| --- | --- |
| Startup/routes | `server/index.ts`, `server/routes.ts`, relevant `server/routes/*` module |
| Frontend routing | `client/src/App.tsx`, `client/src/routes/routeRegistry.ts` |
| Frontend auth/API | `client/src/context/AuthContext.tsx`, `client/src/components/RoleGuard.tsx`, `client/src/lib/queryClient.ts` |
| Cookie auth/CSRF | `server/security/session.ts`, `server/security/authCookies.ts` |
| Bearer role auth | `server/routes/roleAuth.ts`, `server/services/authService.ts`, `server/middleware/requireRole.ts` |
| Provider/EHR auth | `server/auth.ts`, `server/auth/unifiedAuth.ts`, `server/auth/requirePhysician.ts` |
| PHI/redaction | `server/security/phi.ts`, `server/utils/logger.ts`, `server/security/redaction.ts`, `server/middleware/phiScrubber.ts` |
| Audit | `server/audit/hashChain.ts`, `server/audit/auditLogger.ts`, `server/audit/externalAuditStore.ts` |
| Clinical brain | `server/agents/brainOrchestrator.ts`, `server/agents/clinicalDecisionBridge.ts`, `server/agents/persistentLoopState.ts` |
| WebSockets | `server/ws/patientStream.ts`, WS setup in `server/index.ts` |
| Data/schema | `shared/schema.ts`, `server/storage.ts`, `server/db.ts` |
| Migrations | `drizzle.config.ts`, `server/db/migrations/*`, any root `migrations/*` if created |
| Tests | `vitest.config.ts`, `tests/unit/*`, `tests/integration/*`, `tests/contracts/*` |
| Long review docs | `CLAUDE_ANALYSIS_BRIEF.md`, `CLAUDE_ARCHITECTURE_REVIEW_V2.md`, `AURALYN_CODE_REVIEW_SLICES.md`, `replit.md` |

## 4. Current Repo Reality to Respect

- The checked-in `CLAUDE.md` from the sanitized export is a context bundle, not a lean operating file. Keep this root file compact and actionable.
- The sanitized export contains `[REDACTED]` placeholders. Do not copy those tokens into live code; verify against real Replit source/env before type-check conclusions.
- If `.replit` or any checked-in config contains real-looking secret values, rotate them, move them to Replit Secrets or a managed store, and never repeat values in chat, logs, or commits.
- There are multiple auth systems in active or legacy use. Do not create another one.
- `AuthContext.tsx` and `RoleGuard.tsx` still use `localStorage` bearer tokens. `queryClient.ts` uses cookie credentials and CSRF injection. New frontend code should use `apiRequest()`/cookie+CSRF and must not add new localStorage token reads.
- `server/security/session.ts` is the cookie+CSRF target path, but bearer fallback is transitional while localStorage migration is incomplete.
- `server/routes/roleAuth.ts` currently returns bearer-token login data and uses bearer-based `requireRole` for `/me`; do not claim it is fully cookie-only until implemented.
- Role vocabularies differ across files. Align roles before adding a route or UI guard. Avoid undefined roles such as `clinician` unless the backend type and middleware explicitly support them.
- `encounters` approval is represented by `status`, `approvedAt`, `physicianId`, and physician fields. `orders` has `physicianApproved`. Do not check or set a nonexistent `encounters.physicianApproved` column unless adding a migration and all call-site changes.
- `server/index.ts` is large and starts many route modules, sockets, loops, monitors, and workers. New background loops must be behind explicit env flags and safe defaults.

## 5. Clinical Safety Rules

- Deterministic hard stops/red flags run before AI. Do not move LLM calls ahead of safety checks.
- `safetyGate()` in `server/agents/brainOrchestrator.ts` must run before routing/escalation decisions.
- `clinicalDecisionBridge.ts` must preserve the rule that LLM output cannot downgrade deterministic HIGH/CRITICAL risk.
- ICU/CRITICAL/ER routing, order approval, EHR writes, and discharge/return-to-work instructions require authenticated clinician review and audit.
- CDS shown to clinicians must preserve an independently reviewable basis: inputs used, rule/KB basis when available, confidence/uncertainty, limits, and review status.
- Patient-facing AI may collect symptoms and advise emergency escalation for red flags, but must not present a definitive diagnosis or treatment plan.
- Simulations, digital twins, autonomous loops, RLHF, federated learning, and research agents must not affect real clinical records unless an explicitly reviewed path, audit entry, and physician gate exist.

## 6. PHI/ePHI Rules

Treat as PHI/ePHI: names, phone numbers, WhatsApp/SMS content, symptoms tied to a person, diagnoses, vitals, orders, clinical notes, intake sessions, documents, portal/session tokens, FHIR/EHR data, stable patient IDs, and combinations that identify a patient.

- Never use `console.log(req.body)`, raw `JSON.stringify(response)`, or raw error details near intake, encounter, patient, order, WhatsApp, file, AI, FHIR, or audit paths.
- Prefer `logger.*`/redaction utilities. Use `scrubPhi()`, `publicPatientRef()`, `sanitizeAgentCycleForSocket()`, or `scrubCycleForApi()` where appropriate.
- Beware the inline response logger in `server/index.ts` that appends captured JSON responses. Do not expand it; fix or sanitize it before relying on it in production.
- Do not rely on object-only sanitizers for raw free-text strings. Check the sanitizer’s behavior before using it.
- API errors must be generic. Error bodies must not include patient content, prompts, EHR payloads, or file metadata that identifies a patient.
- Tests, fixtures, demos, golden cases, screenshots, and simulations use synthetic data only.
- Send minimum-necessary data to external services and only when BAA/approval status is confirmed for that workflow.
- Do not put PHI in Redis keys, queue names, metric labels, trace spans, WebSocket channel names, URLs, query params, or audit metadata summaries.

## 7. Auth, Roles, and Tenancy

- Protected clinical/admin routes require auth middleware plus correct role middleware. Frontend `RoleGuard` is advisory only; backend enforcement is mandatory.
- Mutating clinical/admin routes require CSRF unless the endpoint is a verified signed webhook/API integration with its own authentication.
- Login, webhook, clinical mutation, agent-brain mutation, file, and EHR/FHIR routes need rate limiting.
- Never trust `req.body.role`, client clinic/tenant IDs, query params, localStorage, or UI route guards for authorization.
- Use verified request identity: `req.user`, `req.provider`, or the route’s established authenticated principal. Document which auth path a route uses.
- Tenant-scoped data must filter by verified `clinicId`, `clinicSiteId`, `organizationId`, or the route’s equivalent server-side tenant field.
- RLS policies using `current_setting('app.clinic_id')` only protect queries if the setting is applied on the same DB connection/transaction as the query. Verify this before claiming RLS enforcement.
- WebSocket upgrades carrying clinical data require authenticated identity and tenant-scoped broadcast. Tokens in query strings are sensitive; prefer cookies/headers when available and never log WS URLs.

## 8. Audit Rules

- Canonical production audit append path: `appendAuditEvent()` in `server/audit/hashChain.ts`.
- New regulated clinical events must include `traceId`, `step`, scrubbed `input`, scrubbed `output`, and useful `metadata`.
- Required audit events: intake submission, consent, AI proposal, red flag/risk scoring, safety gate, physician review, approval/rejection, order suggestions/approvals, file access, external PHI transfer, EHR/FHIR write attempt/result, KB/model/governance change, admin permission change.
- Do not introduce a new audit chain. This repo has several audit-like modules; choose the canonical path unless explicitly refactoring.
- Do not use legacy `logEvent()` or memory-only audit shims for new regulated evidence.
- Never change stable stringify/hash material, genesis hash, advisory lock behavior, or verification semantics without an explicit migration/replay plan and user approval.

## 9. Database and Migration Rules

- `shared/schema.ts` is the Drizzle schema source of truth. Update Zod schemas, inferred types, storage methods, routes, and tests when schema changes.
- DB writes should go through `IStorage` in `server/storage.ts` unless the domain already has an established service/repository pattern.
- Validate request bodies with Zod before writes.
- Do not change primary-key types or existing column semantics casually.
- Do not edit applied migrations. Do not run destructive SQL without explicit user approval.
- `drizzle.config.ts` outputs to `./migrations`, but this sanitized repo currently shows SQL under `server/db/migrations/*`; verify the actual chosen migration path before adding files.
- `server/db/migrate.ts` looks for `server/db/schema.sql`; do not assume it runs the SQL files under `server/db/migrations/*` until that is fixed.
- For existing tables, prefer explicit additive SQL such as `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` plus a rollback note. Do not use `db:push` on production-shaped data unless the user explicitly approves.

## 10. API Pattern

```ts
router.post("/example", requireAuth, requireAnyRole(["admin", "physician"]), requireCsrf, limiter, asyncHandler(async (req, res) => {
  const parsed = schema.parse(req.body);
  const result = await serviceOrStorageCall(parsed, req.user);
  await appendAuditEvent({ traceId, step, input, output, metadata });
  res.json({ ok: true, data: result });
}));
```

Use existing route conventions when they differ, but always preserve: auth, role, tenant scope, CSRF for browser mutations, rate limit, Zod validation, idempotency for duplicate-sensitive clinical writes, audit, and PHI-safe response/error handling.

## 11. Frontend Rules

- New pages go in `client/src/pages/`; shared UI in `client/src/components/`; shadcn primitives from `@/components/ui/*`.
- Routes often exist in both `client/src/App.tsx` and `client/src/routes/routeRegistry.ts`. Update both when relevant, but verify hardcoded routes because not all routes are registry-backed.
- Use TanStack Query v5 object API: `useQuery({ queryKey, queryFn })`.
- Use `apiRequest(method, url, data)` from `@/lib/queryClient` for mutations so credentials and CSRF headers are handled.
- Forms use `react-hook-form`, `zodResolver`, and `defaultValues`.
- Interactive elements need stable `data-testid` attributes.
- Do not add new localStorage token reads/writes. Migrate existing localStorage auth only when asked and with backend cookie behavior verified.
- CDS UI must show review status, confidence/uncertainty when available, and whether a physician has approved/modified/rejected the AI proposal.

## 12. AI/CDS and Integrations

- LLM prompts must exclude names, phone numbers, stable patient IDs, and unnecessary PHI.
- Clinical AI outputs need `intendedUse: "clinical_decision_support_only"` or equivalent audit metadata.
- External clinical failures must surface as failures. No “success: true” for failed EHR/FHIR writes or message delivery.
- Webhooks validate Twilio/signature/secret before parsing or acting on body content.
- PHI-capable providers requiring approval/BAA confirmation before production use: Twilio, OpenAI, Anthropic, Firebase, AWS S3, Epic/SMART/FHIR, and any file/message/LLM provider added later.
- Google Sheets/Drive, Redis, metrics, tracing, research feeds, and queue infrastructure should not receive PHI unless explicitly approved for that workflow.

## 13. Commands

```bash
npm install
npm run dev
npm run check
npm run build
npm run start
npm run db:push                     # dev/additive only; not for production-shaped existing tables
npx vitest --config vitest.config.ts
npx vitest --config vitest.config.ts tests/unit/<file>.test.ts
bash scripts/test_harness_all.sh      # if harness dependencies/env are available
npx tsx scripts/gate-prod.ts          # production gate when configured
psql "$DATABASE_URL" -f <verified_migration_file>.sql
```

No dedicated lint script exists in `package.json`; treat `npm run check` as the baseline. Playwright is installed, but this export did not include a Playwright config; run `npx playwright test` only after confirming config and specs. The sanitized export may not type-check because placeholders are redacted.

## 14. Testing and Verification

- Run `npm run check` for any code change unless blocked by sanitized placeholders or unrelated existing errors.
- Run targeted Vitest tests for touched logic. `vitest.config.ts` includes `tests/unit/**`, `tests/integration/**`, and `tests/contracts/**` only; top-level tests are skipped unless run explicitly.
- `tests/tenantIsolation.test.ts` is a placeholder-style documentation test, not proof of tenant isolation. Add a real integration test before claiming tenant safety.
- For auth changes: verify login, refresh/me, protected access, denied roles, CSRF rejection, bearer fallback behavior, and cookie behavior.
- For clinical changes: verify physician gate, safety gate, red flags, deterministic HIGH/CRITICAL non-downgrade, and audit append.
- For WS changes: verify authenticated connection, tenant-scoped broadcast, scrubbed payload, and no vitals unless explicitly enabled.
- For DB changes: verify migration path, schema/types/storage updates, and rollback/compatibility story.

## 15. Known Landmines

- `server/index.ts` may contain duplicate imports/mounts and a raw API response logger; verify before editing startup wiring.
- `client/src/App.tsx` contains many hardcoded routes and some registry mismatches; route validation is not comprehensive.
- Role names are inconsistent across UI and backend files. Align before adding guards.
- Multiple audit implementations exist. Do not mix them accidentally.
- Multiple auth implementations exist. Do not mix principals from one system with middleware from another.
- Root `migrations/` may not exist even though Drizzle config points there. Verify the actual migration pipeline.
- Background loops and workers are numerous. Do not start new autonomous behavior by default.
- Demo/dev credentials, bearer fallback, placeholder secrets, and mock integrations must not leak into production behavior.

## 16. Forbidden Actions

Never expose PHI; bypass auth/roles/CSRF/rate limits; trust client role/clinic/approval values; let AI approve clinical decisions; weaken safety gates, red flags, deterministic risk protection, JWT verification, cookie security, WebSocket auth, tenant scoping, or audit integrity; change audit hash computation casually; delete or mutate audit logs; modify applied migrations; run destructive SQL; hardcode secrets; send patient data to unapproved services; add clinical logic from memory; log prompts/patient payloads; make production behavior depend on simulation/mock data.

## 17. Environment Variables

Never print or commit values. Known names include: `DATABASE_URL`, `APP_JWT_SECRET`, `JWT_SECRET`, `AUTH_JWT_SECRET`, `SESSION_SECRET`, `CSRF_COOKIE_NAME`, `AUTH_COOKIE_NAME`, `ALLOW_BEARER_AUTH_FALLBACK`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `TWILIO_*`, `HARDENING_WEBHOOK_SECRET`, `REDIS_URL`, `UPSTASH_*`, `FIREBASE_*`, `GOOGLE_SHEETS_*`, `AWS_*`, `AUDIT_HMAC_SECRET`, `CLINIC_PASSWORD`, `DEMO_PASSWORD_*`, `AURALYN_WS_ALLOW_VITALS`, `AUDIT_MEMORY_CACHE_SIZE`, `AUDIT_ADVISORY_LOCK_ID`, and integration-specific EHR/FHIR secrets.

## 18. Definition of Done

Done means: the smallest reasonable diff is implemented; relevant source files were read; `npm run check` and targeted tests were run or blockers are stated; inputs are Zod-validated; auth/role/CSRF/rate-limit/tenant rules are preserved; PHI is not leaked; audit events are appended through the canonical path; clinical safety gates remain intact; migrations follow verified policy; frontend routes/API calls/test IDs are updated; no new localStorage tokens, hardcoded secrets, or mock-production paths are introduced; and remaining risk is stated plainly.
