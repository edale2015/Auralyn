# Auralyn April 2026 patch pack

This bundle implements a production-oriented patch set for the highest-risk items from the attached deep evaluation.

## What is included

### Clinical safety
- Population prior-shift support
- Posterior uncertainty fallback below 0.40
- Debate / veto policy with versioned decision matrix
- Additional fast-path presentations hooks
- Blocking `SCORING_SYSTEMS` parse validation
- Immediate Bayesian prior cache invalidation endpoint

### Regulatory / governance
- Part 11 style physician electronic signature service
- `validation_lock` model freeze control for RLHF / promotion
- Immutable audit hooks
- KB consistency daily audit job

### Multi-tenant / data safety
- Tenant-aware job payload enforcement
- Outbox pattern for PostgreSQL -> Firestore sync
- New tenant-aware RLS migrations for audit + queue tables
- PHI scan in sheet-load cycle
- SQLite PHI deprecation guard

### Reliability / scale
- No in-memory fallback for clinical jobs
- PostgreSQL advisory-lock scheduler
- Self-scheduling loops with backpressure
- Worker-thread Digital Twin launcher stub

### Workflow / access
- Multilingual intake translation pipeline
- Override rationale categories + KB deficiency signal generation

## Important note

This is a real implementation pack, but not a literal line-by-line merge into your private repo because the repo was not attached in this conversation. It is designed to be dropped into an existing TypeScript/Express/PostgreSQL codebase with minimal adaptation.

## Suggested merge order
1. Run SQL migrations
2. Wire `tenantContextHardFail` early in Express
3. Replace any `setInterval(...)` loops with `startBackpressuredLoop(...)`
4. Route clinical writes through `createEncounterWithOutbox(...)`
5. Enforce Part 11 signature flow on override endpoints
6. Register admin routes:
   - `POST /api/kb/priors/invalidate`
   - `POST /api/governance/model-freeze`
7. Replace clinical queue fallback with `enqueueClinicalJobOrFail(...)`
8. Add sheet PHI scan to KB load path
9. Run `runKbConsistencyAudit(...)` daily via advisory-lock scheduler

## Files
- `migrations/*.sql`
- `server/**/*.ts`
