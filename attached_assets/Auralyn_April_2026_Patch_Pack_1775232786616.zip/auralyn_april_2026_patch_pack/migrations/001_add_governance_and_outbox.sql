BEGIN;

CREATE TABLE IF NOT EXISTS governance_flags (
  flag_key text PRIMARY KEY,
  flag_value text NOT NULL,
  updated_by text,
  reason text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS outbox_events (
  id bigserial PRIMARY KEY,
  tenant_id uuid NOT NULL,
  aggregate_type text NOT NULL,
  aggregate_id text NOT NULL,
  event_type text NOT NULL,
  payload_json jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  failure_count integer NOT NULL DEFAULT 0,
  last_error text,
  last_attempt_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_outbox_unprocessed ON outbox_events (processed_at, created_at);

CREATE TABLE IF NOT EXISTS electronic_signatures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  actor_id text NOT NULL,
  printed_name text NOT NULL,
  meaning text NOT NULL,
  statement_text text NOT NULL,
  linked_entity_type text NOT NULL,
  linked_entity_id text NOT NULL,
  rationale text,
  signed_at timestamptz NOT NULL,
  signature_digest text NOT NULL,
  metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS physician_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  actor_id text NOT NULL,
  complaint_key text NOT NULL,
  output_fingerprint text NOT NULL,
  ai_disposition text NOT NULL,
  ai_diagnoses_json jsonb NOT NULL,
  reason_category text NOT NULL,
  reason_text text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_physician_overrides_fp ON physician_overrides (tenant_id, output_fingerprint, reason_category);

CREATE TABLE IF NOT EXISTS kb_deficiency_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  output_fingerprint text NOT NULL,
  reason_category text NOT NULL,
  severity text NOT NULL,
  signal_source text NOT NULL,
  details_json jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

COMMIT;
