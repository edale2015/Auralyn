BEGIN;

ALTER TABLE IF EXISTS encounters
  ADD COLUMN IF NOT EXISTS kb_version_hash text;

ALTER TABLE IF EXISTS encounters
  ADD COLUMN IF NOT EXISTS detected_language text;

CREATE TABLE IF NOT EXISTS scoring_system_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version_key text NOT NULL,
  sheet_checksum text NOT NULL,
  parsed_at timestamptz NOT NULL DEFAULT now(),
  is_active boolean NOT NULL DEFAULT false
);

COMMIT;
