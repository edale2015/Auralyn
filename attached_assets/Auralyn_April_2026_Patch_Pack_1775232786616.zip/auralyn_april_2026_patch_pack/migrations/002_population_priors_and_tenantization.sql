BEGIN;

CREATE TABLE IF NOT EXISTS kb_population_priors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  population_flag text NOT NULL,
  diagnosis_key text NOT NULL,
  multiplier numeric(8,4) NOT NULL CHECK (multiplier > 0),
  active boolean NOT NULL DEFAULT true,
  last_validated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE IF EXISTS kb_feature_likelihoods
  ADD COLUMN IF NOT EXISTS tenant_id uuid,
  ADD COLUMN IF NOT EXISTS last_validated_at timestamptz DEFAULT now();

ALTER TABLE IF EXISTS kb_treatment_protocols
  ADD COLUMN IF NOT EXISTS tenant_id uuid;

ALTER TABLE IF EXISTS kb_red_flags
  ADD COLUMN IF NOT EXISTS tenant_id uuid;

ALTER TABLE IF EXISTS queue_jobs
  ADD COLUMN IF NOT EXISTS tenant_id uuid;

ALTER TABLE IF EXISTS audit_hash_chain
  ADD COLUMN IF NOT EXISTS tenant_id uuid;

-- Safe-default RLS
ALTER TABLE IF EXISTS queue_jobs ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'queue_jobs' AND policyname = 'queue_jobs_tenant_isolation'
  ) THEN
    EXECUTE $POL$
      CREATE POLICY queue_jobs_tenant_isolation
      ON queue_jobs
      USING (
        tenant_id::text = current_setting('app.current_tenant_id', true)
      )
      WITH CHECK (
        tenant_id::text = current_setting('app.current_tenant_id', true)
      )
    $POL$;
  END IF;
END $$;

ALTER TABLE IF EXISTS audit_hash_chain ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'audit_hash_chain' AND policyname = 'audit_hash_chain_tenant_isolation'
  ) THEN
    EXECUTE $POL$
      CREATE POLICY audit_hash_chain_tenant_isolation
      ON audit_hash_chain
      USING (
        tenant_id IS NULL OR tenant_id::text = current_setting('app.current_tenant_id', true)
      )
    $POL$;
  END IF;
END $$;

COMMIT;
