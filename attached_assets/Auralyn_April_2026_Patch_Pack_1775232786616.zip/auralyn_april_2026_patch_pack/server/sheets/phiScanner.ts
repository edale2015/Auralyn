const PHI_PATTERNS: RegExp[] = [
  /\b\d{3}-\d{2}-\d{4}\b/,                   // SSN
  /\b(?:mrn|medical record number)\b/i,
  /\b\d{2}\/\d{2}\/\d{4}\b/,                // DOB-ish
  /\b[A-Z][a-z]+ [A-Z][a-z]+\b/,            // naive name heuristic
  /\b(?:address|street|ave|avenue|road|rd|blvd)\b/i,
  /\b(?:patient|pt)\s+[A-Z][a-z]+\b/i,
  /\b\d{10}\b/,                             // phone-ish
  /\b[\w.+-]+@[\w.-]+\.\w+\b/,              // email
];

export function scanStructuredContentForPhi(value: unknown, path = '$'): string[] {
  const hits: string[] = [];

  if (typeof value === 'string') {
    for (const pattern of PHI_PATTERNS) {
      if (pattern.test(value)) hits.push(path);
    }
    return hits;
  }

  if (Array.isArray(value)) {
    value.forEach((v, idx) => hits.push(...scanStructuredContentForPhi(v, `${path}[${idx}]`)));
    return hits;
  }

  if (value && typeof value === 'object') {
    Object.entries(value as Record<string, unknown>).forEach(([k, v]) => {
      hits.push(...scanStructuredContentForPhi(v, `${path}.${k}`));
    });
  }

  return hits;
}
