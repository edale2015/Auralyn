import { scanStructuredContentForPhi } from './phiScanner';
import { appendAuditEvent } from '../governance/audit';

export async function validateSheetPayloadOrThrow(payload: Record<string, unknown>) {
  const hits = scanStructuredContentForPhi(payload);
  if (!hits.length) return;

  await appendAuditEvent({
    tenantId: null,
    actorId: 'system',
    action: 'SHEETS_PHI_DETECTED_BLOCKED',
    entityType: 'kb_sheet_payload',
    payload: { paths: hits.slice(0, 50) },
    justification: 'PHI detected during sheet-cache load; load halted.',
  });

  const err = new Error(`PHI detected in sheet payload at ${hits.slice(0, 10).join(', ')}`);
  (err as any).statusCode = 422;
  throw err;
}
