import type { Request, Response, NextFunction } from 'express';

declare global {
  namespace Express {
    interface Request {
      tenantId?: string;
      actorId?: string;
    }
  }
}

export function tenantContextHardFail(req: Request, res: Response, next: NextFunction) {
  const tenantId = (req.headers['x-tenant-id'] as string | undefined)?.trim()
    || (req as any).auth?.tenantId
    || (req as any).user?.tenantId;

  if (!tenantId) {
    return res.status(400).json({
      error: 'TENANT_CONTEXT_REQUIRED',
      message: 'Tenant context is required before any protected route can execute.',
    });
  }

  req.tenantId = tenantId;
  req.actorId = (req as any).auth?.sub || (req as any).user?.id || 'unknown-actor';
  next();
}
