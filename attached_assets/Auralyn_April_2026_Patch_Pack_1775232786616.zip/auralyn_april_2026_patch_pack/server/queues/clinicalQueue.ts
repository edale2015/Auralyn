import { appendAuditEvent } from '../governance/audit';

interface EnqueueDeps {
  bullQueue?: { add: (name: string, payload: any, opts?: any) => Promise<any> };
  redisHealthy: boolean;
}

export async function enqueueClinicalJobOrFail(
  deps: EnqueueDeps,
  args: { tenantId: string; encounterId: string; payload: Record<string, unknown> }
) {
  if (!args.tenantId) throw new Error('tenantId required for clinical jobs');

  if (!deps.redisHealthy || !deps.bullQueue) {
    await appendAuditEvent({
      tenantId: args.tenantId,
      actorId: null,
      action: 'CLINICAL_QUEUE_REJECTED_REDIS_UNAVAILABLE',
      entityType: 'queue_job',
      entityId: args.encounterId,
      payload: { encounterId: args.encounterId },
    });

    const err = new Error(
      'Temporary processing issue. Please retry in 30 seconds or contact the clinic directly.'
    );
    (err as any).statusCode = 503;
    (err as any).code = 'CLINICAL_QUEUE_UNAVAILABLE';
    throw err;
  }

  return deps.bullQueue.add(
    'clinical-pipeline',
    {
      tenantId: args.tenantId,
      encounterId: args.encounterId,
      ...args.payload,
    },
    { removeOnComplete: 5000, attempts: 5, backoff: { type: 'exponential', delay: 1000 } }
  );
}
