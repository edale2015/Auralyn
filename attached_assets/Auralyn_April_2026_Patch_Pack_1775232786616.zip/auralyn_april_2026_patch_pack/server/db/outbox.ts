import { pool } from './pool';

export async function createEncounterWithOutbox(params: {
  tenantId: string;
  patientId?: string | null;
  complaintKey: string;
  stateJson: Record<string, unknown>;
  firestoreEvent: Record<string, unknown>;
  kbVersionHash: string;
}) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`SELECT set_config('app.current_tenant_id', $1, true)`, [params.tenantId]);

    const encounter = await client.query(
      `INSERT INTO encounters (tenant_id, patient_id, complaint_key, state_json, kb_version_hash)
       VALUES ($1,$2,$3,$4::jsonb,$5)
       RETURNING id, created_at`,
      [params.tenantId, params.patientId ?? null, params.complaintKey, JSON.stringify(params.stateJson), params.kbVersionHash]
    );

    await client.query(
      `INSERT INTO outbox_events (tenant_id, aggregate_type, aggregate_id, event_type, payload_json)
       VALUES ($1, 'encounter', $2, 'ENCOUNTER_CREATED', $3::jsonb)`,
      [params.tenantId, encounter.rows[0].id, JSON.stringify(params.firestoreEvent)]
    );

    await client.query('COMMIT');
    return encounter.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
