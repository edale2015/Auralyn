import { ClinicalPopulationFlags } from '../db/types';

export interface ClinicalStateLike {
  ageYears?: number | null;
  pregnant?: boolean | null;
  immunocompromised?: boolean | null;
  dialysisDependent?: boolean | null;
  conditions?: string[] | null;
  medications?: string[] | null;
}

export function buildPopulationFlags(state: ClinicalStateLike): ClinicalPopulationFlags {
  const conditions = new Set((state.conditions ?? []).map(x => x.toLowerCase()));
  const meds = new Set((state.medications ?? []).map(x => x.toLowerCase()));

  const immunocompromised =
    Boolean(state.immunocompromised) ||
    ['hiv', 'transplant', 'neutropenia', 'active cancer'].some(c => conditions.has(c)) ||
    ['tacrolimus', 'mycophenolate', 'prednisone', 'chemotherapy'].some(m => meds.has(m));

  return {
    immunocompromised,
    elderlyOver75: (state.ageYears ?? 0) >= 75,
    pregnant: Boolean(state.pregnant),
    pediatricUnder2: (state.ageYears ?? 999) < 2,
    dialysisDependent: Boolean(state.dialysisDependent) || conditions.has('dialysis'),
  };
}
