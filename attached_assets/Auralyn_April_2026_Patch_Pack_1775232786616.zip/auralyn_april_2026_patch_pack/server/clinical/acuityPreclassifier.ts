export interface PreclassifierInput {
  sex?: 'male' | 'female' | 'other';
  ageYears?: number;
  complaint: string;
  symptoms: string[];
  history?: string[];
}

export interface PreclassifierResult {
  matchedRule?: string;
  disposition?: 'ER_NOW' | 'URGENT_CARE';
  specificityFlag?: 'absolute_immediate' | 'recheck_in_30m_if_worse';
}

const hasAny = (hay: string[], needles: string[]) =>
  needles.some(n => hay.some(v => v.toLowerCase().includes(n.toLowerCase())));

export function runFastPath(input: PreclassifierInput): PreclassifierResult | null {
  const symptoms = input.symptoms.map(s => s.toLowerCase());
  const history = (input.history ?? []).map(s => s.toLowerCase());
  const complaint = input.complaint.toLowerCase();

  if (
    input.sex === 'female' &&
    complaint.includes('abdominal') &&
    hasAny(symptoms, ['missed period', 'vaginal bleeding', 'shoulder pain', 'syncope'])
  ) {
    return { matchedRule: 'ectopic_pregnancy_rupture', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if (input.sex === 'male' && hasAny(symptoms, ['scrotal pain']) && hasAny(symptoms, ['sudden', 'acute', 'under 6 hours'])) {
    return { matchedRule: 'testicular_torsion', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if (hasAny(symptoms, ['headache', 'severe headache']) && hasAny(symptoms, ['fever']) &&
      hasAny(symptoms, ['neck stiffness', 'photophobia', 'rash', 'altered mental status']) ) {
    return { matchedRule: 'meningitis_or_meningococcal_sepsis', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if (hasAny(symptoms, ['tearing chest pain', 'ripping chest pain', 'tearing back pain', 'ripping back pain']) &&
      hasAny(history, ['hypertension', 'marfan'])) {
    return { matchedRule: 'aortic_dissection', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if (hasAny(symptoms, ['headache']) && hasAny(symptoms, ['nausea', 'vomiting', 'dizziness']) &&
      (hasAny(history, ['enclosed space', 'heater', 'winter', 'heating system']) || hasAny(history, ['multiple people sick']))) {
    return { matchedRule: 'carbon_monoxide_poisoning', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if (hasAny(symptoms, ['sore throat']) && hasAny(symptoms, ['drooling', 'stridor', 'cannot swallow', 'unable to swallow'])) {
    return { matchedRule: 'adult_epiglottitis', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  if ((input.ageYears ?? 99) < 3 && hasAny(symptoms, ['episodic abdominal pain', 'drawing up legs']) &&
      hasAny(symptoms, ['bloody stool', 'vomiting', 'lethargy'])) {
    return { matchedRule: 'pediatric_intussusception', disposition: 'ER_NOW', specificityFlag: 'absolute_immediate' };
  }

  return null;
}
