import { DebateAgentOpinion, DebateResolution, Disposition } from '../db/types';

const POLICY_VERSION = 'AURALYN_DEBATE_POLICY_v2026_04';

const acuityRank: Record<Disposition, number> = {
  HOME_CARE: 1,
  URGENT_CARE: 2,
  PHYSICIAN_REVIEW: 3,
  ER_NOW: 4,
};

export function resolveDebate(opinions: DebateAgentOpinion[]): DebateResolution {
  const safety = opinions.find(o => o.agent === 'safety_veto');
  const hybrid = opinions.find(o => o.agent === 'hybrid');
  const bayesian = opinions.find(o => o.agent === 'bayesian');

  if (!hybrid || !bayesian || !safety) {
    throw new Error('All three debate agent opinions are required');
  }

  if (safety.veto) {
    return {
      policyVersion: POLICY_VERSION,
      outcome: 'VETO_BLOCK',
      finalDisposition: safety.disposition,
      diagnoses: [safety.diagnosisKey].filter(Boolean) as string[],
      requiresPhysicianReview: true,
      rationale: 'Safety veto is absolute and non-overridable by system policy.',
    };
  }

  if (hybrid.disposition !== bayesian.disposition) {
    const winner = acuityRank[hybrid.disposition] >= acuityRank[bayesian.disposition] ? hybrid : bayesian;
    return {
      policyVersion: POLICY_VERSION,
      outcome: 'HIGHER_ACUITY_WINS',
      finalDisposition: winner.disposition,
      diagnoses: [hybrid.diagnosisKey, bayesian.diagnosisKey].filter(Boolean) as string[],
      requiresPhysicianReview: true,
      rationale: 'Disposition disagreement defaults to higher-acuity path.',
    };
  }

  if (hybrid.diagnosisKey !== bayesian.diagnosisKey) {
    return {
      policyVersion: POLICY_VERSION,
      outcome: 'MERGED_DIFFERENTIAL',
      finalDisposition: hybrid.disposition,
      diagnoses: [hybrid.diagnosisKey, bayesian.diagnosisKey].filter(Boolean) as string[],
      requiresPhysicianReview: true,
      rationale: 'Diagnostic disagreement with same disposition returns ranked differential.',
    };
  }

  return {
    policyVersion: POLICY_VERSION,
    outcome: 'CONSENSUS',
    finalDisposition: hybrid.disposition,
    diagnoses: [hybrid.diagnosisKey].filter(Boolean) as string[],
    requiresPhysicianReview: false,
    rationale: 'Hybrid and Bayesian concurred and safety veto abstained.',
  };
}
