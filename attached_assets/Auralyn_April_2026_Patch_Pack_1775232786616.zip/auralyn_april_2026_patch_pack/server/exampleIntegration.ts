/**
 * Example wiring sketch.
 *
 * import express from 'express';
 * import { tenantContextHardFail } from './middleware/tenantContextHardFail';
 * import { priorInvalidationRouter } from './kb/priorInvalidationRoute';
 * import { modelFreezeRouter } from './governance/modelFreeze';
 * import { startBackpressuredLoop } from './jobs/backpressuredLoop';
 * import { runWithAdvisoryLock } from './jobs/advisoryScheduler';
 * import { runKbConsistencyAudit } from './kb/kbConsistencyAudit';
 * import { flushOutbox } from './jobs/outboxWorker';
 *
 * const app = express();
 * app.use(express.json());
 * app.use(tenantContextHardFail);
 * app.use(priorInvalidationRouter);
 * app.use(modelFreezeRouter);
 *
 * startBackpressuredLoop('kb-consistency-audit', 24 * 60 * 60_000, async () => {
 *   await runWithAdvisoryLock('kb-consistency-audit', async () => {
 *     await runKbConsistencyAudit();
 *   });
 * });
 *
 * startBackpressuredLoop('outbox-flush', 5_000, async () => {
 *   await runWithAdvisoryLock('outbox-flush', async () => {
 *     await flushOutbox(firestoreWriter, 100);
 *   });
 * });
 */
