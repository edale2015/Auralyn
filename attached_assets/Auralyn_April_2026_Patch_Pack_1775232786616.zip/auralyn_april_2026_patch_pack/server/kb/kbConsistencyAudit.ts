import { pool } from '../db/pool';
import { appendAuditEvent } from '../governance/audit';

export async function runKbConsistencyAudit() {
  const checks = [
    {
      name: 'complaint_packs',
      domainTable: 'clinical_rules',
      entityType: 'complaint_pack',
    },
    {
      name: 'red_flags',
      domainTable: 'kb_red_flags',
      entityType: 'red_flag',
    },
    {
      name: 'treatment_protocols',
      domainTable: 'kb_treatment_protocols',
      entityType: 'treatment_protocol',
    },
  ];

  const report: any[] = [];

  for (const check of checks) {
    const missing = await pool.query(
      `SELECT d.id
       FROM ${check.domainTable} d
       LEFT JOIN kb_entity_store k ON k.entity_type = $1 AND k.entity_id = d.id::text
       WHERE k.entity_id IS NULL
       LIMIT 500`,
      [check.entityType]
    );

    const orphaned = await pool.query(
      `SELECT k.entity_id
       FROM kb_entity_store k
       LEFT JOIN ${check.domainTable} d ON d.id::text = k.entity_id
       WHERE k.entity_type = $1 AND d.id IS NULL
       LIMIT 500`,
      [check.entityType]
    );

    report.push({
      name: check.name,
      missingCount: missing.rowCount,
      orphanedCount: orphaned.rowCount,
      missingSample: missing.rows.slice(0, 20),
      orphanedSample: orphaned.rows.slice(0, 20),
    });
  }

  const severity = report.some(r => r.missingCount > 0 || r.orphanedCount > 0) ? 'alert' : 'ok';

  await appendAuditEvent({
    tenantId: null,
    actorId: 'system',
    action: 'KB_CONSISTENCY_AUDIT_COMPLETED',
    entityType: 'kb_entity_store',
    payload: { severity, report },
  });

  return { severity, report };
}
