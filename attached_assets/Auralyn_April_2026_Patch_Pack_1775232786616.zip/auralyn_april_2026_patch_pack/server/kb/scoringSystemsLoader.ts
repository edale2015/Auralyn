import { appendAuditEvent } from '../governance/audit';

export interface ScoringSystemRow {
  score_key: string;
  threshold_value: number;
  version?: string;
}

export function parseScoringSystemsOrThrow(rows: unknown[]): ScoringSystemRow[] {
  const parsed: ScoringSystemRow[] = [];

  for (const [idx, row] of rows.entries()) {
    const r = row as any;
    if (!r?.score_key || Number.isNaN(Number(r?.threshold_value))) {
      const err = new Error(`Invalid SCORING_SYSTEMS row at index ${idx}`);
      (err as any).statusCode = 422;
      throw err;
    }
    parsed.push({
      score_key: String(r.score_key),
      threshold_value: Number(r.threshold_value),
      version: r.version ? String(r.version) : undefined,
    });
  }

  return parsed;
}

export async function handleScoringSystemsParseFailure(err: unknown) {
  await appendAuditEvent({
    tenantId: null,
    actorId: 'system',
    action: 'SCORING_SYSTEMS_PARSE_BLOCKING_FAILURE',
    entityType: 'kb_sheet',
    justification: 'Clinical scoring parameters parse failure must halt KB load.',
    payload: { error: String((err as any)?.message ?? err) },
  });
  throw err;
}
