import { Router } from 'express';
import { invalidatePriorCache } from '../clinical/bayesianPriorService';
import { appendAuditEvent } from '../governance/audit';

export const priorInvalidationRouter = Router();

priorInvalidationRouter.post('/api/kb/priors/invalidate', async (req, res, next) => {
  try {
    if (!(req as any).user?.roles?.includes('system_admin')) {
      return res.status(403).json({ error: 'FORBIDDEN' });
    }

    invalidatePriorCache();

    await appendAuditEvent({
      tenantId: null,
      actorId: req.actorId ?? null,
      action: 'KB_PRIOR_CACHE_INVALIDATED',
      entityType: 'kb_prior_cache',
      justification: req.body?.reason ?? 'manual emergency invalidation',
      payload: { sourceIp: req.ip },
    });

    return res.json({ ok: true, invalidated: true });
  } catch (err) {
    next(err);
  }
});
