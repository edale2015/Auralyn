export function assertNoPhiToSqlite(payload: Record<string, unknown>) {
  const deadline = new Date(process.env.SQLITE_PHI_DEPRECATION_DEADLINE ?? '2026-07-02T00:00:00.000Z');
  if (new Date() >= deadline) {
    const err = new Error('SQLITE_PHI_WRITES_FORBIDDEN_AFTER_DEADLINE');
    (err as any).statusCode = 500;
    throw err;
  }

  const serialized = JSON.stringify(payload).toLowerCase();
  const sensitiveTokens = ['dob', 'full_name', 'address', 'ssn', 'patient_name'];
  if (sensitiveTokens.some(t => serialized.includes(t))) {
    const err = new Error('PHI_PAYLOAD_BLOCKED_FROM_SQLITE');
    (err as any).statusCode = 500;
    throw err;
  }
}
