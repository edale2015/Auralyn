import crypto from 'crypto';
import { pool } from '../db/pool';

export interface AuditEventInput {
  tenantId?: string | null;
  actorId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  justification?: string | null;
  payload?: Record<string, unknown>;
}

export async function appendAuditEvent(input: AuditEventInput) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const prev = await client.query(
      `SELECT event_hash FROM audit_hash_chain ORDER BY created_at DESC LIMIT 1`
    );
    const prevHash = prev.rows[0]?.event_hash ?? 'GENESIS';

    const canonical = JSON.stringify({
      tenantId: input.tenantId ?? null,
      actorId: input.actorId ?? null,
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId ?? null,
      justification: input.justification ?? null,
      payload: input.payload ?? {},
      prevHash,
    });

    const eventHash = crypto.createHash('sha256').update(canonical).digest('hex');

    await client.query(
      `INSERT INTO audit_hash_chain
       (tenant_id, actor_id, action, entity_type, entity_id, justification, payload_json, prev_hash, event_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9)`,
      [
        input.tenantId ?? null,
        input.actorId ?? null,
        input.action,
        input.entityType,
        input.entityId ?? null,
        input.justification ?? null,
        JSON.stringify(input.payload ?? {}),
        prevHash,
        eventHash,
      ]
    );

    await client.query('COMMIT');
    return { eventHash, prevHash };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
