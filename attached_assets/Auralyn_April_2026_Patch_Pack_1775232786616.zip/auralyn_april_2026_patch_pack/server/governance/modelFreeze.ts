import { Router } from 'express';
import { pool } from '../db/pool';
import { appendAuditEvent } from './audit';

export const modelFreezeRouter = Router();

modelFreezeRouter.post('/api/governance/model-freeze', async (req, res, next) => {
  try {
    if (!(req as any).user?.roles?.includes('system_admin')) {
      return res.status(403).json({ error: 'FORBIDDEN' });
    }

    const locked = Boolean(req.body?.locked);
    const reason = String(req.body?.reason ?? '').trim();
    if (!reason) return res.status(400).json({ error: 'REASON_REQUIRED' });

    await pool.query(
      `INSERT INTO governance_flags (flag_key, flag_value, updated_by, reason)
       VALUES ('validation_lock', $1, $2, $3)
       ON CONFLICT (flag_key)
       DO UPDATE SET flag_value = EXCLUDED.flag_value, updated_by = EXCLUDED.updated_by, reason = EXCLUDED.reason, updated_at = now()`,
      [locked ? 'true' : 'false', req.actorId ?? 'unknown-actor', reason]
    );

    await appendAuditEvent({
      tenantId: null,
      actorId: req.actorId ?? null,
      action: locked ? 'MODEL_VALIDATION_LOCK_ENABLED' : 'MODEL_VALIDATION_LOCK_DISABLED',
      entityType: 'governance_flag',
      entityId: 'validation_lock',
      justification: reason,
      payload: { locked },
    });

    res.json({ ok: true, validationLock: locked });
  } catch (err) {
    next(err);
  }
});

export async function assertModelPromotionAllowed() {
  const { rows } = await pool.query(
    `SELECT flag_value FROM governance_flags WHERE flag_key = 'validation_lock' LIMIT 1`
  );
  const locked = rows[0]?.flag_value === 'true';
  if (locked) {
    const err = new Error('MODEL_VALIDATION_LOCK_ACTIVE');
    (err as any).statusCode = 423;
    throw err;
  }
}
