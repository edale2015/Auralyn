export interface DeploymentChecklistItem {
  key: string;
  required: boolean;
  passed: boolean;
  notes?: string;
}

export function evaluateProductionChecklist(env: NodeJS.ProcessEnv): DeploymentChecklistItem[] {
  return [
    { key: 'waf_enabled', required: true, passed: env.WAF_ENABLED === 'true' },
    { key: 'private_db_subnets', required: true, passed: env.DB_PRIVATE_SUBNETS === 'true' },
    { key: 'tls_1_2_plus', required: true, passed: env.TLS_MIN_VERSION === '1.2' || env.TLS_MIN_VERSION === '1.3' },
    { key: 'hipaa_baa_openai_api_only', required: true, passed: env.OPENAI_USE_ASSISTANTS_API !== 'true' },
    { key: 'signed_baas_complete', required: true, passed: env.SIGNED_BAAS_COMPLETE === 'true' },
    { key: 'audit_retention_7_years', required: true, passed: Number(env.AUDIT_RETENTION_DAYS ?? 0) >= 2555 },
    { key: 'immutable_log_sink', required: true, passed: env.IMMUTABLE_LOG_SINK === 's3_write_once' },
    { key: 'pen_test_complete', required: true, passed: env.PEN_TEST_COMPLETE === 'true' },
  ];
}
