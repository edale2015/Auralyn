import { Worker } from 'worker_threads';
import path from 'path';

export function startDigitalTwinWorker() {
  const workerPath = path.join(__dirname, 'digitalTwinWorkerThread.js');
  const worker = new Worker(workerPath);
  worker.on('error', (err) => {
    console.error('[digital-twin-worker]', err);
  });
  worker.on('exit', (code) => {
    if (code !== 0) console.error(`[digital-twin-worker] exited with code ${code}`);
  });
  return worker;
}
