import { pool } from '../db/pool';

export interface FirestoreWriter {
  writeEvent: (payload: Record<string, unknown>) => Promise<void>;
}

export async function flushOutbox(firestore: FirestoreWriter, batchSize = 100) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `SELECT id, payload_json
       FROM outbox_events
       WHERE processed_at IS NULL
       ORDER BY created_at ASC
       LIMIT $1
       FOR UPDATE SKIP LOCKED`,
      [batchSize]
    );

    for (const row of rows) {
      try {
        await firestore.writeEvent(row.payload_json);
        await client.query(
          `UPDATE outbox_events SET processed_at = now(), failure_count = 0, last_error = NULL WHERE id = $1`,
          [row.id]
        );
      } catch (err: any) {
        await client.query(
          `UPDATE outbox_events
           SET failure_count = failure_count + 1, last_error = $2, last_attempt_at = now()
           WHERE id = $1`,
          [row.id, String(err?.message ?? err)]
        );
      }
    }

    await client.query('COMMIT');
    return { processed: rows.length };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
