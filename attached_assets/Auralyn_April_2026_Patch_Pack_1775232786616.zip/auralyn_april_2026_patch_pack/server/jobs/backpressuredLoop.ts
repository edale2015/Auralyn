export function startBackpressuredLoop(
  name: string,
  intervalMs: number,
  task: () => Promise<void>,
  onError: (err: unknown) => void = console.error
) {
  let stopped = false;

  async function tick() {
    if (stopped) return;
    try {
      await task();
    } catch (err) {
      onError({ loop: name, err });
    } finally {
      if (!stopped) setTimeout(tick, intervalMs);
    }
  }

  void tick();

  return {
    stop() {
      stopped = true;
    },
  };
}
