export interface TranslationProvider {
  detectLanguage(text: string): Promise<string>;
  translate(text: string, source: string, target: string): Promise<string>;
}

const NYC_MIN_LANGS = new Set(['en', 'es', 'zh', 'bn', 'ru', 'ar', 'ht', 'ko']);

export async function normalizeInboundText(
  provider: TranslationProvider,
  rawText: string
): Promise<{ detectedLanguage: string; normalizedEnglishText: string }> {
  const detectedLanguage = await provider.detectLanguage(rawText);
  const lang = NYC_MIN_LANGS.has(detectedLanguage) ? detectedLanguage : 'en';

  if (lang === 'en') {
    return { detectedLanguage: 'en', normalizedEnglishText: rawText };
  }

  const normalizedEnglishText = await provider.translate(rawText, lang, 'en');
  return { detectedLanguage: lang, normalizedEnglishText };
}

export async function localizeOutboundText(
  provider: TranslationProvider,
  englishText: string,
  targetLanguage: string
): Promise<string> {
  if (!targetLanguage || targetLanguage === 'en') return englishText;
  return provider.translate(englishText, 'en', targetLanguage);
}
