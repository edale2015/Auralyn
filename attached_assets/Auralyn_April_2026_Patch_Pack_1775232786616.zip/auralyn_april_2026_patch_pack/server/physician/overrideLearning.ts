import { pool } from '../db/pool';
import { StructuredOverrideReason } from '../db/types';
import { appendAuditEvent } from '../governance/audit';

export async function recordOverrideAndMaybeSignal(params: {
  tenantId: string;
  actorId: string;
  complaintKey: string;
  aiDisposition: string;
  aiDiagnoses: string[];
  reason: StructuredOverrideReason;
}) {
  const outputFingerprint = `${params.complaintKey}|${params.aiDisposition}|${params.aiDiagnoses.slice().sort().join(',')}`;

  await pool.query(
    `INSERT INTO physician_overrides
     (tenant_id, actor_id, complaint_key, output_fingerprint, ai_disposition, ai_diagnoses_json, reason_category, reason_text)
     VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7,$8)`,
    [
      params.tenantId,
      params.actorId,
      params.complaintKey,
      outputFingerprint,
      params.aiDisposition,
      JSON.stringify(params.aiDiagnoses),
      params.reason.category,
      params.reason.freeText ?? null,
    ]
  );

  const samePhysician = await pool.query(
    `SELECT count(*)::int AS c
     FROM physician_overrides
     WHERE tenant_id = $1 AND actor_id = $2 AND output_fingerprint = $3 AND reason_category = $4`,
    [params.tenantId, params.actorId, outputFingerprint, params.reason.category]
  );

  const crossPhysician = await pool.query(
    `SELECT count(DISTINCT actor_id)::int AS c
     FROM physician_overrides
     WHERE tenant_id = $1 AND output_fingerprint = $2 AND reason_category = $3`,
    [params.tenantId, outputFingerprint, params.reason.category]
  );

  if (samePhysician.rows[0].c >= 3 || crossPhysician.rows[0].c >= 3) {
    await pool.query(
      `INSERT INTO kb_deficiency_signals
       (tenant_id, output_fingerprint, reason_category, severity, signal_source, details_json)
       VALUES ($1,$2,$3,$4,$5,$6::jsonb)`,
      [
        params.tenantId,
        outputFingerprint,
        params.reason.category,
        crossPhysician.rows[0].c >= 3 ? 'high' : 'medium',
        crossPhysician.rows[0].c >= 3 ? 'cross_physician_consensus' : 'single_physician_repeat',
        JSON.stringify({
          complaintKey: params.complaintKey,
          aiDisposition: params.aiDisposition,
          aiDiagnoses: params.aiDiagnoses,
        }),
      ]
    );

    await appendAuditEvent({
      tenantId: params.tenantId,
      actorId: params.actorId,
      action: 'KB_DEFICIENCY_SIGNAL_CREATED',
      entityType: 'kb_deficiency_signal',
      justification: params.reason.freeText ?? params.reason.category,
      payload: {
        outputFingerprint,
        category: params.reason.category,
        samePhysicianCount: samePhysician.rows[0].c,
        crossPhysicianCount: crossPhysician.rows[0].c,
      },
    });
  }
}
