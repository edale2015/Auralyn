import fs from 'node:fs'; import path from 'node:path'; import { exampleEdges, exampleNodes } from '../server/data/exampleClinicalGraphData';
const outPath = path.join(process.cwd(), 'server', 'data', 'clinical_reasoning_graph.json');
fs.writeFileSync(outPath, JSON.stringify({ nodes: exampleNodes, edges: exampleEdges }, null, 2));
console.log(`Wrote ${outPath}`);
