export type Disposition = 'ER_NOW' | 'URGENT_SAME_DAY' | 'OFFICE_24H' | 'VIDEO_VISIT' | 'HOME_CARE' | 'NEEDS_WORKUP' | 'NEEDS_PHYSICIAN_REVIEW' | 'BLOCK';
export type SeverityLevel = 'low' | 'moderate' | 'high' | 'critical';
export type SupervisorDecision = 'PASS' | 'ESCALATE' | 'BLOCK';
export interface VitalSigns { heartRate?: number; respiratoryRate?: number; systolicBP?: number; diastolicBP?: number; temperatureC?: number; spo2?: number; }
export interface PatientProfile { age?: number; sex?: 'male' | 'female' | 'intersex' | 'unknown'; pregnant?: boolean; weightKg?: number; comorbidities?: string[]; medications?: string[]; allergies?: string[]; labs?: Record<string, string | number | boolean | null | undefined>; }
export interface DifferentialScore { diagnosis: string; score: number; rationale?: string[]; source?: string; }
export interface QuestionScore { questionId: string; score: number; reason?: string; }
export interface BrainCaseInput { caseId: string; complaint: string; symptoms: string[]; negatives?: string[]; durationHours?: number; timeline?: string[]; vitals?: VitalSigns; profile?: PatientProfile; answeredQuestions?: string[]; unansweredQuestions?: string[]; priorDifferentials?: DifferentialScore[]; metadata?: Record<string, unknown>; }
export interface MemoryCase { caseId: string; complaint: string; symptoms: string[]; finalDiagnosis?: string; finalDisposition?: Disposition; outcome?: string; createdAt: string; }
export interface MemoryMatch { caseId: string; score: number; complaint: string; finalDiagnosis?: string; finalDisposition?: Disposition; }
export interface ContradictionFinding { code: string; severity: 'error' | 'warning'; message: string; }
export interface SafetyGuardResult { triggered: boolean; ruleId?: string; disposition?: Disposition; reason?: string; }
export interface UncertaintyResult { entropy: number; confidence: number; shouldAskMore: boolean; }
export interface GovernanceSignals { severityLevel?: SeverityLevel; completenessPassed?: boolean; contradictionErrors?: number; protocolVarianceMajor?: boolean; driftMajor?: boolean; guidelineIssues?: string[]; supervisorDecision?: SupervisorDecision; }
export interface BrainOutput { normalizedSymptoms: string[]; contradictionFindings: ContradictionFinding[]; safetyGuard: SafetyGuardResult; memoryMatches: MemoryMatch[]; graphDifferentials: DifferentialScore[]; bayesianDifferentials: DifferentialScore[]; aggregatedDifferentials: DifferentialScore[]; nextBestQuestions: QuestionScore[]; uncertainty: UncertaintyResult; severityLevel: SeverityLevel; disposition: Disposition; tests: string[]; treatments: string[]; precautions: string[]; notes: string[]; }
export interface CoordinationOutput { ok: boolean; output: BrainOutput; governanceSignals: GovernanceSignals; }
export interface GraphNode { id: string; type: 'complaint' | 'symptom' | 'diagnosis' | 'test' | 'treatment' | 'red_flag' | 'question'; label: string; metadata?: Record<string, unknown>; }
export interface GraphEdge { from: string; to: string; relation: string; weight?: number; metadata?: Record<string, unknown>; }
