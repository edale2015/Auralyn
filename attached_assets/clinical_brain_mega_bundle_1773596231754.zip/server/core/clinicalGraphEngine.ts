import type { GraphEdge, GraphNode } from '../../shared/clinicalEngineTypes';
export class ClinicalGraphEngine {
  private nodes = new Map<string, GraphNode>(); private edges: GraphEdge[] = [];
  addNode(node: GraphNode): void { this.nodes.set(node.id, node); }
  addEdge(edge: GraphEdge): void { this.edges.push(edge); }
  scoreDiagnoses(symptoms: string[]): Record<string, number> {
    const scores: Record<string, number> = {};
    for (const symptom of symptoms) {
      const symptomNode = [...this.nodes.values()].find((n) => n.type === 'symptom' && n.label === symptom); if (!symptomNode) continue;
      for (const edge of this.edges.filter((e) => e.from === symptomNode.id && e.relation === 'supports_dx')) {
        const dx = this.nodes.get(edge.to); if (!dx) continue; scores[dx.label] = (scores[dx.label] || 0) + (edge.weight || 1);
      }
    }
    return scores;
  }
  getTests(diagnoses: string[]): string[] { const out = new Set<string>(); diagnoses.forEach((dxLabel) => { const dxNode = [...this.nodes.values()].find((n) => n.type === 'diagnosis' && n.label === dxLabel); if (!dxNode) return; this.edges.filter((e) => e.from === dxNode.id && e.relation === 'suggests_test').forEach((e) => { const n = this.nodes.get(e.to); if (n) out.add(n.label); }); }); return [...out]; }
  getTreatments(diagnoses: string[]): string[] { const out = new Set<string>(); diagnoses.forEach((dxLabel) => { const dxNode = [...this.nodes.values()].find((n) => n.type === 'diagnosis' && n.label === dxLabel); if (!dxNode) return; this.edges.filter((e) => e.from === dxNode.id && e.relation === 'suggests_treatment').forEach((e) => { const n = this.nodes.get(e.to); if (n) out.add(n.label); }); }); return [...out]; }
  toJSON() { return { nodes: [...this.nodes.values()], edges: this.edges }; }
  static fromJSON(json: { nodes: GraphNode[]; edges: GraphEdge[] }): ClinicalGraphEngine { const g = new ClinicalGraphEngine(); json.nodes.forEach((n) => g.addNode(n)); json.edges.forEach((e) => g.addEdge(e)); return g; }
}
