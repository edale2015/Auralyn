export function runCoverageGapEngine(existingComplaints:string[], sheetComplaints:string[]): string[] { const set = new Set(existingComplaints); return sheetComplaints.filter((c)=>!set.has(c)); }
