import { ClinicalGraphEngine } from '../core/clinicalGraphEngine';
import { exampleEdges, exampleNodes } from './exampleClinicalGraphData';
const graph = new ClinicalGraphEngine(); exampleNodes.forEach((n) => graph.addNode(n)); exampleEdges.forEach((e) => graph.addEdge(e));
export { graph as clinicalGraph };
