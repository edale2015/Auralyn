
CREATE TABLE clinical_documents (
  id SERIAL PRIMARY KEY,
  title TEXT,
  source TEXT,
  uploaded_at TIMESTAMP DEFAULT now()
);

CREATE TABLE document_nodes (
  id TEXT PRIMARY KEY,
  document_id INT,
  title TEXT,
  start_page INT,
  end_page INT,
  summary TEXT,
  content TEXT
);

CREATE TABLE reasoning_queries (
  id SERIAL PRIMARY KEY,
  document_id INT,
  question TEXT,
  selected_node TEXT,
  answer TEXT,
  created_at TIMESTAMP DEFAULT now()
);
