
const OpenAI = require("openai");
const db = require("../db");

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class ClinicalEngine {
  async answer(documentId, question) {
    const res = await db("SELECT * FROM document_nodes WHERE document_id=$1", [documentId]);
    const nodes = res.rows;

    const node = nodes[0];

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Answer clinically and precisely." },
        { role: "user", content: node.content + "\nQuestion: " + question }
      ]
    });

    const answer = completion.choices[0].message.content;

    await db(
      "INSERT INTO reasoning_queries(document_id, question, selected_node, answer) VALUES($1,$2,$3,$4)",
      [documentId, question, node.id, answer]
    );

    return answer;
  }
}

module.exports = ClinicalEngine;
