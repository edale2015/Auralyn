
const fs = require("fs");
const pdfParse = require("pdf-parse");

class PageIndexBuilder {
  async buildTreeFromPDF(path) {
    const buffer = fs.readFileSync(path);
    const data = await pdfParse(buffer);

    const pages = data.text.split("\n\n");
    const nodes = [];

    pages.forEach((page, i) => {
      nodes.push({
        node_id: "node_" + i,
        title: page.substring(0, 50),
        start_page: i,
        end_page: i,
        content: page
      });
    });

    return nodes;
  }
}

module.exports = PageIndexBuilder;
