import React, { useEffect, useState } from "react";

type TelemetryMap = Record<string, Array<{ ts: number; risk?: number; urgency?: string; disagreement?: number; disposition?: string }>>;

export default function HierarchicalCouncilDashboard() {
  const [result, setResult] = useState<any>(null);
  const [telemetry, setTelemetry] = useState<TelemetryMap>({});

  async function runSample() {
    const res = await fetch("/api/council/hierarchical/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patient: {
          patientId: "P-1001",
          complaint: "chest pain and fever",
          symptoms: ["chest pain", "fever"],
          riskFactors: ["CAD", "diabetes"],
          vitals: { hr: 126, spo2: 91, temp: 39.1, systolic: 88, diastolic: 54, rr: 30 },
          labs: { troponin: 0.12, lactate: 3.1, wbc: 18 },
          exam: { chestPain: true, dyspnea: true, cough: true, alteredMentalStatus: false },
          tests: { ecgStElevation: false, infiltrateOnCxr: true },
        },
      }),
    });
    setResult(await res.json());
  }

  async function loadTelemetry() {
    const res = await fetch("/api/council/hierarchical/telemetry");
    setTelemetry(await res.json());
  }

  useEffect(() => {
    loadTelemetry();
    const t = setInterval(loadTelemetry, 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ padding: 16, fontFamily: "sans-serif" }}>
      <h2>Hierarchical Council Dashboard</h2>
      <button onClick={runSample}>Run sample case</button>

      {result && (
        <>
          <h3>Final decision</h3>
          <div><b>Disposition:</b> {result.finalDecision.disposition}</div>
          <div><b>Action:</b> {result.finalDecision.action}</div>
          <div><b>Rationale:</b> {result.finalDecision.rationale}</div>
          <div><b>Master risk:</b> {result.masterConsensus.risk.toFixed(2)}</div>
          <div><b>Master disagreement:</b> {result.masterConsensus.disagreement.toFixed(2)}</div>

          <h3>Specialist councils</h3>
          {result.specialistCouncils.map((c: any) => (
            <div key={c.council} style={{ border: "1px solid #ddd", padding: 12, marginTop: 8 }}>
              <div><b>{c.council}</b> | risk {c.consensus.risk.toFixed(2)} | urgency {c.consensus.urgency}</div>
              <div><b>Recommendation:</b> {String(c.finalDecision.recommendation || c.consensus.recommendation || "n/a")}</div>
              <div><b>Debate:</b></div>
              <ul>
                {c.debate.map((d: any, i: number) => (
                  <li key={i}>{d.from} → {d.to}: {d.critique}</li>
                ))}
              </ul>
              <div><b>Reasoning paths:</b></div>
              <ul>
                {c.reasoningPaths.map((p: any, i: number) => (
                  <li key={i}>{p.path.join(" → ")} | score {p.score.toFixed(2)}</li>
                ))}
              </ul>
            </div>
          ))}

          <h3>Cross-council debate</h3>
          <ul>
            {result.crossCouncilDebate.map((d: any, i: number) => (
              <li key={i}>{d.from} → {d.to}: {d.critique}</li>
            ))}
          </ul>

          <h3>Master reasoning paths</h3>
          <ul>
            {result.masterReasoningPaths.map((p: any, i: number) => (
              <li key={i}>{p.path.join(" → ")} | score {p.score.toFixed(2)}</li>
            ))}
          </ul>
        </>
      )}

      <h3>Telemetry</h3>
      {Object.entries(telemetry).map(([council, entries]) => (
        <div key={council} style={{ marginBottom: 8 }}>
          <b>{council}</b>:{" "}
          {entries.slice(0, 10).map((e, idx) => (
            <span key={idx} title={`risk=${e.risk ?? "n/a"} disagreement=${e.disagreement ?? "n/a"} disposition=${e.disposition ?? "n/a"}`} style={{ marginRight: 4 }}>
              {(e.risk ?? 0) > 0.8 ? "🔴" : (e.risk ?? 0) > 0.5 ? "🟠" : "🟢"}
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}
