from flask import Flask, request, jsonify
import os
import numpy as np

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    payload = request.json or {}
    features = payload.get("features", [])
    if not features:
        return jsonify({"risk": 0.2})
    arr = np.array(features, dtype=float)
    score = float(np.tanh(np.maximum(arr.mean(), 0.0) / 10.0))
    return jsonify({"risk": max(0.0, min(1.0, score))})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
