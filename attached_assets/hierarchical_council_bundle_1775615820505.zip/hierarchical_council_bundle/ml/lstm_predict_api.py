from flask import Flask, request, jsonify
import numpy as np

app = Flask(__name__)

@app.route("/predict-seq", methods=["POST"])
def predict_seq():
    payload = request.json or {}
    seq = payload.get("sequence", [])
    if not seq:
        return jsonify({"risk": 0.25})
    arr = np.array(seq, dtype=float)
    trend = arr[-1].mean() - arr[0].mean() if len(arr) > 1 else arr.mean()
    score = 1 / (1 + np.exp(-trend / 10.0))
    return jsonify({"risk": float(max(0.0, min(1.0, score)))})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
