# Hierarchical Multi-Agent Clinical Council Bundle

This bundle adds specialist sub-councils and a master council on top of the existing clinical brain.

Included:
- Cardiology, Infectious Disease, and ICU specialist councils
- Debate and consensus engines
- Reasoning-graph integration
- Control Tower telemetry endpoints
- REST API route for hierarchical council execution
- React dashboard page
- Replit and AWS-friendly container config

Assumptions:
- Existing Express server and React client
- Redis available for telemetry and optional memory/bandit state
- Existing ML services are available or mocked by the specialist agents in this bundle

Wire-in:
1. Register the `councilRoutes` router under `/api/council`.
2. Add `HierarchicalCouncilDashboard` to your router/menu.
3. If you already have a `ClinicalGraphEngine`, replace the included one with yours.
4. Deploy using `docker-compose.yml` locally, then the same images to Replit or AWS ECS/Fargate.
