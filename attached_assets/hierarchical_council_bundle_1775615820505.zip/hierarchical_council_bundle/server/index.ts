import express from "express";
import councilRoutes from "./routes/councilRoutes";

const app = express();
app.use(express.json());
app.use("/api/council", councilRoutes);

app.get("/healthz", (_req, res) => {
  res.json({ ok: true, service: "hierarchical-council-api" });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Hierarchical council API listening on ${port}`);
});
