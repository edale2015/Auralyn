import express from "express";
import { hierarchicalCouncil } from "../agents/hierarchicalCouncil";
import { getCouncilTelemetry } from "../controlTower/councilTelemetry";
import type { AgentInput } from "../agents/types";

const router = express.Router();

router.post("/hierarchical/run", async (req, res, next) => {
  try {
    const body = req.body || {};
    const input: AgentInput = {
      traceId: body.traceId || `trace_${Date.now()}`,
      council: "master",
      patient: body.patient || {
        patientId: "unknown",
        complaint: "undifferentiated",
      },
      features: body.features || [],
      sequence: body.sequence || [],
      mode: body.mode || "balanced",
    };

    const result = await hierarchicalCouncil.run(input);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get("/hierarchical/telemetry", async (_req, res, next) => {
  try {
    const telemetry = await getCouncilTelemetry();
    res.json(telemetry);
  } catch (err) {
    next(err);
  }
});

export default router;
