import Redis from "ioredis";

const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379");
const PREFIX = "telemetry:council";

export async function logCouncilTelemetry(council: string, payload: Record<string, unknown>): Promise<void> {
  const key = `${PREFIX}:${council}`;
  await redis.lpush(key, JSON.stringify({ ts: Date.now(), ...payload }));
  await redis.ltrim(key, 0, 199);
}

export async function getCouncilTelemetry(): Promise<Record<string, unknown[]>> {
  const keys = await redis.keys(`${PREFIX}:*`);
  const result: Record<string, unknown[]> = {};
  for (const key of keys) {
    const council = key.split(":")[2];
    const entries = await redis.lrange(key, 0, 49);
    result[council] = entries.map(v => JSON.parse(v));
  }
  return result;
}
