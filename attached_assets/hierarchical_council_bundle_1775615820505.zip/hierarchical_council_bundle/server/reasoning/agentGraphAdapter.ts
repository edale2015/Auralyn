import { ClinicalGraphEngine } from "./clinicalGraphEngine";
import type { AgentOutput, PatientContext } from "../agents/types";

export class AgentGraphAdapter {
  constructor(private graph: ClinicalGraphEngine, private startNodes: (ctx: PatientContext) => string[]) {}

  buildPaths(outputs: AgentOutput[], context: PatientContext) {
    const starts = this.startNodes(context);
    const paths = this.graph.traverse(starts, context);
    const confidenceBonus = outputs.reduce((s, o) => s + o.confidence * 0.05, 0);
    return paths.map(p => ({ ...p, score: p.score + confidenceBonus })).slice(0, 3);
  }
}
