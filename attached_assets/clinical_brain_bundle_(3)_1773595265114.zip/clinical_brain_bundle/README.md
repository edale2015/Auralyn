# Clinical Brain Bundle

This is a paste-ready TypeScript starter bundle for the engines you listed.

## Included
- Clinical brain orchestrator
- Memory retrieval + storage
- Symptom normalization
- Contradiction engine
- Safety guard
- Similarity engine
- Bayesian differential engine
- Knowledge graph engine + sample graph data
- Evidence aggregator
- Uncertainty engine
- Complaint completeness
- Guideline adherence
- Temporal progression
- Risk stratification
- Tests, treatments, precautions
- Medication safety
- Test yield
- Physician feedback learning
- Protocol variance
- Severity scoring
- Cross complaint router
- Diagnostic drift
- Disposition calibration
- Physician review packet
- Supervisor engine
- Coverage gap + expansion engine
- Domain generalization engine
- Telepresence orchestrator
- Barrel exports

## Wiring suggestion
1. Drop files into your existing `server/core`, `server/data`, `server/services/telepresence`, `server/scripts`, and `shared` folders.
2. Import `runClinicalBrainEngine` or `runClinicalIntelligenceCoordinationLayer` into your pipeline.
3. Map your existing case state into `BrainCaseInput`.
4. Feed the resulting `BrainOutput` back into your case/session state.
5. Replace the sample graph data with your Google Sheet exports using `buildClinicalReasoningGraph.ts`.

## Honest note
Because I do not have your exact Replit repo files in this chat, this bundle is designed to be highly compatible and easy to adapt, but it may need light interface renaming to match your existing state objects.
