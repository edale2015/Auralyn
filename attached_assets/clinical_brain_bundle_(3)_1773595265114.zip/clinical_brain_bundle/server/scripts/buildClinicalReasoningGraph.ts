/**
 * Minimal graph builder placeholder.
 * Replace CSV_PATHS with your real sheet exports and extend parsing as needed.
 */
import fs from 'fs';
import path from 'path';
import { CLINICAL_GRAPH_EDGES } from '../data/clinicalKnowledgeGraph';

const OUT = path.join(process.cwd(), 'clinical_reasoning_graph.json');
fs.writeFileSync(OUT, JSON.stringify({ edges: CLINICAL_GRAPH_EDGES }, null, 2));
console.log(`Wrote ${CLINICAL_GRAPH_EDGES.length} edges to ${OUT}`);
