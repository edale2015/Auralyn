export interface TelepresencePlan {
  roomMode: 'wall_screen' | 'robot_assist' | 'hybrid';
  devices: string[];
  safetyChecklist: string[];
}

export function buildTelepresencePlan(complaint: string): TelepresencePlan {
  const devices = ['wall_screen', 'mobile_camera'];
  if (['ear_pain', 'sore_throat'].includes(complaint)) devices.push('otoscope_or_oral_camera');
  if (['chest_pain', 'shortness_of_breath'].includes(complaint)) devices.push('pulse_ox', 'ecg');
  if (['std_exposure', 'fever'].includes(complaint)) devices.push('vitals_station');
  return {
    roomMode: devices.length > 3 ? 'hybrid' : 'wall_screen',
    devices,
    safetyChecklist: [
      'Confirm patient identity and location.',
      'Confirm emergency backup plan if deterioration occurs.',
      'Verify device sterilization and operator training.',
      'Escalate to in-person or ER for unstable vitals or red flags.'
    ]
  };
}
