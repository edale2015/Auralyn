import { BrainCaseInput, BrainOutput } from '../../shared/clinicalEngineTypes';
import { runClinicalIntelligenceCoordinationLayer } from './clinicalIntelligenceCoordinationLayer';

export function runClinicalBrainEngine(input: BrainCaseInput): BrainOutput {
  return runClinicalIntelligenceCoordinationLayer(input);
}
