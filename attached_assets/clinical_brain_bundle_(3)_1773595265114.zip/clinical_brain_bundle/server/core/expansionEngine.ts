import { runCoverageGapEngine } from './coverageGapEngine';

export function runExpansionEngine(existingComplaints: string[], sheetCandidates: string[]): { nextWave: string[]; rationale: string } {
  const gaps = runCoverageGapEngine(existingComplaints, sheetCandidates);
  return {
    nextWave: gaps.slice(0, 25),
    rationale: `Found ${gaps.length} uncovered complaint candidates from sheet data.`
  };
}
