export function runDomainGeneralizationEngine<T extends Record<string, unknown>>(items: T[], target: T, keys: Array<keyof T>): Array<{ item: T; similarity: number }> {
  const score = (a: T, b: T) => {
    let match = 0;
    for (const k of keys) if (String(a[k]) === String(b[k])) match += 1;
    return match / Math.max(1, keys.length);
  };
  return items.map((item) => ({ item, similarity: score(item, target) })).sort((a, b) => b.similarity - a.similarity);
}
