import { RankedItem } from '../../shared/clinicalEngineTypes';

export function runTestYieldEngine(differentials: RankedItem[], tests: RankedItem[]): RankedItem[] {
  const top = new Set(differentials.slice(0, 3).map((d) => d.id));
  return tests.map((t) => ({ ...t, metadata: { yield: top.has('acute_coronary_syndrome') && ['ecg', 'troponin'].includes(t.id) ? 'high' : t.score > 0.85 ? 'high' : t.score > 0.7 ? 'moderate' : 'low' } }));
}
