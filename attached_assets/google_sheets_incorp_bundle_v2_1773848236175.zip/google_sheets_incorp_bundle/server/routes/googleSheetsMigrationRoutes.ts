import express from "express";
import {
  ensureCanonicalTabs,
  verifyCanonicalTabs,
  dryRunMigration,
  applyMigration,
  runQaChecks,
  cutoverToCanonicalOnly,
} from "../engines/googleSheetsMigrationEngine";

const router = express.Router();

router.post("/ensure-canonical-tabs", async (_req, res) => {
  try {
    const result = await ensureCanonicalTabs();
    const verification = await verifyCanonicalTabs();
    res.json({ ok: true, result, verification });
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

router.post("/dry-run", async (req, res) => {
  try {
    const result = await dryRunMigration(req.body?.sources || {});
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

router.post("/apply", async (req, res) => {
  try {
    const result = await applyMigration(req.body?.sources || {});
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

router.post("/run-qa", async (_req, res) => {
  try {
    const result = await runQaChecks();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

router.post("/cutover", async (_req, res) => {
  try {
    const result = await cutoverToCanonicalOnly();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

export default router;
