# Google Sheets Incorporation Bundle

This bundle implements the 5-step incorporation path:

1. Turn on Google Sheets as the repository driver
2. Create and verify canonical tabs
3. Bulk import / migrate into canonical tabs
4. Run validation + simulator QA
5. Cut over to canonical-tabs-only mode

## Environment variables

```bash
PACK_REPO_DRIVER=google_sheets
PACKS_SPREADSHEET_ID=your_google_sheet_id
GOOGLE_APPLICATION_CREDENTIALS=/absolute/path/to/service-account.json
PACKS_CANONICAL_ONLY=false
```

## Canonical tabs expected

- Symptom_Packs
- Pack_Questions
- Modifier_Packs
- Clinician_Algorithms
- Plan_Templates
- Pack_Audit_Log
- Import_Mapping_Log
- Import_Errors

## Route registration

Add to `server/index.ts`:

```ts
import googleSheetsMigrationRoutes from "./routes/googleSheetsMigrationRoutes";
app.use("/api/google-sheets-migration", googleSheetsMigrationRoutes);
```

## Key routes

### 1) Verify canonical tabs
`POST /api/google-sheets-migration/ensure-canonical-tabs`

### 2) Dry run migration
`POST /api/google-sheets-migration/dry-run`

Body example:

```json
{
  "sources": {
    "symptomPackTab": "Symptom_Packs",
    "questionTab": "Pack_Questions",
    "modifierTab": "Modifier_Packs",
    "algorithmTab": "Clinician_Algorithms"
  }
}
```

### 3) Apply migration
`POST /api/google-sheets-migration/apply`

### 4) Run QA
`POST /api/google-sheets-migration/run-qa`

### 5) Cut over
`POST /api/google-sheets-migration/cutover`

This sets `PACKS_CANONICAL_ONLY=true` in the returned status payload. Persisting env changes depends on your hosting setup.

## Notes

- This bundle assumes your canonical tabs are either already populated or are the target of your import.
- Legacy raw tabs still need an explicit mapper if their columns differ from the canonical schema.
- A starter endocrinology expansion file is included in `server/config/systemContent/endocrinologyFullRows.ts`.
