# New Complaint Pathway Skill
# Type: Code Templates & Scaffolding
#
# DESCRIPTION (for Claude Code skill discovery):
# Scaffolds a complete new urgent care complaint pathway for Auralyn.
# Includes: ontology registration, KB rules stub, LR table for Bayesian updater,
# knowledge graph nodes, follow-up protocol (if applicable), drift canary,
# and all required wiring. Use when adding a new complaint type that doesn't
# exist in COMPLAINT_ONTOLOGY.
# Trigger: "add complaint", "new pathway", "new complaint type", "add [condition] pathway"

## What Gets Created

A complete complaint pathway requires changes to 6 files and 1 new file.
This skill scaffolds all of them.

### Files to Modify

1. `server/ontology/clinicalOntology.ts` — add to COMPLAINT_ONTOLOGY
2. `server/reasoning/bayesianConfidenceUpdater.ts` — add LR table + priors
3. `server/reasoning/clinicalKnowledgeGraph.ts` — add graph nodes + edges
4. `server/harness/driftCheck.ts` — add 1-2 drift canaries
5. `server/followup/followUpService.ts` — add follow-up protocol (if chronic/follow-up eligible)
6. `server/reasoning/geometricReasoningIntegrator.ts` — add SYMPTOM_MAPPING entry

### New File

7. `.specs/spec-[complaint-slug].md` — spec document for this pathway

## Scaffolding Instructions for Claude Code

When this skill is invoked with a complaint name, generate all six modifications:

### 1. COMPLAINT_ONTOLOGY entry template

```typescript
// In server/ontology/clinicalOntology.ts, add to COMPLAINT_ONTOLOGY:
[COMPLAINT_SLUG]: {
  canonical:     "[COMPLAINT_SLUG]",
  displayName:   "[Display Name]",
  icdCategory:   "[ICD-10 category code]",
  acuityClass:   "[emergent|urgent|routine|chronic]",
  redFlagRisk:   "[high|medium|low]",
  asyncSafeDefault: [true|false],
  followUpProtocolExists: [true|false],
  aliases: ["[alias1]", "[alias2]", "[display name lower]"],
},
```

### 2. Bayesian LR table template

```typescript
// In bayesianConfidenceUpdater.ts, add to LR_TABLES and PRIORS:
const [COMPLAINT_SLUG_UPPER]_LR: LikelihoodRatioTable = {
  // Key symptoms with their likelihood ratios per diagnosis
  // LR > 1: symptom increases probability of this diagnosis
  // LR < 1: symptom decreases probability
  // Source: [clinical guideline, e.g., Centor criteria, Wells, HEART]
  [key_symptom]: {
    yes: {
      "[Primary Diagnosis]":   [LR value based on guidelines],
      "[Secondary Diagnosis]": [LR value],
    },
    no: {
      "[Primary Diagnosis]":   [inverse LR],
      "[Secondary Diagnosis]": [inverse LR],
    },
  },
  // Add 4-6 key symptoms
};

// In PRIORS, add:
[COMPLAINT_SLUG]: {
  "[Primary Diagnosis]":   [base rate 0-1, from urgent care epidemiology],
  "[Secondary Diagnosis]": [base rate],
  "[Tertiary Diagnosis]":  [base rate],
  // All priors must sum to ~1.0
},
```

### 3. Knowledge graph template

```typescript
// In clinicalKnowledgeGraph.ts, add a new load method:
private load[ComplaintPascalCase]Graph(): void {
  // Diagnosis nodes
  this.addNode({ id: "[slug1]", type: "diagnosis", label: "[Diagnosis 1]", icdCode: "[ICD]" });
  this.addNode({ id: "[slug2]", type: "diagnosis", label: "[Diagnosis 2]", icdCode: "[ICD]" });
  
  // Symptom nodes  
  this.addNode({ id: "[symptom1]", type: "symptom", label: "[Symptom display]" });
  
  // Red flag node (if applicable)
  this.addNode({ id: "rf_[complaint]", type: "red_flag", label: "[Red Flag Name]" });
  
  // Edges with clinical basis
  this.addEdge({ from: "[symptom1]", to: "[slug1]", type: "strongly_supports", weight: 0.8, 
                 evidenceBase: "[Guideline source]" });
  this.addEdge({ from: "[symptom1]", to: "rf_[complaint]", type: "triggers_red_flag", weight: 1.0 });
  
  // Clusters (symptom patterns)
  this.addCluster({
    id: "[cluster_id]", name: "[Clinical Pattern Name]",
    nodes: ["[symptom1]", "[symptom2]"],
    threshold: 0.5,
    targetDx: "[Primary Diagnosis]",
  });
}
```

### 4. Drift canary template

```typescript
// In driftCheck.ts, add to DRIFT_CANARIES:
{
  id:                   "[complaint_slug]_[scenario]",
  complaint:            "[COMPLAINT_SLUG]",
  symptoms:             ["[key symptom 1]", "[key symptom 2]", "[benign symptom]"],
  patientAge:           [typical age],
  patientSex:           "[male|female]",
  expectedDisposition:  "[er_send|urgent_care|pcp|self_care]",
  expectedTopDiagnosis: "[Primary Diagnosis]",
  confidenceFloor:      0.60,
  mustHaveRedFlag:      [true|false],
  mustNotHaveRedFlag:   [true|false],
},
// Add a second canary for the red-flag scenario if high-risk complaint
```

### 5. Follow-up protocol template (if followUpProtocolExists: true)

```typescript
// In followUpService.ts FOLLOW_UP_PROTOCOLS, add:
{
  id:           "[complaint_slug]",
  complaintSlug: "[COMPLAINT_SLUG]",
  name:         "[Protocol Name]",
  checkIns: [
    {
      dayOffset: 1,
      questions: [
        "[Are your symptoms improving?]",
        "[Specific clinical question for this condition]",
        "[Red flag question: any emergency symptoms?]",
      ],
      escalationTrigger: "[deterioration condition]",
    },
    { dayOffset: 3, questions: ["[Follow-up question]"], escalationTrigger: "[trigger]" },
    { dayOffset: 7, questions: ["[Final check]"],        escalationTrigger: "[trigger]" },
  ],
},
```

### 6. SYMPTOM_MAPPING entry

```typescript
// In geometricReasoningIntegrator.ts SYMPTOM_MAPPING:
[COMPLAINT_SLUG]: {
  "[question_id_from_kb]": "[graph_node_id]",
  "[another_question_id]": "[another_graph_node_id]",
  // Map intake question IDs to graph node IDs
},
```

## Pre-Scaffold Checklist

Before scaffolding, confirm with the user:

1. What is the complaint slug? (lowercase, underscores, e.g., `knee_pain`)
2. What are the 2-3 most important diagnoses to differentiate? 
3. Is this complaint high-risk for red flags? (determines drift canary structure)
4. Does this need a chronic disease follow-up protocol?
5. What clinical decision rule governs this complaint? (Centor, Wells, Ottawa, etc.)
6. What is the typical disposition in urgent care?

## After Scaffolding

Tell the user:
1. Run `npx ts-node .claude/skills/clinical-safety-verifier/scripts/verify-gates.ts`
2. Add the new complaint to the spec-driven system: `POST /api/harness/spec`
3. The KB rules still need to be added to the database (the ontology and graph are code-level; KB rules are data)
4. The new drift canary won't fire until the nightly drift check runs
