
import express from "express";
import { runCognitiveBrain } from "./cognitive/cognitiveOrchestrator";

const app = express();
app.use(express.json());

app.post("/api/cognitive-run", async (req, res) => {
  const result = await runCognitiveBrain(req.body);
  res.json(result);
});

app.listen(3000, () => console.log("Server running on port 3000"));
