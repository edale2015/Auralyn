
export function selectStrategy(monologue: any, debate: any) {
  return monologue.recommended_strategy || "observe";
}
