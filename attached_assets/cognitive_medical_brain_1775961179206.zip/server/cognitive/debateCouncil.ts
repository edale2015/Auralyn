
export async function runSpecialistDebate(caseData: any, baseResult: any) {
  return {
    final_diagnosis: "example",
    disagreementScore: 0.2,
    most_dangerous_miss: "",
    confidence: 0.8
  };
}
