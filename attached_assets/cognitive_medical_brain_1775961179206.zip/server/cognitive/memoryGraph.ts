
export async function writeToMemoryGraph(caseData: any, result: any) {
  return true;
}
