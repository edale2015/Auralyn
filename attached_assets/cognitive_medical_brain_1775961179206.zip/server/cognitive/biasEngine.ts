
export function applyBiasGuards({ plan, monologue }: any) {
  return plan;
}
