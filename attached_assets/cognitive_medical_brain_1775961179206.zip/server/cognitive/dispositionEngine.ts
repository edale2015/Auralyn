
export function computeDisposition({ confidence }: any) {
  return confidence > 0.8 ? "HOME" : "FOLLOW_UP";
}
