import os
from dataclasses import dataclass


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass(frozen=True)
class MedicalAIConfig:
    provider: str = os.getenv("MED_AI_PROVIDER", "ollama")
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "gemma3")
    ollama_embed_model: str = os.getenv("OLLAMA_EMBED_MODEL", "embeddinggemma")

    # Keep PHI local by default. Turn this on only after compliance/vendor review.
    allow_cloud_phi: bool = _bool_env("ALLOW_CLOUD_PHI", False)

    pinecone_api_key: str = os.getenv("PINECONE_API_KEY", "")
    pinecone_index_name: str = os.getenv("PINECONE_INDEX_NAME", "")
    pinecone_namespace: str = os.getenv("PINECONE_NAMESPACE", "medical-assistant")

    local_db_path: str = os.getenv("MED_AI_LOCAL_DB", "medical_ai.sqlite3")
    max_context_chars: int = int(os.getenv("MED_AI_MAX_CONTEXT_CHARS", "8000"))
    request_timeout_seconds: int = int(os.getenv("MED_AI_TIMEOUT_SECONDS", "90"))


CONFIG = MedicalAIConfig()
