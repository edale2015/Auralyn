import json
import re
from typing import Any, Dict, Iterable, List, Union

import requests

from .config import CONFIG

JsonLike = Union[Dict[str, Any], List[Any], str, int, float, bool, None]


class LLMError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, base_url: str = CONFIG.ollama_base_url, model: str = CONFIG.ollama_model):
        self.base_url = base_url.rstrip("/")
        self.model = model

    def generate_json(self, prompt: str, system: str, schema: Dict[str, Any]) -> Dict[str, Any]:
        payload = {
            "model": self.model,
            "system": system,
            "prompt": prompt,
            "stream": False,
            "format": schema,
            "options": {"temperature": 0.1},
        }
        try:
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=CONFIG.request_timeout_seconds,
            )
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise LLMError(f"Ollama generate request failed: {exc}") from exc

        raw = resp.json().get("response", "")
        return _parse_json_object(raw)

    def embed(self, texts: Union[str, Iterable[str]]) -> List[List[float]]:
        is_single = isinstance(texts, str)
        input_payload = texts if is_single else list(texts)
        payload = {"model": CONFIG.ollama_embed_model, "input": input_payload}
        try:
            resp = requests.post(
                f"{self.base_url}/api/embed",
                json=payload,
                timeout=CONFIG.request_timeout_seconds,
            )
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise LLMError(f"Ollama embedding request failed: {exc}") from exc

        data = resp.json()
        embeddings = data.get("embeddings")
        if embeddings is None and "embedding" in data:
            embeddings = [data["embedding"]]
        if not isinstance(embeddings, list) or not embeddings:
            raise LLMError("Ollama did not return embeddings.")
        return embeddings if not is_single else [embeddings[0]]


def _parse_json_object(raw: str) -> Dict[str, Any]:
    raw = str(raw or "").strip()
    try:
        value = json.loads(raw)
        if isinstance(value, dict):
            return value
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", raw, re.S)
    if match:
        try:
            value = json.loads(match.group(0))
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass

    raise LLMError("Model did not return valid JSON.")
