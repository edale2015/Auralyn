from flask import Blueprint, jsonify, request

from .audit import log_event
from .llm import LLMError, OllamaClient
from .phi import clean_text, redact_phi
from .prompts import RESPONSE_SCHEMA, SYSTEM_PROMPT, build_artifact_prompt, build_chat_prompt
from .safety import detect_red_flags, emergency_payload, standard_disclaimer
from .store import get_store, source_dicts

medical_ai_bp = Blueprint("medical_ai", __name__, url_prefix="/api/medical-ai")


def _json_body():
    return request.get_json(silent=True) or {}


@medical_ai_bp.post("/chat")
def chat():
    data = _json_body()
    message = clean_text(data.get("message", ""), limit=12000)
    if not message:
        return jsonify({"error": "message is required"}), 400

    role = clean_text(data.get("role", "patient"), limit=40) or "patient"
    patient_context = clean_text(data.get("patient_context", ""), limit=12000)

    flags = detect_red_flags(message + "\n" + patient_context)
    if flags["is_emergency"]:
        payload = emergency_payload(flags["matches"])
        log_event("emergency_flag", {"message": redact_phi(message), "matches": flags["matches"]})
        return jsonify(payload), 200

    store = get_store()
    sources = source_dicts(store.search(message, limit=int(data.get("limit", 5) or 5)))
    prompt = build_chat_prompt(message=message, patient_context=patient_context, sources=sources, role=role)

    try:
        result = OllamaClient().generate_json(prompt=prompt, system=SYSTEM_PROMPT, schema=RESPONSE_SCHEMA)
    except LLMError as exc:
        log_event("llm_error", {"message": redact_phi(message), "error": str(exc)})
        return jsonify({
            "error": "local_llm_unavailable",
            "detail": "The local AI model is not reachable. Check OLLAMA_BASE_URL and OLLAMA_MODEL in Replit Secrets.",
        }), 503

    result["disclaimer"] = standard_disclaimer(role)
    result["retrieved_sources"] = sources
    log_event("chat", {"message": redact_phi(message), "source_count": len(sources), "role": role})
    return jsonify(result), 200


@medical_ai_bp.post("/knowledge/ingest")
def ingest_knowledge():
    data = _json_body()
    title = clean_text(data.get("title", "Untitled source"), limit=300) or "Untitled source"
    text = clean_text(data.get("text", ""), limit=250000)
    if not text:
        return jsonify({"error": "text is required"}), 400

    metadata = data.get("metadata") if isinstance(data.get("metadata"), dict) else {}
    metadata.setdefault("source_type", clean_text(data.get("source_type", "user_uploaded"), limit=80))

    store = get_store()
    count = store.upsert_text(title=title, text=text, metadata=metadata)
    log_event("knowledge_ingest", {"title": title, "chunks": count, "source_type": metadata.get("source_type")})
    return jsonify({"ok": True, "title": title, "chunks_indexed": count}), 201


@medical_ai_bp.get("/knowledge/search")
def search_knowledge():
    query = clean_text(request.args.get("q", ""), limit=1000)
    limit = int(request.args.get("limit", 5) or 5)
    if not query:
        return jsonify({"error": "q is required"}), 400
    results = source_dicts(get_store().search(query, limit=limit))
    return jsonify({"query": query, "results": results}), 200


@medical_ai_bp.post("/artifact")
def artifact():
    data = _json_body()
    artifact_type = clean_text(data.get("artifact_type", "visit_summary"), limit=80)
    user_text = clean_text(data.get("text", ""), limit=16000)
    role = clean_text(data.get("role", "patient"), limit=40) or "patient"
    if not user_text:
        return jsonify({"error": "text is required"}), 400

    flags = detect_red_flags(user_text)
    if flags["is_emergency"]:
        payload = emergency_payload(flags["matches"])
        log_event("emergency_flag_artifact", {"artifact_type": artifact_type, "matches": flags["matches"]})
        return jsonify(payload), 200

    sources = source_dicts(get_store().search(user_text, limit=5))
    prompt = build_artifact_prompt(artifact_type=artifact_type, user_text=user_text, sources=sources, role=role)

    try:
        result = OllamaClient().generate_json(prompt=prompt, system=SYSTEM_PROMPT, schema=RESPONSE_SCHEMA)
    except LLMError as exc:
        log_event("artifact_llm_error", {"artifact_type": artifact_type, "error": str(exc)})
        return jsonify({
            "error": "local_llm_unavailable",
            "detail": "The local AI model is not reachable. Check OLLAMA_BASE_URL and OLLAMA_MODEL in Replit Secrets.",
        }), 503

    result["artifact_type"] = artifact_type
    result["disclaimer"] = standard_disclaimer(role)
    result["retrieved_sources"] = sources
    log_event("artifact", {"artifact_type": artifact_type, "source_count": len(sources)})
    return jsonify(result), 200
