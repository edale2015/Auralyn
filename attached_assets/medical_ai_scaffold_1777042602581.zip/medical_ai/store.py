import json
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from .config import CONFIG
from .llm import LLMError, OllamaClient
from .phi import clean_text

TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}")


@dataclass
class SourceChunk:
    source_id: str
    title: str
    text: str
    metadata: Dict[str, object]
    score: float = 0.0

    def to_dict(self, position: int) -> Dict[str, object]:
        return {
            "source_id": f"S{position}",
            "chunk_id": self.source_id,
            "title": self.title,
            "text": self.text,
            "metadata": self.metadata,
            "score": self.score,
        }


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 160) -> List[str]:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end].strip())
        if end == len(text):
            break
        start = max(0, end - overlap)
    return [c for c in chunks if c]


class LocalSQLiteStore:
    def __init__(self, db_path: str = CONFIG.local_db_path):
        self.db_path = db_path
        self.fts_enabled = True
        self._init()

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def _init(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS medical_docs (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    text TEXT NOT NULL,
                    metadata TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            try:
                conn.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS medical_docs_fts USING fts5(id UNINDEXED, title, text)"
                )
            except sqlite3.OperationalError:
                self.fts_enabled = False
            conn.commit()

    def upsert_text(self, title: str, text: str, metadata: Optional[Dict[str, object]] = None) -> int:
        metadata = metadata or {}
        chunks = chunk_text(text)
        now = time.time()
        with self._connect() as conn:
            for idx, chunk in enumerate(chunks):
                chunk_id = f"local-{uuid.uuid4().hex}"
                meta = dict(metadata, chunk_index=idx, source_title=title)
                conn.execute(
                    "INSERT OR REPLACE INTO medical_docs(id, title, text, metadata, created_at) VALUES (?, ?, ?, ?, ?)",
                    (chunk_id, clean_text(title, 300), clean_text(chunk), json.dumps(meta), now),
                )
                if self.fts_enabled:
                    conn.execute(
                        "INSERT INTO medical_docs_fts(id, title, text) VALUES (?, ?, ?)",
                        (chunk_id, clean_text(title, 300), clean_text(chunk)),
                    )
            conn.commit()
        return len(chunks)

    def search(self, query: str, limit: int = 5) -> List[SourceChunk]:
        query = str(query or "").strip()
        if not query:
            return []
        if self.fts_enabled:
            return self._search_fts(query, limit)
        return self._search_like(query, limit)

    def _search_fts(self, query: str, limit: int) -> List[SourceChunk]:
        fts_query = _make_fts_query(query)
        if not fts_query:
            return []
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT d.id, d.title, d.text, d.metadata, bm25(medical_docs_fts) AS rank
                FROM medical_docs_fts f
                JOIN medical_docs d ON d.id = f.id
                WHERE medical_docs_fts MATCH ?
                ORDER BY rank ASC
                LIMIT ?
                """,
                (fts_query, limit),
            ).fetchall()
        return [
            SourceChunk(
                source_id=row["id"],
                title=row["title"],
                text=row["text"],
                metadata=json.loads(row["metadata"] or "{}"),
                score=float(row["rank"] or 0),
            )
            for row in rows
        ]

    def _search_like(self, query: str, limit: int) -> List[SourceChunk]:
        tokens = _tokens(query)
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id, title, text, metadata FROM medical_docs ORDER BY created_at DESC LIMIT 500").fetchall()
        scored = []
        for row in rows:
            haystack = f"{row['title']} {row['text']}".lower()
            score = sum(1 for token in tokens if token in haystack)
            if score > 0:
                scored.append((score, row))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            SourceChunk(
                source_id=row["id"],
                title=row["title"],
                text=row["text"],
                metadata=json.loads(row["metadata"] or "{}"),
                score=float(score),
            )
            for score, row in scored[:limit]
        ]


class PineconeStore:
    def __init__(self):
        from pinecone import Pinecone

        self.pc = Pinecone(api_key=CONFIG.pinecone_api_key)
        self.index = self.pc.Index(CONFIG.pinecone_index_name)
        self.namespace = CONFIG.pinecone_namespace
        self.llm = OllamaClient()

    def upsert_text(self, title: str, text: str, metadata: Optional[Dict[str, object]] = None) -> int:
        metadata = metadata or {}
        chunks = chunk_text(text)
        if not chunks:
            return 0
        embeddings = self.llm.embed(chunks)
        vectors = []
        for idx, (chunk, vector) in enumerate(zip(chunks, embeddings)):
            chunk_id = f"pc-{uuid.uuid4().hex}"
            meta = dict(metadata, title=title, text=chunk[:3500], chunk_index=idx)
            vectors.append({"id": chunk_id, "values": vector, "metadata": meta})
        self.index.upsert(vectors=vectors, namespace=self.namespace)
        return len(vectors)

    def search(self, query: str, limit: int = 5) -> List[SourceChunk]:
        vector = self.llm.embed(query)[0]
        result = self.index.query(
            vector=vector,
            top_k=limit,
            include_metadata=True,
            namespace=self.namespace,
        )
        matches = result.get("matches", []) if isinstance(result, dict) else getattr(result, "matches", [])
        chunks: List[SourceChunk] = []
        for match in matches:
            if isinstance(match, dict):
                meta = match.get("metadata", {}) or {}
                chunks.append(
                    SourceChunk(
                        source_id=match.get("id", ""),
                        title=meta.get("title", "Untitled source"),
                        text=meta.get("text", ""),
                        metadata={k: v for k, v in meta.items() if k != "text"},
                        score=float(match.get("score", 0) or 0),
                    )
                )
            else:
                meta = getattr(match, "metadata", {}) or {}
                chunks.append(
                    SourceChunk(
                        source_id=getattr(match, "id", ""),
                        title=meta.get("title", "Untitled source"),
                        text=meta.get("text", ""),
                        metadata={k: v for k, v in meta.items() if k != "text"},
                        score=float(getattr(match, "score", 0) or 0),
                    )
                )
        return chunks


def get_store():
    pinecone_ready = CONFIG.allow_cloud_phi and CONFIG.pinecone_api_key and CONFIG.pinecone_index_name
    if pinecone_ready:
        try:
            return PineconeStore()
        except Exception:
            # Fall back to local storage instead of breaking the medical flow.
            return LocalSQLiteStore()
    return LocalSQLiteStore()


def source_dicts(chunks: Iterable[SourceChunk]) -> List[Dict[str, object]]:
    return [chunk.to_dict(i) for i, chunk in enumerate(chunks, start=1)]


def _tokens(text: str) -> List[str]:
    return [m.group(0).lower() for m in TOKEN_RE.finditer(text or "")]


def _make_fts_query(text: str) -> str:
    tokens = _tokens(text)
    tokens = [t for t in tokens if len(t) >= 3][:12]
    return " OR ".join(tokens)
