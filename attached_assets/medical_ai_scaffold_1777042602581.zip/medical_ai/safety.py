import re
from typing import Dict, List

RED_FLAG_PATTERNS = {
    "possible_heart_or_lung_emergency": [
        r"\bchest pain\b",
        r"\bpressure in (my )?chest\b",
        r"\btrouble breathing\b",
        r"\bshort(ness)? of breath\b",
        r"\bblue lips\b",
    ],
    "possible_stroke_or_neurologic_emergency": [
        r"\bstroke\b",
        r"\bface droop\b",
        r"\bslurred speech\b",
        r"\bsudden weakness\b",
        r"\bone[-\s]?sided weakness\b",
        r"\bworst headache\b",
        r"\bseizure\b",
    ],
    "possible_self_harm_or_overdose": [
        r"\bsuicid(e|al)\b",
        r"\bkill myself\b",
        r"\bself[-\s]?harm\b",
        r"\boverdose\b",
        r"\btook too much\b",
    ],
    "possible_severe_allergy_or_bleeding": [
        r"\banaphylaxis\b",
        r"\bthroat swelling\b",
        r"\btongue swelling\b",
        r"\bsevere bleeding\b",
        r"\bwon'?t stop bleeding\b",
    ],
    "possible_pregnancy_emergency": [
        r"\bpregnant\b.*\bbleeding\b",
        r"\bpregnant\b.*\bsevere pain\b",
    ],
}


def detect_red_flags(text: str) -> Dict[str, object]:
    text = str(text or "").lower()
    matches: List[Dict[str, str]] = []
    for category, patterns in RED_FLAG_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text, re.I):
                matches.append({"category": category, "pattern": pattern})
                break
    return {"is_emergency": bool(matches), "matches": matches}


def emergency_payload(matches: List[Dict[str, str]]) -> Dict[str, object]:
    categories = sorted({m["category"] for m in matches})
    return {
        "answer": "This may be urgent. Please call emergency services now, go to the nearest emergency department, or contact a local crisis/emergency line immediately. Do not wait for an AI response.",
        "care_safety": {
            "urgent": True,
            "red_flags_detected": categories,
            "instruction": "Seek immediate human medical help now.",
        },
        "recommended_next_steps": [
            "Call local emergency services now if symptoms are happening now or feel severe.",
            "Do not drive yourself if you feel faint, confused, short of breath, or unsafe.",
            "Have a trusted person stay with you while help is contacted.",
        ],
        "questions_for_clinician": [],
        "sources": [],
        "confidence": "high",
        "disclaimer": "This app provides education and triage support, not a diagnosis or a substitute for emergency care.",
    }


def standard_disclaimer(role: str = "patient") -> str:
    if role == "clinician":
        return "Clinical support only. Verify against the patient record, exam findings, current guidelines, and local policy before acting."
    return "Educational support only. This is not a diagnosis, treatment plan, or substitute for a licensed clinician. For urgent symptoms, seek emergency care."
