RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "answer": {"type": "string"},
        "care_safety": {
            "type": "object",
            "properties": {
                "urgent": {"type": "boolean"},
                "red_flags_detected": {"type": "array", "items": {"type": "string"}},
                "instruction": {"type": "string"},
            },
            "required": ["urgent", "red_flags_detected", "instruction"],
        },
        "recommended_next_steps": {"type": "array", "items": {"type": "string"}},
        "questions_for_clinician": {"type": "array", "items": {"type": "string"}},
        "sources": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source_id": {"type": "string"},
                    "title": {"type": "string"},
                    "used_for": {"type": "string"},
                },
                "required": ["source_id", "title", "used_for"],
            },
        },
        "confidence": {"type": "string", "enum": ["low", "medium", "high"]},
    },
    "required": ["answer", "care_safety", "recommended_next_steps", "questions_for_clinician", "sources", "confidence"],
}

SYSTEM_PROMPT = """
You are a cautious medical education assistant inside a medical assistant app.

Rules:
1. Do not diagnose, prescribe, adjust medication, or claim certainty.
2. Do not tell the user to ignore, delay, or replace professional care.
3. For urgent or emergency symptoms, tell the user to seek emergency care immediately.
4. Use the provided source excerpts when relevant. Cite them with source_id values such as [S1].
5. When sources are weak or missing, say what information is missing and keep confidence low.
6. Give practical outputs: next steps, doctor questions, and what to monitor.
7. Return JSON only. No markdown outside JSON.
""".strip()


def build_chat_prompt(message: str, patient_context: str, sources: list, role: str = "patient") -> str:
    source_lines = []
    for i, src in enumerate(sources, start=1):
        source_id = src.get("source_id") or f"S{i}"
        title = src.get("title", "Untitled source")
        excerpt = src.get("text", "")[:1600]
        source_lines.append(f"[{source_id}] {title}\n{excerpt}")
    sources_block = "\n\n".join(source_lines) if source_lines else "No source excerpts were found."

    return f"""
User role: {role}
Patient/context notes, possibly incomplete:
{patient_context or "No extra patient context supplied."}

Source excerpts:
{sources_block}

User question:
{message}

Return a JSON response that follows the schema exactly.
""".strip()


def build_artifact_prompt(artifact_type: str, user_text: str, sources: list, role: str = "patient") -> str:
    source_lines = []
    for i, src in enumerate(sources, start=1):
        source_id = src.get("source_id") or f"S{i}"
        source_lines.append(f"[{source_id}] {src.get('title', 'Untitled source')}\n{src.get('text', '')[:1200]}")
    sources_block = "\n\n".join(source_lines) if source_lines else "No source excerpts were found."

    artifact_instructions = {
        "visit_summary": "Create a concise pre-visit summary with symptoms, timeline, medications mentioned, concerns, and unknowns.",
        "doctor_questions": "Create prioritized questions the user can ask their clinician. Avoid leading questions and avoid diagnosis claims.",
        "symptom_timeline": "Create a structured symptom timeline template from the user's notes, with unknown fields clearly marked.",
        "medication_review": "Create a medication discussion checklist. Do not recommend medication changes.",
        "patient_education_visual_brief": "Create a safe, non-diagnostic creative brief for a patient education visual. Include visual goal, audience, plain-language labels, and safety caveats.",
        "audio_script": "Create a short patient education audio script. Keep it calm, plain-language, and non-diagnostic.",
    }
    instruction = artifact_instructions.get(artifact_type, artifact_instructions["visit_summary"])

    return f"""
User role: {role}
Artifact type: {artifact_type}
Task: {instruction}

Source excerpts:
{sources_block}

User notes:
{user_text}

Return JSON using this same app response schema. Put the artifact content in the answer field.
""".strip()
