import re
from html import escape

EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}(?!\d)")
SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
MRN_RE = re.compile(r"\b(?:MRN|medical record number|patient id)[:#\s-]*[A-Z0-9-]{5,}\b", re.I)
DOB_RE = re.compile(r"\b(?:DOB|date of birth)[:#\s-]*(?:\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|[A-Z][a-z]+\s+\d{1,2},\s*\d{4})\b", re.I)
ADDRESS_RE = re.compile(r"\b\d{1,6}\s+[A-Za-z0-9.'-]+(?:\s+[A-Za-z0-9.'-]+){0,4}\s+(?:St|Street|Ave|Avenue|Rd|Road|Blvd|Boulevard|Ln|Lane|Dr|Drive|Way|Ct|Court)\b", re.I)


def clean_text(text: str, limit: int = 20000) -> str:
    text = str(text or "")[:limit]
    text = text.replace("\x00", " ")
    return escape(text, quote=False).strip()


def redact_phi(text: str) -> str:
    text = str(text or "")
    replacements = [
        (EMAIL_RE, "[REDACTED_EMAIL]"),
        (PHONE_RE, "[REDACTED_PHONE]"),
        (SSN_RE, "[REDACTED_SSN]"),
        (MRN_RE, "[REDACTED_MRN]"),
        (DOB_RE, "[REDACTED_DOB]"),
        (ADDRESS_RE, "[REDACTED_ADDRESS]"),
    ]
    for pattern, replacement in replacements:
        text = pattern.sub(replacement, text)
    return text
