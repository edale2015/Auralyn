import json
import sqlite3
import time
from typing import Dict

from .config import CONFIG
from .phi import redact_phi


def _connect():
    return sqlite3.connect(CONFIG.local_db_path)


def init_audit() -> None:
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS medical_ai_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at REAL NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )
            """
        )
        conn.commit()


def log_event(event_type: str, payload: Dict[str, object]) -> None:
    init_audit()
    safe_payload = json.loads(redact_phi(json.dumps(payload, default=str)))
    with _connect() as conn:
        conn.execute(
            "INSERT INTO medical_ai_audit(created_at, event_type, payload_json) VALUES (?, ?, ?)",
            (time.time(), event_type, json.dumps(safe_payload)),
        )
        conn.commit()
