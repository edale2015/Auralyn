
Research & Meta-AI Bundle

This bundle adds:

1. Research Source Registry
2. Clinical Knowledge Ingestion Engine
3. Provenance Tracking Engine
4. Research Validation Engine
5. Source Promotion Engine
6. Comment Distillation Engine (for forums / article comments)
7. Meta AI Supervisor

Comment Distillation Engine:
Extracts themes from comments or forum posts and returns bullet summaries.
These are informational only for physicians, not used as clinical rules.
