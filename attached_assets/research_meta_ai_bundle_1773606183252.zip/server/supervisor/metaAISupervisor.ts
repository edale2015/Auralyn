
export function metaAISupervisor(state:any){
  const flags: string[] = []

  if (state.entropy && state.entropy > 1.2) {
    flags.push("High diagnostic uncertainty")
  }

  if (!state.tests || state.tests.length === 0) {
    flags.push("No diagnostic tests proposed")
  }

  if (state.redFlags && state.redFlags.length > 0) {
    flags.push("Red flag symptoms detected")
  }

  return {
    supervisorDecision: flags.length ? "REVIEW_REQUIRED" : "APPROVED",
    flags
  }
}
