
export type SourceTier = 1 | 2 | 3 | 4

export interface ResearchSource {
  id: string
  title: string
  sourceType:
    | "guideline"
    | "review"
    | "flowchart"
    | "sheet"
    | "journalism"
    | "commentary"
    | "forum"
    | "patient_language"
  authorityTier: SourceTier
  domain: "clinical_rule" | "patient_language" | "trend_surveillance"
  url?: string
  uploadedFilePath?: string
  citation?: string
  versionDate?: string
  addedBy: string
  requiresHumanReview: boolean
  active: boolean
}

export interface KnowledgeEdge {
  from: string
  to: string
  relation: string
  weight?: number
  provenance?: KnowledgeProvenance
}

export interface KnowledgeProvenance {
  sourceId: string
  sourceTitle: string
  citation?: string
  extractedAt: string
  evidenceStrength: "high" | "moderate" | "low" | "unknown"
  reviewedByHuman: boolean
  approvedForClinicalUse: boolean
}
