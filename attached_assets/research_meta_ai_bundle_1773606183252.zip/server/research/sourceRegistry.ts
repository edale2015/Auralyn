
import { ResearchSource } from "./types/researchTypes"

const sources: Record<string, ResearchSource> = {}

export function registerSource(source: ResearchSource) {
  sources[source.id] = source
}

export function listSources() {
  return Object.values(sources)
}

export function getSource(id: string) {
  return sources[id]
}
