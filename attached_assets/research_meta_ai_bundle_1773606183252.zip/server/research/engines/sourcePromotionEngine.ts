
import { KnowledgeEdge } from "../types/researchTypes"

export function sourcePromotionEngine(edges: KnowledgeEdge[]) {
  const promoted: KnowledgeEdge[] = []

  for (const e of edges) {
    if (e.provenance && e.provenance.reviewedByHuman) {
      e.provenance.approvedForClinicalUse = true
      promoted.push(e)
    }
  }

  return promoted
}
