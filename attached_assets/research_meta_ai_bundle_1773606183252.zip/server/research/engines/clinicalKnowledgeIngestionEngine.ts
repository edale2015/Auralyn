
import { KnowledgeEdge } from "../types/researchTypes"

export function clinicalKnowledgeIngestionEngine(text: string, sourceId: string): KnowledgeEdge[] {

  const edges: KnowledgeEdge[] = []
  const lines = text.split("\n")

  for (const line of lines) {
    if (line.includes("causes")) {
      const parts = line.split("causes")
      edges.push({
        from: parts[0].trim(),
        to: parts[1].trim(),
        relation: "causes",
        provenance: {
          sourceId,
          sourceTitle: sourceId,
          extractedAt: new Date().toISOString(),
          evidenceStrength: "unknown",
          reviewedByHuman: false,
          approvedForClinicalUse: false
        }
      })
    }
  }

  return edges
}
