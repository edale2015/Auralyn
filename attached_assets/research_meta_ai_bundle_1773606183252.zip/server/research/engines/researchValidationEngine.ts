
import { KnowledgeEdge } from "../types/researchTypes"

export function researchValidationEngine(edges: KnowledgeEdge[]) {
  const safe: KnowledgeEdge[] = []
  const rejected: KnowledgeEdge[] = []

  for (const e of edges) {
    if (!e.from || !e.to) {
      rejected.push(e)
      continue
    }
    safe.push(e)
  }

  return { safe, rejected }
}
