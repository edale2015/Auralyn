
import { KnowledgeEdge } from "../types/researchTypes"

export function attachProvenance(edge: KnowledgeEdge, sourceTitle: string) {
  edge.provenance = {
    sourceId: edge.provenance?.sourceId || "unknown",
    sourceTitle,
    extractedAt: new Date().toISOString(),
    evidenceStrength: "unknown",
    reviewedByHuman: false,
    approvedForClinicalUse: false
  }
  return edge
}
