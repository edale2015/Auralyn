
export function commentDistillationEngine(comments: string[]) {
  const themes: Record<string, number> = {}

  for (const c of comments) {
    const words = c.toLowerCase().split(/\W+/)

    for (const w of words) {
      if (w.length < 4) continue
      themes[w] = (themes[w] || 0) + 1
    }
  }

  const sorted = Object.entries(themes)
    .sort((a,b)=>b[1]-a[1])
    .slice(0,15)
    .map(([word,count])=>({word,count}))

  return {
    summaryBullets: sorted.map(s=>`Frequent topic: ${s.word} (${s.count} mentions)`)
  }
}
