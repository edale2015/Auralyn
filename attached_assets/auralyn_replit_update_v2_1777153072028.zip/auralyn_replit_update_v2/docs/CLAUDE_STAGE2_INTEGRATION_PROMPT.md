# Claude/Replit integration prompt, stage 2

You are integrating Auralyn hardening bundle v2. This repo is a HIPAA/FDA-sensitive medical triage SaaS. Work only in a staging branch or staging Replit copy.

## Inputs

- All 15 Auralyn review slices.
- `auralyn_replit_update_v2.zip`.
- Current Replit workspace/repo.

## Important context

The v2 ZIP includes the original security/audit/auth/WebSocket hardening bundle plus dashboard-functionality review, dashboard integration helpers, static scanning scripts, and Medium article traceability scaffolding.

Do not blindly overwrite the app. Compare each included file and patch to the current repo first.

## Phase plan

1. Confirm branch:
   ```bash
   git status
   git checkout -b hardening/dashboard-medium-review
   ```

2. Unzip into a temp folder:
   ```bash
   mkdir -p /tmp/auralyn-v2
   unzip auralyn_replit_update_v2.zip -d /tmp/auralyn-v2
   ```

3. Review docs:
   - `docs/DASHBOARD_FUNCTIONALITY_REVIEW.md`
   - `docs/MEDIUM_IMPLEMENTATION_REVIEW.md`
   - `docs/dashboard_endpoint_contract.json`

4. Apply backend v1 hardening first if not already applied:
   - persistent audit chain
   - Agent Brain route auth/CSRF/rate limit/Zod validation
   - WebSocket auth/origin checks/PHI redaction
   - cookie auth integration
   - brain orchestrator/fleet safety bridge

5. Apply frontend auth changes:
   - replace `client/src/lib/queryClient.ts`
   - replace or merge `client/src/context/AuthContext.tsx`
   - ensure login/logout backend supports cookie session + CSRF cookie

6. Apply dashboard v2 helpers:
   - add `client/src/lib/patientStream.ts`
   - add `client/src/lib/dashboardActions.ts`
   - add `client/src/lib/dashboardEndpointContract.ts`

7. Manually merge patches:
   - `patches/AgentBrainPage.dashboard_integration.diff`
   - `patches/AdminDashboard.audit_export.diff`
   - `patches/ops.ask_hardening.diff`

8. Run static checks:
   ```bash
   node scripts/check-dashboard-contract.mjs
   node scripts/medium-traceability-check.mjs
   ```

9. Run project checks:
   ```bash
   npm run typecheck
   npm test
   npm run build
   ```

## Required implementation constraints

- Do not expose production secrets.
- Do not use real patient data.
- Do not deploy.
- Do not make autonomous medical decisions.
- Do not let LLM output downgrade deterministic HIGH/CRITICAL risk.
- Do not allow WebSocket broadcast of raw patient identifiers, names, phone numbers, complaint free text, or vitals by default.
- Do not leave any frontend `localStorage.getItem("app_auth_token")` usage.

## Return after work

Return:

1. Files changed.
2. Patches applied cleanly versus manual conflicts.
3. Git diff summary.
4. Test/build command results.
5. Remaining dashboard gaps.
6. Remaining Medium article traceability gaps.
7. Any clinical, HIPAA, FDA, or security concerns.
