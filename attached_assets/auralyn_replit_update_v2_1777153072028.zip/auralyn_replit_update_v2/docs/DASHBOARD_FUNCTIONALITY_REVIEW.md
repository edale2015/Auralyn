# Auralyn dashboard functionality review, stage 2

This review is based on the uploaded dashboard summaries and hardening-relevant source sections. It is not a substitute for running the full Replit repo, because the upload includes key snippets and endpoint lists rather than every component body, every click handler, and every rendered button.

## Executive finding

The dashboards appear directionally useful, but the current implementation needs three classes of fixes before it should be treated as a clinical command center:

1. **Security/auth correctness:** remove all `localStorage` token reads, use HttpOnly cookie session auth, attach CSRF headers for mutating calls, and authenticate WebSocket upgrades.
2. **Dashboard interaction correctness:** every button that mutates backend state should disable while pending, show success/error state, and invalidate or refetch the exact monitors it changes.
3. **Clinical governance coverage:** the existing dashboards expose many operational and agentic controls, but they are not comprehensive for the full medical system. Missing or underrepresented functions include co-signature queues, discharge blocking, clinical override audit, user/role admin, audit verification, article-to-code traceability, model/version governance, and incident/security status.

## Dashboard-by-dashboard review

### 1. AgentBrainPage.tsx

Uploaded capabilities:

- Polls `/api/agent-brain/status`, `/heatmap`, `/insights`, and `/audit`.
- Opens `/ws/patient-stream`.
- Provides start/stop loop controls, manual cycle, and simulate controls.
- Shows patient heatmap, selected patient, agent pipeline, digital twin, routing, insights, audit chain, and WebSocket event feed.

Confirmed issues from the uploaded snippets:

- WebSocket connects without app-level auth logic in the frontend and previously depended on unauthenticated backend acceptance.
- WebSocket feed displays raw `patientId` and nested risk data rather than the redacted `patientRef` + `riskLevel` contract.
- The patient card type includes `name` and raw vitals. Those may be acceptable over authenticated REST for same-tenant clinical users, but should not be sent over broadcast WebSocket.
- Mutating controls post to `/api/agent-brain/*` but the shown snippets do not invalidate the relevant queries after success.
- Controls need role-aware disabled states. Start/stop should be admin/physician only, not staff/patient.

Recommended improvements implemented in this bundle:

- `client/src/lib/patientStream.ts` provides a redacted, reconnecting WebSocket hook that expects `patientRef`.
- `patches/AgentBrainPage.dashboard_integration.diff` shows how to wire the hook, update patient identifiers, and invalidate dashboard queries after mutations.
- The previous v1 bundle adds backend auth, CSRF, rate limits, persistent audit, and PHI redaction for the Agent Brain routes and WebSocket.

### 2. AdminDashboard.tsx

Uploaded capabilities:

- Five groups and twenty links across clinical operations, decision pipeline, AI/learning, data/audit, and governance.
- Audit export calls `/api/audit/export-package`.

Confirmed issues:

- Audit export directly reads `localStorage.getItem("app_auth_token")` and places it into an Authorization header.
- `decision-graphs` and `trace-viewer` appear in more than one group. This is not automatically wrong, but it can make coverage look better than it is. The dashboard should distinguish duplicate navigation links from unique system functions.

Recommended improvements implemented in this bundle:

- `patches/AdminDashboard.audit_export.diff` replaces direct token access with `apiRequest("GET", ...)`, which uses cookie credentials and correlation IDs.
- `scripts/check-dashboard-contract.mjs` detects future direct token reads.

Additional recommended admin controls:

- Audit chain verification status and latest persisted chain head.
- User/role/tenant administration.
- WebSocket/session security health.
- Feature flags for autonomous loop, LLM fleet usage, and research-to-production promotion.
- Incident log and emergency kill-switch for autonomous features.

### 3. AuralynDashboard.tsx

Uploaded capabilities:

- Overview metrics, clinic tenant CRUD, billing, and a clinical assistant tab.
- Uses `/api/auralyn/overview`, `/tenants`, `/billing/*`, and `/clinical/run`.

Functional risks to check inside the full repo:

- Tenant creation should require admin role and should not allow cross-tenant leakage.
- Billing panels must not expose other tenants' billing records.
- `/api/auralyn/clinical/run` should be treated as clinical decision support, not a final diagnosis. It should produce an audit record, show confidence/uncertainty, and require physician review for any medical disposition.
- Create/update/delete actions should have loading, error, and success states.
- Tenant changes should invalidate overview, tenant list, billing summary, and any affected dashboard cache.

### 4. PhysicianDashboard.tsx

Uploaded capabilities:

- Feedback stats, feedback logs, error detection, RLHF-style fixes with approve/reject, case memory search, and explainability graph.

Functional risks to check inside the full repo:

- Approving a self-improvement/RLHF fix is clinically sensitive and should require physician/admin role, CSRF, an audit event, and versioned rollback.
- Fix approval should be blocked if no validation result is attached.
- Error detection output should be clearly separated from verified clinical error.
- Similar-case memory search should avoid returning PHI unless same-tenant and authorized.
- Explainability graph should show model/rule versions, not just a demo result.

### 5. Query client and auth layer

Confirmed issue:

- The uploaded query client reads `localStorage.getItem("app_auth_token")`.

Implemented in v1 and reinforced in v2:

- Cookie-based `queryClient.ts` and `AuthContext.tsx` use `credentials: "include"` and CSRF header support.
- `scripts/check-dashboard-contract.mjs` fails if direct localStorage token use remains.

## Are the buttons and monitors comprehensive?

Not yet. The current dashboard set is broad, but a full medical triage system also needs explicit UI coverage for:

- Intake queue and encounter lifecycle.
- Physician review queue and co-signature queue.
- Discharge approval/blocking workflow.
- Critical escalation handoff and acknowledgement.
- Override reasons and override audit review.
- Audit chain verification and tamper alerting.
- Patient identity/demographics via dedicated audited endpoint, not WebSocket.
- Tenant/site/user/role management.
- Research article review, implementation traceability, and promotion status.
- Model and prompt version registry.
- Agent circuit breaker and feature flag governance.
- Security status: session, CSRF, WebSocket origin, failed auth, and PHI exposure warnings.
- Incident response controls and autonomous-loop kill switch.

## Minimum button/monitor acceptance criteria

Each dashboard button should satisfy the following before production use:

- Has a clear allowed role.
- Has a matching backend route with auth, CSRF for mutations, rate limit, and Zod/body validation.
- Disables while pending.
- Shows failure and success feedback.
- Invalidates the relevant query keys after success.
- Writes an audit event if it affects clinical, security, tenant, billing, or governance state.
- Does not expose PHI over unauthenticated or broadcast channels.

Each monitor should satisfy:

- Shows loading, empty, error, and stale states.
- Displays the source timestamp and freshness.
- Uses redacted patient references unless it is a dedicated same-tenant clinical view.
- Has a backend source of truth, not module-only memory for critical state.
- Shows whether data is simulated, demo, production, or clinically verified.
