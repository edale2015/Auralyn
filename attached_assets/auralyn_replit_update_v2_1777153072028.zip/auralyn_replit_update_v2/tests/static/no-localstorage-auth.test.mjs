import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

function walk(dir, acc = []) {
  if (!fs.existsSync(dir)) return acc;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!["node_modules", ".git", "dist", "build"].includes(entry.name)) walk(full, acc);
    } else if (/\.(ts|tsx|js|jsx)$/.test(entry.name)) {
      acc.push(full);
    }
  }
  return acc;
}

test("frontend does not store or read app_auth_token from localStorage", () => {
  const root = process.cwd();
  const files = walk(path.join(root, "client"));
  const offenders = files.filter(file => /localStorage\.(getItem|setItem|removeItem)\(["']app_auth_token["']\)/.test(fs.readFileSync(file, "utf8")));
  assert.deepEqual(offenders.map(f => path.relative(root, f)), []);
});
