# Auralyn Replit update v2

This ZIP includes the original v1 hardening bundle plus a second-stage dashboard and Medium implementation review bundle.

## What v1 already included

- Persistent Postgres-backed audit hash chain.
- Authenticated, origin-checked, PHI-minimized WebSocket stream.
- Hardened `/api/agent-brain` routes with auth, role checks, CSRF, rate limits, and Zod validation.
- Cookie/CSRF frontend auth path replacing `localStorage` bearer-token dependence.
- Rule-based brain + LLM fleet bridge that prevents LLM downgrades of deterministic risk.
- Persistent loop/cycle state scaffolding.

## What v2 adds

- Dashboard functionality review.
- Medium article implementation traceability review.
- Replit/Claude integration prompt for stage 2.
- Redacted React WebSocket hook: `client/src/lib/patientStream.ts`.
- Dashboard helper utilities and endpoint contract.
- Manual merge patches for AgentBrainPage, AdminDashboard audit export, and Ops Assistant hardening.
- Static check scripts for dashboard endpoints, localStorage auth leakage, and Medium traceability.
- Static test to prevent future `app_auth_token` localStorage usage.

## Suggested order

1. Apply v1 backend security hardening first.
2. Replace/merge `client/src/lib/queryClient.ts` and `client/src/context/AuthContext.tsx`.
3. Add the v2 helper files under `client/src/lib`.
4. Manually merge the patches under `patches/`.
5. Run:

```bash
node scripts/check-dashboard-contract.mjs
node scripts/medium-traceability-check.mjs
npm run typecheck
npm test
npm run build
```

## Important caveat

The dashboard review is based on the uploaded dashboard snippets and endpoint lists, not a live click-through of the full Replit app. Use the static scripts and Replit staging branch to validate every button and monitor against the actual repo.
