import { useCallback, useEffect, useRef, useState } from "react";

export type PatientStreamRiskLevel = "LOW" | "MODERATE" | "HIGH" | "CRITICAL" | string;

export interface PatientStreamEvent {
  type: "connected" | "agent_cycle" | string;
  patientRef?: string;
  risk?: {
    level?: PatientStreamRiskLevel;
    score?: number;
    flagCount?: number;
    flags?: string[];
  };
  routing?: {
    destination?: string;
    urgency?: string;
  };
  icu?: {
    needsICU?: boolean;
    urgency?: string;
  };
  auditHash?: string;
  ts?: number;
  elevated?: boolean;
}

export interface UsePatientStreamOptions {
  enabled?: boolean;
  maxEvents?: number;
  reconnectBaseMs?: number;
  reconnectMaxMs?: number;
}

export interface UsePatientStreamResult {
  connected: boolean;
  lastEvent: PatientStreamEvent | null;
  events: string[];
  rawEvents: PatientStreamEvent[];
  reconnectNow: () => void;
  clearEvents: () => void;
}

function streamUrl(): string {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${protocol}//${window.location.host}/ws/patient-stream`;
}

function describeEvent(event: PatientStreamEvent): string {
  const t = new Date(event.ts ?? Date.now()).toLocaleTimeString();
  if (event.type === "connected") return `✓ Connected at ${t}`;
  if (event.type === "agent_cycle") {
    const ref = event.patientRef || "redacted-patient";
    const level = event.risk?.level ?? "UNKNOWN";
    const route = event.routing?.destination ? ` → ${event.routing.destination}` : "";
    const audit = event.auditHash ? ` · audit ${event.auditHash}` : "";
    return `[${t}] ${ref} → ${level}${route}${audit}`;
  }
  return `[${t}] ${event.type}`;
}

function safeParseEvent(raw: string): PatientStreamEvent | null {
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    // Enforce the redacted contract on the client too. If a legacy backend leaks raw patientId,
    // do not display it in the live stream.
    if ("patientId" in parsed && !("patientRef" in parsed)) {
      parsed.patientRef = "legacy-id-redacted";
      delete parsed.patientId;
    }
    if ("name" in parsed) delete parsed.name;
    if (parsed.vitals && process.env.NODE_ENV === "production") delete parsed.vitals;
    return parsed as PatientStreamEvent;
  } catch {
    return null;
  }
}

export function usePatientStream(options: UsePatientStreamOptions = {}): UsePatientStreamResult {
  const {
    enabled = true,
    maxEvents = 50,
    reconnectBaseMs = 1_500,
    reconnectMaxMs = 15_000,
  } = options;

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectAttemptRef = useRef(0);
  const manuallyClosedRef = useRef(false);

  const [connected, setConnected] = useState(false);
  const [lastEvent, setLastEvent] = useState<PatientStreamEvent | null>(null);
  const [events, setEvents] = useState<string[]>([]);
  const [rawEvents, setRawEvents] = useState<PatientStreamEvent[]>([]);

  const clearReconnectTimer = useCallback(() => {
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
  }, []);

  const clearEvents = useCallback(() => {
    setEvents([]);
    setRawEvents([]);
    setLastEvent(null);
  }, []);

  const connect = useCallback(() => {
    if (!enabled) return;
    if (wsRef.current?.readyState === WebSocket.OPEN || wsRef.current?.readyState === WebSocket.CONNECTING) return;

    clearReconnectTimer();
    manuallyClosedRef.current = false;

    const ws = new WebSocket(streamUrl());
    wsRef.current = ws;

    ws.onopen = () => {
      reconnectAttemptRef.current = 0;
      setConnected(true);
      const event: PatientStreamEvent = { type: "connected", ts: Date.now() };
      setLastEvent(event);
      setRawEvents(prev => [event, ...prev].slice(0, maxEvents));
      setEvents(prev => [describeEvent(event), ...prev].slice(0, maxEvents));
    };

    ws.onmessage = ev => {
      if (typeof ev.data !== "string") return;
      const event = safeParseEvent(ev.data);
      if (!event) return;
      setLastEvent(event);
      setRawEvents(prev => [event, ...prev].slice(0, maxEvents));
      setEvents(prev => [describeEvent(event), ...prev].slice(0, maxEvents));
    };

    ws.onerror = () => {
      // Do not leak connection details into the UI. onclose will handle reconnect.
    };

    ws.onclose = () => {
      setConnected(false);
      wsRef.current = null;
      if (manuallyClosedRef.current || !enabled) return;
      reconnectAttemptRef.current += 1;
      const delay = Math.min(reconnectMaxMs, reconnectBaseMs * 2 ** Math.min(5, reconnectAttemptRef.current));
      reconnectTimerRef.current = setTimeout(connect, delay);
    };
  }, [clearReconnectTimer, enabled, maxEvents, reconnectBaseMs, reconnectMaxMs]);

  const reconnectNow = useCallback(() => {
    clearReconnectTimer();
    reconnectAttemptRef.current = 0;
    if (wsRef.current) {
      manuallyClosedRef.current = true;
      wsRef.current.close();
      wsRef.current = null;
    }
    setConnected(false);
    connect();
  }, [clearReconnectTimer, connect]);

  useEffect(() => {
    if (!enabled) return undefined;
    connect();
    return () => {
      manuallyClosedRef.current = true;
      clearReconnectTimer();
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [clearReconnectTimer, connect, enabled]);

  return { connected, lastEvent, events, rawEvents, reconnectNow, clearEvents };
}
