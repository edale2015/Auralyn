export function filenameFromContentDisposition(header: string | null, fallback: string): string {
  if (!header) return fallback;
  const quoted = /filename="([^"]+)"/i.exec(header)?.[1];
  if (quoted) return quoted.replace(/[\\/]/g, "_");
  const bare = /filename=([^;]+)/i.exec(header)?.[1];
  return (bare || fallback).trim().replace(/[\\/]/g, "_");
}

export async function downloadResponseAsFile(response: Response, fallbackFilename: string): Promise<void> {
  const blob = await response.blob();
  const filename = filenameFromContentDisposition(response.headers.get("content-disposition"), fallbackFilename);
  const url = URL.createObjectURL(blob);
  try {
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}
