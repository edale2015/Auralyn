export type DashboardRole = "admin" | "physician" | "staff" | "patient";
export type HttpMethod = "GET" | "POST" | "PATCH" | "PUT" | "DELETE";

export interface DashboardEndpoint {
  method?: HttpMethod;
  transport?: "http" | "websocket";
  endpoint: string;
  label: string;
  minimumRole?: DashboardRole;
  csrf?: boolean;
  audit?: boolean;
  invalidates?: string[];
  redactedPayload?: boolean;
  clinicalDecisionSupportOnly?: boolean;
}

export const agentBrainControls: DashboardEndpoint[] = [
  {
    label: "Start autonomous loop",
    method: "POST",
    endpoint: "/api/agent-brain/loop/start",
    minimumRole: "physician",
    csrf: true,
    audit: true,
    invalidates: ["/api/agent-brain/status", "/api/agent-brain/heatmap", "/api/agent-brain/insights", "/api/agent-brain/cycle-results", "/api/agent-brain/audit"],
  },
  {
    label: "Stop autonomous loop",
    method: "POST",
    endpoint: "/api/agent-brain/loop/stop",
    minimumRole: "physician",
    csrf: true,
    audit: true,
    invalidates: ["/api/agent-brain/status", "/api/agent-brain/audit"],
  },
  {
    label: "Run manual cycle",
    method: "POST",
    endpoint: "/api/agent-brain/cycle",
    minimumRole: "staff",
    csrf: true,
    audit: true,
    invalidates: ["/api/agent-brain/status", "/api/agent-brain/heatmap", "/api/agent-brain/insights", "/api/agent-brain/cycle-results", "/api/agent-brain/audit"],
  },
  {
    label: "Simulate",
    method: "POST",
    endpoint: "/api/agent-brain/simulate",
    minimumRole: "staff",
    csrf: true,
    audit: false,
  },
];

export const agentBrainMonitors: DashboardEndpoint[] = [
  { label: "Loop status", method: "GET", endpoint: "/api/agent-brain/status" },
  { label: "Patient heatmap", method: "GET", endpoint: "/api/agent-brain/heatmap" },
  { label: "Insights", method: "GET", endpoint: "/api/agent-brain/insights" },
  { label: "Audit", method: "GET", endpoint: "/api/agent-brain/audit" },
  { label: "Live stream", transport: "websocket", endpoint: "/ws/patient-stream", redactedPayload: true },
];

const roleRank: Record<DashboardRole, number> = { patient: 0, staff: 1, physician: 2, admin: 3 };

export function canUseDashboardEndpoint(userRole: DashboardRole | undefined, endpoint: DashboardEndpoint): boolean {
  if (!endpoint.minimumRole) return true;
  if (!userRole) return false;
  return roleRank[userRole] >= roleRank[endpoint.minimumRole];
}
