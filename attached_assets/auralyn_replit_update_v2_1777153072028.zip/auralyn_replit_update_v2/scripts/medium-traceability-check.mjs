#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const expectedFeeds = [
  "https://medium.com/feed/tag/artificial-intelligence",
  "https://medium.com/feed/tag/machine-learning",
  "https://medium.com/feed/tag/large-language-models",
  "https://medium.com/feed/tag/generative-ai",
  "https://medium.com/feed/tag/llm",
  "https://medium.com/feed/tag/chatgpt",
  "https://medium.com/feed/tag/openai",
  "https://medium.com/feed/tag/prompt-engineering",
  "https://medium.com/feed/tag/ai-agents",
  "https://medium.com/feed/tag/rag",
  "https://medium.com/feed/tag/langchain",
];
const expectedList = "https://medium.com/@erwindale2000/list/chatgpt-be348691fe82";

function walk(dir, acc = []) {
  if (!fs.existsSync(dir)) return acc;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!["node_modules", ".git", "dist", "build", ".cache"].includes(entry.name)) walk(full, acc);
    } else if (/\.(ts|tsx|js|jsx|json|md)$/.test(entry.name)) {
      acc.push(full);
    }
  }
  return acc;
}

const files = walk(root);
const haystack = files.map(f => fs.readFileSync(f, "utf8")).join("\n");

const feedStatus = expectedFeeds.map(feed => ({ feed, present: haystack.includes(feed) }));
const listStatus = { url: expectedList, present: haystack.includes(expectedList) };

const possibleTraceabilityFiles = files
  .map(f => path.relative(root, f))
  .filter(f => /traceability|researchReviews|agentHandoffs|researchArticles|medium/i.test(f));

const report = {
  generatedAt: new Date().toISOString(),
  feedStatus,
  savedList: listStatus,
  possibleTraceabilityFiles,
  nextRequiredEvidence: [
    "approved article URLs/titles",
    "researchReviews verdicts and safety notes",
    "agentHandoffs approval status",
    "implementation file paths for each approved article",
    "tests and audit hashes for each promotion"
  ]
};

console.log(JSON.stringify(report, null, 2));

const missingFeeds = feedStatus.filter(f => !f.present);
if (missingFeeds.length) {
  console.error(`\nWARN: ${missingFeeds.length} expected Medium feed URL(s) were not found in this repo scan.`);
}
if (!listStatus.present) {
  console.error("WARN: Expected saved Medium list URL was not found in this repo scan.");
}
