#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const candidateFiles = [
  "client/src/lib/queryClient.ts",
  "client/src/context/AuthContext.tsx",
  "client/src/pages/AgentBrainPage.tsx",
  "client/src/pages/AdminDashboard.tsx",
  "client/src/pages/AuralynDashboard.tsx",
  "client/src/pages/PhysicianDashboard.tsx",
];

function read(rel) {
  const abs = path.join(root, rel);
  if (!fs.existsSync(abs)) return null;
  return fs.readFileSync(abs, "utf8");
}

const endpointPattern = /["'](\/(?:api|ws)\/[^"'`\s)]+)["']/g;
const findings = [];
let failures = 0;

for (const rel of candidateFiles) {
  const text = read(rel);
  if (text === null) {
    findings.push({ file: rel, status: "missing" });
    continue;
  }

  const endpoints = [...text.matchAll(endpointPattern)].map(m => m[1]).sort();
  const localStorageAuth = /localStorage\.(?:getItem|setItem|removeItem)\(["']app_auth_token["']\)/.test(text);
  const rawBearer = /Authorization\s*:\s*`?Bearer/.test(text) || /headers\.set\(["']Authorization["']/.test(text);
  const websocketPatientStream = /new\s+WebSocket\([^)]*\/ws\/patient-stream/.test(text);
  const hasCredentialsInclude = /credentials\s*:\s*["']include["']/.test(text);

  if (localStorageAuth) failures++;

  findings.push({
    file: rel,
    status: "scanned",
    endpoints: [...new Set(endpoints)],
    localStorageAuth,
    rawBearer,
    websocketPatientStream,
    hasCredentialsInclude,
  });
}

console.log(JSON.stringify({ generatedAt: new Date().toISOString(), findings }, null, 2));

if (failures > 0) {
  console.error(`\nFAIL: Found ${failures} file(s) reading app_auth_token from localStorage.`);
  process.exit(1);
}
