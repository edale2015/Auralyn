-- Auralyn Agent Brain hardening migration
-- Apply with your existing Replit/Postgres migration runner.

BEGIN;

-- Existing audit_logs table is used by the new persistent hash chain.
CREATE INDEX IF NOT EXISTS idx_audit_logs_hash ON audit_logs(hash);
CREATE INDEX IF NOT EXISTS idx_audit_logs_prev_hash ON audit_logs(prev_hash);
CREATE UNIQUE INDEX IF NOT EXISTS uq_audit_logs_hash_nonnull ON audit_logs(hash) WHERE hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS agent_loop_state (
  id            text PRIMARY KEY DEFAULT 'main',
  running       boolean NOT NULL DEFAULT false,
  cycle_count   integer NOT NULL DEFAULT 0,
  last_cycle_at timestamp,
  started_at    timestamp,
  errors        integer NOT NULL DEFAULT 0,
  updated_at    timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO agent_loop_state (id, running, cycle_count, errors)
VALUES ('main', false, 0, 0)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS agent_cycle_results (
  id              bigserial PRIMARY KEY,
  patient_id      text NOT NULL,
  clinic_site_id  text,
  risk            jsonb NOT NULL DEFAULT '{}'::jsonb,
  icu             jsonb NOT NULL DEFAULT '{}'::jsonb,
  safety          jsonb NOT NULL DEFAULT '{}'::jsonb,
  routing         jsonb NOT NULL DEFAULT '{}'::jsonb,
  insights        jsonb NOT NULL DEFAULT '[]'::jsonb,
  audit_hash      text,
  result_redacted jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_agent_cycle_results_patient_created
  ON agent_cycle_results(patient_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_cycle_results_created
  ON agent_cycle_results(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_cycle_results_audit_hash
  ON agent_cycle_results(audit_hash);

COMMIT;
