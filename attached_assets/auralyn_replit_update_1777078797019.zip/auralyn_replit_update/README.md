# Auralyn Replit update: clinical-safety, PHI, audit, auth, and agent hardening

This bundle is designed to be copied into the repo root in Replit. It is based on the slices you provided, not a full repository checkout, so a few integration points may need path/name alignment with your existing auth route and Drizzle setup.

## What this implements

1. **Persistent tamper-evident audit chain**
   - Uses the existing `audit_logs` table instead of the in-memory-only 500-entry chain.
   - Recovers chain head from Postgres after restart.
   - Uses a Postgres advisory transaction lock so concurrent writers do not fork the chain.
   - Adds async `appendAuditEvent()` and `getAuditChainAsync()` while leaving legacy sync functions for old call sites.

2. **PHI-minimized WebSocket stream**
   - Requires authenticated clinical users for `/ws/patient-stream`.
   - Validates origin.
   - Sends redacted `patientRef` by default instead of raw patient id/name/full vitals.
   - Allows vitals only for same-tenant clinical users when `AURALYN_WS_ALLOW_VITALS=true`.

3. **Agent Brain API hardening**
   - Requires auth and clinical roles.
   - Adds request rate limiting.
   - Validates all manual-cycle vitals with Zod.
   - Makes loop start/stop physician/admin-only.
   - Returns scrubbed cycle payloads.

4. **Rule-based brain plus LLM fleet bridge**
   - Runs deterministic rule scoring first.
   - Calls the multi-agent LLM fleet only when risk is elevated, ambiguous, or explicitly forced.
   - Never lets the LLM downgrade deterministic risk.
   - Adds an “independent review basis” object for physician-visible reasoning.

5. **Cookie-based auth client path**
   - Removes Bearer token storage from `localStorage`.
   - Uses HttpOnly server cookie sessions plus a readable CSRF cookie for mutating requests.
   - Keeps Bearer-token fallback available server-side for transition only.

6. **Persistent loop/cycle data store scaffolding**
   - Adds migration for loop state and cycle result tables.
   - Provides raw-SQL persistence helpers so you do not need to immediately remodel all Drizzle schema types.

## Install/apply

1. Copy this bundle over your repo root, preserving paths.
2. Apply `migrations/20260424_agent_brain_hardening.sql` to Postgres.
3. Replace these files with the provided versions:
   - `server/audit/hashChain.ts`
   - `server/ws/patientStream.ts`
   - `server/routes/agentBrainRoutes.ts`
   - `client/src/context/AuthContext.tsx`
   - `client/src/lib/queryClient.ts`
4. Add these new files:
   - `server/security/session.ts`
   - `server/security/rateLimit.ts`
   - `server/security/phi.ts`
   - `server/security/authCookies.ts`
   - `server/agents/clinicalDecisionBridge.ts`
   - `server/agents/persistentLoopState.ts`
   - `server/simulation/trajectoryDigitalTwin.ts`
5. Apply the manual diffs in `patches/`:
   - `brainOrchestrator.integration.diff`
   - `agentFleetOrchestrator.safety.diff`
   - `roleAuth.cookie.integration.diff`

## Environment variables

Recommended defaults:

```bash
JWT_SECRET="replace-with-strong-secret"
AUTH_COOKIE_NAME="app_session"
ALLOWED_WS_ORIGINS="https://your-replit-domain.replit.app,https://your-production-domain.com"
PHI_REF_SALT="replace-with-strong-random-salt"
AURALYN_WS_ALLOW_VITALS="false"
AURALYN_FLEET_MODEL="gpt-4o"
AGENT_BRAIN_RESUME_LOOP="false"
```

## Important clinical note

This patch hardens software behavior. It does **not** clinically validate the risk thresholds, digital twin outputs, or triage policy. Treat the application as physician-facing decision support unless and until a qualified clinical governance process validates thresholds, intended use, contraindications, safety cases, and labeling.
