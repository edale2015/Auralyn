import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { getCsrfToken } from "../lib/queryClient";

type AuthUser = {
  userId: string;
  email?: string;
  displayName?: string;
  role: "admin" | "physician" | "staff" | "patient";
  organizationId?: string;
  isActive: boolean;
};

type AuthContextValue = {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  authFetch: typeof fetch;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function loadMe() {
      try {
        const res = await fetch("/api/roleAuth/me", { credentials: "include" });
        if (!res.ok) throw new Error("Not authenticated");
        const data = await res.json();
        if (!cancelled) setUser(data.user ?? null);
      } catch {
        if (!cancelled) setUser(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    loadMe();
    return () => { cancelled = true; };
  }, []);

  async function login(email: string, password: string) {
    const res = await fetch("/api/roleAuth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Login failed");
    setUser(data.user ?? null);
  }

  async function logout() {
    await fetch("/api/roleAuth/logout", {
      method: "POST",
      credentials: "include",
      headers: { "x-csrf-token": getCsrfToken() ?? "" },
    }).catch(() => undefined);
    setUser(null);
  }

  const authFetch: typeof fetch = (input, init = {}) => {
    const headers = new Headers((init as RequestInit).headers || {});
    const method = ((init as RequestInit).method || "GET").toUpperCase();
    if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
      const csrf = getCsrfToken();
      if (csrf) headers.set("x-csrf-token", csrf);
    }
    return fetch(input as RequestInfo, {
      ...(init as RequestInit),
      credentials: "include",
      headers,
    });
  };

  const value = useMemo(() => ({ user, loading, login, logout, authFetch }), [user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
