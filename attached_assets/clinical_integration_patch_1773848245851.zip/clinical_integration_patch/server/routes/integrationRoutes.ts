import { Router } from 'express';
import { tuneRuleWeights } from '../engines/rlhfWeightTuningEngine';
import { findSimilarCases, boostFromMemory } from '../engines/caseMemoryEngine';
import { telegramWebhookHandler } from '../integrations/telegramBot';
import { whatsappWebhookHandler } from '../integrations/whatsappFlow';

const router = Router();

router.post('/rlhf/tune', async (req, res) => {
  const updates = tuneRuleWeights(req.body.outcomes ?? [], req.body.weights ?? {});
  res.json({ count: updates.length, updates });
});

router.post('/memory/similar', async (req, res) => {
  const similar = findSimilarCases(req.body.currentCase, req.body.memory ?? [], req.body.limit ?? 5);
  res.json({ similar, boost: boostFromMemory(similar) });
});

router.post('/telegram/webhook', telegramWebhookHandler);
router.post('/whatsapp/webhook', whatsappWebhookHandler);

export default router;
