export type CaseMemoryRecord = {
  encounterId: string;
  complaintId: string;
  system: string;
  symptomKeys: string[];
  modifierKeys: string[];
  diagnosis: string;
  disposition: string;
  timestamp: string;
};

export type SimilarCase = {
  caseRecord: CaseMemoryRecord;
  score: number;
  overlaps: string[];
};

function jaccard(a: string[], b: string[]) {
  const sa = new Set(a);
  const sb = new Set(b);
  const intersection = [...sa].filter((x) => sb.has(x));
  const union = new Set([...sa, ...sb]);
  return {
    score: union.size === 0 ? 0 : intersection.length / union.size,
    overlaps: intersection
  };
}

export function findSimilarCases(
  current: Pick<CaseMemoryRecord, 'system' | 'symptomKeys' | 'modifierKeys'>,
  memory: CaseMemoryRecord[],
  limit = 5
): SimilarCase[] {
  const currentKeys = [...current.symptomKeys, ...current.modifierKeys];

  return memory
    .filter((item) => item.system === current.system)
    .map((item) => {
      const itemKeys = [...item.symptomKeys, ...item.modifierKeys];
      const result = jaccard(currentKeys, itemKeys);
      return {
        caseRecord: item,
        score: Number(result.score.toFixed(4)),
        overlaps: result.overlaps
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

export function boostFromMemory(similar: SimilarCase[]) {
  const diagnosisVotes = new Map<string, number>();
  const dispositionVotes = new Map<string, number>();

  for (const item of similar) {
    diagnosisVotes.set(
      item.caseRecord.diagnosis,
      (diagnosisVotes.get(item.caseRecord.diagnosis) ?? 0) + item.score
    );
    dispositionVotes.set(
      item.caseRecord.disposition,
      (dispositionVotes.get(item.caseRecord.disposition) ?? 0) + item.score
    );
  }

  return {
    diagnoses: [...diagnosisVotes.entries()].sort((a, b) => b[1] - a[1]),
    dispositions: [...dispositionVotes.entries()].sort((a, b) => b[1] - a[1])
  };
}
