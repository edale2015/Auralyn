# Clinical Integration Roadmap

This roadmap is grounded in the uploaded workbook `MedAssistNovember18 (1).xlsx`.

## What is already present in the workbook

Core global control sheets are present for the pack architecture:
- `COMPLAINT_REGISTRY`
- `CHIEF_COMPLAINT_ROUTER`
- `GLOBAL_MODIFIERS_CLEAN`
- `GLOBAL_CLUSTER_TRIAGE`
- `GLOBAL_SECONDARY`
- `RULESTRIGGERS`
- `CLUSTER_SCORING_RULES`
- `OUTPUT_TEMPLATES`
- `GLOBAL_MEDICATIONS_FINAL`
- `GLOBAL_STANDARDIZED_MEDGROUPS`
- `MED_TO_CONDITION_TRIGGERS`
- `INTEGRATION_MAP`
- `GLOBAL_FLOWSHEET_ALL_SYSTEMS`

The workbook has 211 sheets, including many system-specific tabs for ENT, GI, Pulm, Neuro, Derm, Endo, Ortho, Oph, Psychiatry, Toxicology, and UroGyn.

## What still needs to be finished to complete integration

### 1. Canonical system normalization
The workbook uses inconsistent system labels across major sheets. Examples include:
- `ENT` vs `Ent`
- `GI` vs `Gastroenterology`
- `CARD` vs `Cardiology`
- `PULM` vs `Pulmonology`
- `GU` vs `UroGyn`
- `MSK` vs `Orthopedics`
- `ID` vs `Infectious` vs `Infectious Disease`

Until a canonical mapping layer exists, joins across sheets will be brittle.

### 2. Complaint registry coverage
`COMPLAINT_REGISTRY` currently contains 25 data rows across 10 normalized systems, while the workbook clearly contains far more system-specific logic and content. The registry needs expansion or automated generation from the system index sheets so every supported complaint is routable.

### 3. Modifier coverage
`GLOBAL_MODIFIERS_CLEAN` is sparse relative to the rest of the workbook. It contains only a small number of system entries and is dominated by `GEN`, with limited `CARD` and `PULM`. The modifier layer needs either:
- expansion from `CLINICAL_MODIFIERS` and related tabs, or
- a deliberate rule that most complaints inherit the global set plus optional system overlays.

### 4. Rule migration
`RULESTRIGGERS` currently has very few populated rows compared with the size of `GLOBAL_SECONDARY`, `GLOBAL_CLUSTER_TRIAGE`, and `GLOBAL_MEDICATIONS_FINAL`. Rule content likely remains split between:
- `RULESTRIGGERS`
- `Rules_Triggers`
- system-specific rule tabs such as `ENT_FLU_RULES`

This must be merged into one executable rule format.

### 5. Routing completeness
`CHIEF_COMPLAINT_ROUTER` currently has fewer entries than the workbook’s likely total complaint count. Routing needs to be generated or audited against:
- `COMPLAINT_REGISTRY`
- `*_SystemIndex` sheets
- `GLOBAL_FLOWSHEET_ALL_SYSTEMS`

### 6. Template and plan linkage
`OUTPUT_TEMPLATES` exists, but every complaint and disposition set must be linked to a valid template set id. This should be checked automatically with a foreign-key style validator.

### 7. Medication linkage and safety logic
Medication data is rich, but safe prescribing requires these joins to be validated:
- diagnosis -> medication rows
- medication group -> contraindications
- modifiers -> cautions and interactions
- medications -> follow-up plan snippets

### 8. Traceability and audit wiring
Sheets like `TRACE_LOG`, `Rules_Fired`, `MD_Actions`, and `QA_Log` exist. The runtime needs to write into a normalized audit stream so every recommendation can be reconstructed.

### 9. Messaging channel constraints
Telegram and WhatsApp intake cannot carry the full richness of the web UI. Every complaint pack needs a compact mobile projection:
- yes/no first
- short radio groups second
- free text last

### 10. Outcome logging and supervised learning loop
The self-improving loop will be weak until you have a reliable way to capture:
- predicted diagnosis/disposition
- clinician final diagnosis/disposition
- missing questions
- override reason
- downstream outcome

### 11. EHR and real patient data boundary
Before real deployment, decide what remains outside the AI and what goes into the EHR:
- intake only
- draft assessment/plan only
- triage suggestions only
- medication suggestions only

### 12. Production hardening
Before release, add:
- auth and RBAC
- PHI-safe logging
- secrets management
- retry and dead-letter queues for messaging/EHR
- monitoring and alerting
- versioned pack releases

## Recommended finish order

1. Canonical mapping layer for systems, complaints, and IDs
2. Coverage dashboard with workbook-wide join validation
3. Auto pack generation from registry/router/system index sheets
4. Rule merge and execution migration
5. Template and medication foreign-key validation
6. Self-improvement loop with physician approval queue
7. Case memory retrieval and similarity boost
8. Telegram and WhatsApp compact intake deployment
9. Outcome logging and EHR sync boundary
10. Production hardening and staged rollout
