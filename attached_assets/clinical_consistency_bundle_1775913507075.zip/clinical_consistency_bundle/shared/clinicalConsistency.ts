export type Disposition =
  | 'home_supportive_care'
  | 'home_with_rx'
  | 'follow_up_primary_care'
  | 'same_day_urgent_care'
  | 'er_now'
  | 'hospital_admission';

export type ConfidenceBand = 'low' | 'moderate' | 'high';

export type TreatmentClass =
  | 'none'
  | 'supportive'
  | 'antibiotic'
  | 'antiviral'
  | 'steroid'
  | 'bronchodilator'
  | 'topical'
  | 'antifungal';

export interface ClinicalFeatureMap {
  [key: string]: boolean | number | string | null | undefined;
}

export interface SyndromeCandidate {
  syndromeId: string;
  label: string;
  score: number;
  rationale: string[];
  requiredFeaturesMet: boolean;
}

export interface CanonicalTreatmentPlan {
  class: TreatmentClass;
  medicationKey?: string;
  indication: string;
  whyChosen: string[];
  whyNotBroader: string[];
  blockedAlternatives: string[];
}

export interface CanonicalDispositionPlan {
  disposition: Disposition;
  urgency: number;
  rationale: string[];
  redFlagsTriggered: string[];
  followUpWindow?: string;
}

export interface EvidenceRequirement {
  evidenceKey: string;
  reason: string;
  met: boolean;
}

export interface CanonicalDecision {
  complaint: string;
  phenotypeHash: string;
  confidence: ConfidenceBand;
  winningSyndrome: SyndromeCandidate | null;
  alternatives: SyndromeCandidate[];
  treatment: CanonicalTreatmentPlan;
  disposition: CanonicalDispositionPlan;
  evidenceRequirements: EvidenceRequirement[];
  evidenceLockTriggered: boolean;
  notesForClinician: string[];
  varianceWarnings: string[];
}

export interface RegistryRecord {
  phenotypeHash: string;
  complaint: string;
  canonicalDecision: CanonicalDecision;
  firstSeenAt: string;
  lastSeenAt: string;
  occurrenceCount: number;
  createdBy?: string;
}

export interface VarianceEvent {
  phenotypeHash: string;
  complaint: string;
  clinicianId?: string;
  clinicianName?: string;
  selectedDisposition?: string;
  selectedMedicationKey?: string;
  canonicalDisposition: string;
  canonicalMedicationKey?: string;
  warnings: string[];
  createdAt: string;
}

export interface LeaderboardEntry {
  complaint: string;
  clinicianId?: string;
  clinicianName?: string;
  totalCases: number;
  varianceCases: number;
  varianceRate: number;
  medicationVarianceCases: number;
  dispositionVarianceCases: number;
}

export interface PathwayRuleSet {
  syndromeId: string;
  complaint: string;
  label: string;
  required: string[];
  positiveWeights: Record<string, number>;
  negativeWeights: Record<string, number>;
  exclusions?: string[];
  evidenceRequirements?: string[];
  treatmentCeiling?: TreatmentClass;
  canonicalMedicationKey?: string;
  defaultDisposition?: Disposition;
}
