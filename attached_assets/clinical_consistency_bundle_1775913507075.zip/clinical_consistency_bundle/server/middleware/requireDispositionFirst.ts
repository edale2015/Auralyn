import { NextFunction, Request, Response } from 'express';
import { runDispositionFirstWorkflow } from '../services/dispositionFirstWorkflow';

export function requireDispositionFirst(req: Request, res: Response, next: NextFunction): void {
  try {
    const { complaint, features, medicationOrders } = req.body ?? {};
    if (!complaint || !features) {
      res.status(400).json({ ok: false, error: 'complaint and features are required' });
      return;
    }

    const result = runDispositionFirstWorkflow({ complaint, features, medicationOrders });
    (req as any).dispositionFirst = result;

    if (!result.allowedToFinalize) {
      res.status(409).json({
        ok: false,
        error: 'Disposition-first workflow blocked finalization',
        blockingReasons: result.blockingReasons,
        canonical: result.canonical,
      });
      return;
    }

    next();
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error?.message ?? 'Disposition-first middleware failure' });
  }
}
