CREATE TABLE IF NOT EXISTS phenotype_registry (
  phenotype_hash VARCHAR(64) NOT NULL,
  complaint VARCHAR(128) NOT NULL,
  canonical_decision JSONB NOT NULL,
  first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  occurrence_count INTEGER NOT NULL DEFAULT 1,
  created_by VARCHAR(128),
  PRIMARY KEY (phenotype_hash, complaint)
);

CREATE TABLE IF NOT EXISTS variance_events (
  id BIGSERIAL PRIMARY KEY,
  phenotype_hash VARCHAR(64) NOT NULL,
  complaint VARCHAR(128) NOT NULL,
  clinician_id VARCHAR(128),
  clinician_name VARCHAR(255),
  selected_disposition VARCHAR(128),
  selected_medication_key VARCHAR(128),
  canonical_disposition VARCHAR(128) NOT NULL,
  canonical_medication_key VARCHAR(128),
  warnings JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS clinical_pathway_rules (
  syndrome_id VARCHAR(128) PRIMARY KEY,
  complaint VARCHAR(128) NOT NULL,
  label VARCHAR(255) NOT NULL,
  required JSONB NOT NULL,
  positive_weights JSONB NOT NULL,
  negative_weights JSONB NOT NULL,
  exclusions JSONB,
  evidence_requirements JSONB,
  treatment_ceiling VARCHAR(64),
  canonical_medication_key VARCHAR(128),
  default_disposition VARCHAR(64),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
