import { ClinicalFeatureMap, SyndromeCandidate, PathwayRuleSet } from '../../shared/clinicalConsistency';

export interface SyndromeRule extends PathwayRuleSet {}

export const DEFAULT_RULES: SyndromeRule[] = [
  {
    syndromeId: 'viral_pharyngitis',
    label: 'Viral pharyngitis / URI syndrome',
    complaint: 'sore_throat',
    required: ['sore_throat'],
    positiveWeights: { cough: 2, rhinorrhea: 2, hoarseness: 2, conjunctivitis: 1, low_grade_fever: 1 },
    negativeWeights: { tonsillar_exudate: 2, tender_anterior_cervical_nodes: 2, fever_over_38: 2, no_cough: 1 },
    treatmentCeiling: 'supportive',
    defaultDisposition: 'home_supportive_care',
  },
  {
    syndromeId: 'gas_centor_compatible',
    label: 'Group A strep compatible syndrome',
    complaint: 'sore_throat',
    required: ['sore_throat'],
    positiveWeights: { tonsillar_exudate: 3, tender_anterior_cervical_nodes: 2, fever_over_38: 2, no_cough: 2 },
    negativeWeights: { cough: 2, rhinorrhea: 2, hoarseness: 1 },
    evidenceRequirements: ['positive_strep_test'],
    canonicalMedicationKey: 'strep_narrow_first_line',
    treatmentCeiling: 'antibiotic',
    defaultDisposition: 'home_with_rx',
  },
  {
    syndromeId: 'asymptomatic_bacteriuria',
    label: 'Asymptomatic bacteriuria',
    complaint: 'urine_result_review',
    required: ['positive_urine_test', 'no_urinary_symptoms'],
    positiveWeights: { positive_urine_test: 3, no_urinary_symptoms: 3 },
    negativeWeights: { dysuria: 3, frequency: 2, urgency: 2, flank_pain: 3, fever_over_38: 3 },
    treatmentCeiling: 'none',
    defaultDisposition: 'follow_up_primary_care',
  },
  {
    syndromeId: 'simple_cystitis',
    label: 'Acute uncomplicated cystitis',
    complaint: 'urinary_symptoms',
    required: ['dysuria'],
    positiveWeights: { dysuria: 3, frequency: 2, urgency: 2, no_vaginal_discharge: 1 },
    negativeWeights: { flank_pain: 3, fever_over_38: 3, vomiting: 2, pregnancy_high_risk: 2 },
    evidenceRequirements: ['dysuria'],
    canonicalMedicationKey: 'narrow_uti_first_line',
    treatmentCeiling: 'antibiotic',
    defaultDisposition: 'home_with_rx',
  },
  {
    syndromeId: 'bacterial_vaginosis_symptomatic',
    label: 'Symptomatic bacterial vaginosis',
    complaint: 'vaginal_discharge',
    required: ['vaginal_discharge'],
    positiveWeights: { thin_gray_discharge: 2, fishy_odor: 3 },
    negativeWeights: { no_vaginal_symptoms: 4, pelvic_pain: 2, fever_over_38: 2 },
    evidenceRequirements: ['vaginal_discharge'],
    canonicalMedicationKey: 'bv_first_line',
    treatmentCeiling: 'topical',
    defaultDisposition: 'home_with_rx',
  },
  {
    syndromeId: 'influenza_like_illness',
    label: 'Influenza-like illness',
    complaint: 'flu_like',
    required: ['feverish_or_fever', 'body_aches'],
    positiveWeights: { feverish_or_fever: 3, body_aches: 2, acute_onset: 2, cough: 1, sick_contacts: 1 },
    negativeWeights: { dysuria: 2, vaginal_discharge: 2, isolated_sore_throat_only: 1 },
    evidenceRequirements: ['feverish_or_fever', 'body_aches'],
    canonicalMedicationKey: 'consider_targeted_antiviral',
    treatmentCeiling: 'antiviral',
    defaultDisposition: 'home_supportive_care',
  },
];

function hasFeature(features: ClinicalFeatureMap, key: string): boolean {
  return Boolean(features[key]);
}

export function scoreSyndromes(
  complaint: string,
  features: ClinicalFeatureMap,
  rules: SyndromeRule[] = DEFAULT_RULES,
): SyndromeCandidate[] {
  const candidates = rules.filter((r) => r.complaint === complaint);

  return candidates
    .map((rule) => {
      const requiredFeaturesMet = rule.required.every((req) => hasFeature(features, req));
      let score = requiredFeaturesMet ? 5 : -999;
      const rationale: string[] = [];

      for (const [k, w] of Object.entries(rule.positiveWeights)) {
        if (hasFeature(features, k)) {
          score += w;
          rationale.push(`+${w} ${k}`);
        }
      }

      for (const [k, w] of Object.entries(rule.negativeWeights)) {
        if (hasFeature(features, k)) {
          score -= w;
          rationale.push(`-${w} ${k}`);
        }
      }

      if (rule.exclusions?.some((ex) => hasFeature(features, ex))) {
        const matched = rule.exclusions.filter((ex) => hasFeature(features, ex));
        score -= 100;
        rationale.push(`excluded by ${matched.join(', ')}`);
      }

      return {
        syndromeId: rule.syndromeId,
        label: rule.label,
        score,
        rationale,
        requiredFeaturesMet,
      };
    })
    .sort((a, b) => b.score - a.score);
}
