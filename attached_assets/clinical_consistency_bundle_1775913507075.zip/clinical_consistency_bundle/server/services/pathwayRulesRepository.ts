import fs from 'fs';
import path from 'path';
import { PathwayRuleSet } from '../../shared/clinicalConsistency';
import { DEFAULT_RULES } from './canonicalSyndromeRules';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const RULES_FILE = path.join(DATA_DIR, 'clinical-pathway-rules.json');

function ensureDataDir(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export function loadPathwayRules(): PathwayRuleSet[] {
  ensureDataDir();
  if (!fs.existsSync(RULES_FILE)) {
    fs.writeFileSync(RULES_FILE, JSON.stringify(DEFAULT_RULES, null, 2), 'utf8');
    return [...DEFAULT_RULES];
  }

  const raw = fs.readFileSync(RULES_FILE, 'utf8');
  return JSON.parse(raw) as PathwayRuleSet[];
}

export function savePathwayRules(rules: PathwayRuleSet[]): PathwayRuleSet[] {
  ensureDataDir();
  fs.writeFileSync(RULES_FILE, JSON.stringify(rules, null, 2), 'utf8');
  return rules;
}

export function upsertPathwayRule(rule: PathwayRuleSet): PathwayRuleSet[] {
  const rules = loadPathwayRules();
  const idx = rules.findIndex((r) => r.syndromeId === rule.syndromeId);
  if (idx >= 0) rules[idx] = rule;
  else rules.push(rule);
  return savePathwayRules(rules);
}

export function deletePathwayRule(syndromeId: string): PathwayRuleSet[] {
  const rules = loadPathwayRules().filter((r) => r.syndromeId !== syndromeId);
  return savePathwayRules(rules);
}
