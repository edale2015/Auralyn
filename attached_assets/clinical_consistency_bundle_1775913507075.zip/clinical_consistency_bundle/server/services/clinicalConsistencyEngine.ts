import { CanonicalDecision, ClinicalFeatureMap, ConfidenceBand } from '../../shared/clinicalConsistency';
import { buildCanonicalDisposition } from './dispositionConsistencyEngine';
import { scoreSyndromes } from './canonicalSyndromeRules';
import { buildEvidenceRequirements, evidenceLockTriggered } from './evidenceLockService';
import { loadPathwayRules } from './pathwayRulesRepository';
import { buildCanonicalTreatmentPlan } from './therapeuticMinimalismEngine';
import { buildPhenotypeHash } from './varianceAuditService';

function confidenceFromTopScore(score: number): ConfidenceBand {
  if (score >= 10) return 'high';
  if (score >= 6) return 'moderate';
  return 'low';
}

export function runClinicalConsistencyEngine(complaint: string, features: ClinicalFeatureMap): CanonicalDecision {
  const rules = loadPathwayRules();
  const candidates = scoreSyndromes(complaint, features, rules as any);
  const winning = candidates.length > 0 && candidates[0].score > 0 ? candidates[0] : null;
  const evidenceRequirements = buildEvidenceRequirements(winning, features, rules as any);
  const evidenceLocked = evidenceLockTriggered(evidenceRequirements, winning);
  const baseTreatment = buildCanonicalTreatmentPlan(complaint, winning, features);
  const treatment = evidenceLocked
    ? {
        ...baseTreatment,
        class: 'supportive' as const,
        medicationKey: undefined,
        indication: `${baseTreatment.indication} but evidence lock prevents escalation`,
        whyChosen: [...baseTreatment.whyChosen, 'Locked until minimum canonical evidence is present.'],
      }
    : baseTreatment;
  const disposition = buildCanonicalDisposition(complaint, winning, features);
  const phenotypeHash = buildPhenotypeHash(complaint, features);
  const varianceWarnings: string[] = [];
  const notesForClinician: string[] = [];

  if (!winning) notesForClinician.push('No dominant syndrome. Avoid reflex treatment. Sharpen phenotype first.');
  else notesForClinician.push(`Dominant syndrome: ${winning.label}`, 'Canonical principle: narrowest justified treatment and consistent disposition.');

  if (treatment.blockedAlternatives.length > 0) {
    varianceWarnings.push(`Shotgun protection active. Blocked alternatives: ${treatment.blockedAlternatives.join(', ')}`);
  }
  if (evidenceLocked) {
    varianceWarnings.push('Evidence lock active. Minimum evidence for escalated therapy is not yet satisfied.');
  }

  return {
    complaint,
    phenotypeHash,
    confidence: confidenceFromTopScore(winning?.score ?? 0),
    winningSyndrome: winning,
    alternatives: candidates.slice(1, 4),
    treatment,
    disposition,
    evidenceRequirements,
    evidenceLockTriggered: evidenceLocked,
    notesForClinician,
    varianceWarnings,
  };
}
