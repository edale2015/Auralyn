import { CanonicalDecision, ClinicalFeatureMap } from '../../shared/clinicalConsistency';
import { MedicationOrder, validateMedicationBundle } from './medicationConsistencyGuard';
import { runClinicalConsistencyEngine } from './clinicalConsistencyEngine';

export interface DispositionFirstInput {
  complaint: string;
  features: ClinicalFeatureMap;
  medicationOrders?: MedicationOrder[];
}

export interface DispositionFirstResult {
  canonical: CanonicalDecision;
  medicationGuard: ReturnType<typeof validateMedicationBundle>;
  allowedToFinalize: boolean;
  blockingReasons: string[];
}

export function runDispositionFirstWorkflow(input: DispositionFirstInput): DispositionFirstResult {
  const canonical = runClinicalConsistencyEngine(input.complaint, input.features);
  const medicationGuard = validateMedicationBundle(input.medicationOrders ?? []);
  const blockingReasons: string[] = [];

  if (!medicationGuard.allowed) blockingReasons.push(...medicationGuard.reasons);
  if (canonical.evidenceLockTriggered) blockingReasons.push('Evidence lock prevents finalizing escalated therapy.');
  if (canonical.disposition.disposition === 'er_now' && (input.medicationOrders?.length ?? 0) > 2) {
    blockingReasons.push('ER disposition detected. Do not finalize a broad outpatient medication bundle before escalation.');
  }

  return {
    canonical,
    medicationGuard,
    allowedToFinalize: blockingReasons.length === 0,
    blockingReasons,
  };
}
