import { ClinicalFeatureMap, EvidenceRequirement, SyndromeCandidate } from '../../shared/clinicalConsistency';
import { DEFAULT_RULES, SyndromeRule } from './canonicalSyndromeRules';

function featureMet(features: ClinicalFeatureMap, key: string): boolean {
  return Boolean(features[key]);
}

export function buildEvidenceRequirements(
  winning: SyndromeCandidate | null,
  features: ClinicalFeatureMap,
  rules: SyndromeRule[] = DEFAULT_RULES,
): EvidenceRequirement[] {
  if (!winning) return [];
  const rule = rules.find((r) => r.syndromeId === winning.syndromeId);
  const keys = rule?.evidenceRequirements ?? [];
  return keys.map((evidenceKey) => ({
    evidenceKey,
    reason: `Canonical pathway requires ${evidenceKey} before locked treatment escalation.`,
    met: featureMet(features, evidenceKey),
  }));
}

export function evidenceLockTriggered(requirements: EvidenceRequirement[], winning: SyndromeCandidate | null): boolean {
  if (!winning) return false;
  const antibioticLike = ['gas_centor_compatible', 'simple_cystitis', 'bacterial_vaginosis_symptomatic'];
  if (!antibioticLike.includes(winning.syndromeId)) return false;
  return requirements.some((r) => !r.met);
}
