import fs from 'fs';
import path from 'path';
import { CanonicalDecision, LeaderboardEntry, RegistryRecord, VarianceEvent } from '../../shared/clinicalConsistency';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const REGISTRY_FILE = path.join(DATA_DIR, 'phenotype-registry.json');
const VARIANCE_FILE = path.join(DATA_DIR, 'variance-events.json');

function ensureDataDir(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readJsonFile<T>(filePath: string, fallback: T): T {
  ensureDataDir();
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), 'utf8');
    return fallback;
  }
  return JSON.parse(fs.readFileSync(filePath, 'utf8')) as T;
}

function writeJsonFile<T>(filePath: string, data: T): T {
  ensureDataDir();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  return data;
}

export function upsertRegistryRecord(decision: CanonicalDecision, createdBy?: string): RegistryRecord {
  const registry = readJsonFile<RegistryRecord[]>(REGISTRY_FILE, []);
  const now = new Date().toISOString();
  const existing = registry.find((r) => r.phenotypeHash === decision.phenotypeHash && r.complaint === decision.complaint);

  if (existing) {
    existing.lastSeenAt = now;
    existing.occurrenceCount += 1;
    existing.canonicalDecision = decision;
    writeJsonFile(REGISTRY_FILE, registry);
    return existing;
  }

  const created: RegistryRecord = {
    phenotypeHash: decision.phenotypeHash,
    complaint: decision.complaint,
    canonicalDecision: decision,
    firstSeenAt: now,
    lastSeenAt: now,
    occurrenceCount: 1,
    createdBy,
  };
  registry.push(created);
  writeJsonFile(REGISTRY_FILE, registry);
  return created;
}

export function listRegistryRecords(): RegistryRecord[] {
  return readJsonFile<RegistryRecord[]>(REGISTRY_FILE, []).sort((a, b) => b.occurrenceCount - a.occurrenceCount);
}

export function appendVarianceEvent(event: VarianceEvent): VarianceEvent {
  const events = readJsonFile<VarianceEvent[]>(VARIANCE_FILE, []);
  events.push(event);
  writeJsonFile(VARIANCE_FILE, events);
  return event;
}

export function listVarianceEvents(): VarianceEvent[] {
  return readJsonFile<VarianceEvent[]>(VARIANCE_FILE, []).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function buildVarianceLeaderboard(): LeaderboardEntry[] {
  const events = listVarianceEvents();
  const registry = listRegistryRecords();
  const totalCasesByComplaint = registry.reduce<Record<string, number>>((acc, row) => {
    acc[row.complaint] = (acc[row.complaint] ?? 0) + row.occurrenceCount;
    return acc;
  }, {});

  const groups = new Map<string, LeaderboardEntry>();
  for (const event of events) {
    const key = `${event.complaint}::${event.clinicianId ?? 'unknown'}`;
    const found = groups.get(key) ?? {
      complaint: event.complaint,
      clinicianId: event.clinicianId,
      clinicianName: event.clinicianName,
      totalCases: totalCasesByComplaint[event.complaint] ?? events.filter((e) => e.complaint === event.complaint).length,
      varianceCases: 0,
      varianceRate: 0,
      medicationVarianceCases: 0,
      dispositionVarianceCases: 0,
    };

    found.varianceCases += 1;
    if (event.warnings.some((w) => w.startsWith('Medication variance'))) found.medicationVarianceCases += 1;
    if (event.warnings.some((w) => w.startsWith('Disposition variance'))) found.dispositionVarianceCases += 1;
    groups.set(key, found);
  }

  return [...groups.values()]
    .map((row) => ({ ...row, varianceRate: row.totalCases ? Number((row.varianceCases / row.totalCases).toFixed(4)) : 0 }))
    .sort((a, b) => b.varianceRate - a.varianceRate || b.varianceCases - a.varianceCases);
}
