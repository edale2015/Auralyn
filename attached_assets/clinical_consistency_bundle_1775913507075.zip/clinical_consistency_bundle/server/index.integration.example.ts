import express from 'express';
import clinicalConsistencyRoutes from './routes/clinicalConsistencyRoutes';

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use('/api/clinical-consistency', clinicalConsistencyRoutes);

app.listen(3000, () => {
  console.log('Clinical consistency bundle mounted on http://localhost:3000');
});
