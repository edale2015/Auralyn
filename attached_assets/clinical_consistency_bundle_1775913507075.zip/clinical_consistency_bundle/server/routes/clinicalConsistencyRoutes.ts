import { Router } from 'express';
import { runClinicalConsistencyEngine } from '../services/clinicalConsistencyEngine';
import { appendVarianceEvent, buildVarianceLeaderboard, listRegistryRecords, listVarianceEvents, upsertRegistryRecord } from '../services/phenotypeRegistryRepository';
import { deletePathwayRule, loadPathwayRules, upsertPathwayRule } from '../services/pathwayRulesRepository';
import { runDispositionFirstWorkflow } from '../services/dispositionFirstWorkflow';
import { detectVariance } from '../services/varianceAuditService';

const router = Router();

router.post('/run', async (req, res) => {
  try {
    const { complaint, features, clinicianId, clinicianName, clinicianSelectedDisposition, clinicianSelectedMedicationKey } = req.body;
    const canonical = runClinicalConsistencyEngine(complaint, features || {});
    const registry = upsertRegistryRecord(canonical, clinicianId);
    const variance = detectVariance({
      canonical,
      clinicianId,
      clinicianName,
      clinicianSelectedDisposition,
      clinicianSelectedMedicationKey,
    });

    if (variance.event) appendVarianceEvent(variance.event);

    res.json({ ok: true, canonical, registry, variance: variance.warnings });
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error?.message || 'Failed to run clinical consistency engine' });
  }
});

router.post('/finalize', async (req, res) => {
  try {
    const result = runDispositionFirstWorkflow(req.body);
    res.json({ ok: true, ...result });
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error?.message || 'Finalize workflow failed' });
  }
});

router.get('/registry', async (_req, res) => {
  res.json({ ok: true, items: listRegistryRecords() });
});

router.get('/variance-events', async (_req, res) => {
  res.json({ ok: true, items: listVarianceEvents() });
});

router.get('/variance-leaderboard', async (_req, res) => {
  res.json({ ok: true, items: buildVarianceLeaderboard() });
});

router.get('/pathways', async (_req, res) => {
  res.json({ ok: true, items: loadPathwayRules() });
});

router.put('/pathways/:syndromeId', async (req, res) => {
  const payload = { ...req.body, syndromeId: req.params.syndromeId };
  res.json({ ok: true, items: upsertPathwayRule(payload) });
});

router.delete('/pathways/:syndromeId', async (req, res) => {
  res.json({ ok: true, items: deletePathwayRule(req.params.syndromeId) });
});

export default router;
