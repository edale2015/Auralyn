export async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) throw new Error(await res.text());
  return (await res.json()) as T;
}

export const clinicalConsistencyApi = {
  run: (payload: unknown) => fetchJson('/api/clinical-consistency/run', { method: 'POST', body: JSON.stringify(payload) }),
  finalize: (payload: unknown) => fetchJson('/api/clinical-consistency/finalize', { method: 'POST', body: JSON.stringify(payload) }),
  registry: () => fetchJson('/api/clinical-consistency/registry'),
  varianceLeaderboard: () => fetchJson('/api/clinical-consistency/variance-leaderboard'),
  pathways: () => fetchJson('/api/clinical-consistency/pathways'),
  upsertPathway: (syndromeId: string, payload: unknown) =>
    fetchJson(`/api/clinical-consistency/pathways/${encodeURIComponent(syndromeId)}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deletePathway: (syndromeId: string) =>
    fetchJson(`/api/clinical-consistency/pathways/${encodeURIComponent(syndromeId)}`, { method: 'DELETE' }),
};
