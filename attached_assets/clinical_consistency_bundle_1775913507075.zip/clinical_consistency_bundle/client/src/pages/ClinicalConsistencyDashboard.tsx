import React, { useEffect, useState } from 'react';
import ClinicalConsistencyCard from '../components/ClinicalConsistencyCard';
import PathwayEditor from '../components/PathwayEditor';
import VarianceLeaderboardTable from '../components/VarianceLeaderboardTable';
import { clinicalConsistencyApi } from '../lib/clinicalConsistencyApi';

export default function ClinicalConsistencyDashboard() {
  const [result, setResult] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [pathways, setPathways] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    clinicalConsistencyApi.varianceLeaderboard().then((r: any) => setLeaderboard(r.items || [])).catch(() => undefined);
    clinicalConsistencyApi.pathways().then((r: any) => setPathways(r.items || [])).catch(() => undefined);
  }, []);

  async function demoRun() {
    setLoading(true);
    try {
      const r = await clinicalConsistencyApi.run({
        complaint: 'sore_throat',
        features: { sore_throat: true, cough: true, rhinorrhea: true, fever_over_38: false },
        clinicianSelectedDisposition: 'home_with_rx',
        clinicianSelectedMedicationKey: 'empiric_azithromycin',
      });
      setResult(r);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Clinical Consistency Dashboard</h1>
          <p className="text-sm text-gray-600">Variance-killer controls for phenotype registry, evidence locks, pathway editing, and disposition-first finalization.</p>
        </div>
        <button className="rounded-xl bg-black text-white px-4 py-2" onClick={demoRun} disabled={loading}>
          {loading ? 'Running…' : 'Run demo case'}
        </button>
      </div>

      <ClinicalConsistencyCard result={result} />
      <VarianceLeaderboardTable items={leaderboard} />
      <PathwayEditor initialItems={pathways} />
    </div>
  );
}
