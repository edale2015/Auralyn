import React, { useState } from 'react';
import { clinicalConsistencyApi } from '../lib/clinicalConsistencyApi';

export default function PathwayEditor({ initialItems }: { initialItems: any[] }) {
  const [items, setItems] = useState(initialItems);
  const [editing, setEditing] = useState<any>(initialItems[0] || null);
  const [saving, setSaving] = useState(false);

  async function saveRule() {
    if (!editing?.syndromeId) return;
    setSaving(true);
    try {
      const res: any = await clinicalConsistencyApi.upsertPathway(editing.syndromeId, editing);
      setItems(res.items);
    } finally {
      setSaving(false);
    }
  }

  async function removeRule(syndromeId: string) {
    const res: any = await clinicalConsistencyApi.deletePathway(syndromeId);
    setItems(res.items);
    if (editing?.syndromeId === syndromeId) setEditing(null);
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <div className="text-lg font-semibold mb-3">Canonical Pathways</div>
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.syndromeId} className="flex items-center justify-between rounded-xl border p-3">
              <button className="text-left" onClick={() => setEditing(item)}>
                <div className="font-medium">{item.label}</div>
                <div className="text-xs text-gray-500">{item.complaint} • {item.syndromeId}</div>
              </button>
              <button className="text-red-600 text-sm" onClick={() => removeRule(item.syndromeId)}>Delete</button>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border bg-white p-4 shadow-sm">
        <div className="text-lg font-semibold mb-3">Editor</div>
        {editing ? (
          <div className="space-y-3 text-sm">
            <label className="block">
              <div className="mb-1">Label</div>
              <input className="w-full rounded border p-2" value={editing.label || ''} onChange={(e) => setEditing({ ...editing, label: e.target.value })} />
            </label>
            <label className="block">
              <div className="mb-1">Complaint</div>
              <input className="w-full rounded border p-2" value={editing.complaint || ''} onChange={(e) => setEditing({ ...editing, complaint: e.target.value })} />
            </label>
            <label className="block">
              <div className="mb-1">Required features (comma separated)</div>
              <input className="w-full rounded border p-2" value={(editing.required || []).join(', ')} onChange={(e) => setEditing({ ...editing, required: e.target.value.split(',').map((x) => x.trim()).filter(Boolean) })} />
            </label>
            <label className="block">
              <div className="mb-1">Evidence requirements (comma separated)</div>
              <input className="w-full rounded border p-2" value={(editing.evidenceRequirements || []).join(', ')} onChange={(e) => setEditing({ ...editing, evidenceRequirements: e.target.value.split(',').map((x) => x.trim()).filter(Boolean) })} />
            </label>
            <button disabled={saving} className="rounded bg-black text-white px-4 py-2" onClick={saveRule}>{saving ? 'Saving…' : 'Save rule'}</button>
          </div>
        ) : (
          <div className="text-sm text-gray-500">Select a pathway to edit.</div>
        )}
      </div>
    </div>
  );
}
