import React from 'react';

export default function ClinicalConsistencyCard({ result }: { result: any }) {
  if (!result?.canonical) return null;
  const c = result.canonical;

  return (
    <div className="rounded-2xl border p-4 bg-white shadow-sm">
      <div className="text-lg font-semibold">Clinical Consistency Engine</div>
      <div className="mt-3 text-sm grid gap-1">
        <div><strong>Complaint:</strong> {c.complaint}</div>
        <div><strong>Phenotype:</strong> {c.phenotypeHash}</div>
        <div><strong>Confidence:</strong> {c.confidence}</div>
        <div><strong>Syndrome:</strong> {c.winningSyndrome?.label || 'No dominant syndrome'}</div>
        <div><strong>Disposition:</strong> {c.disposition?.disposition}</div>
        <div><strong>Treatment class:</strong> {c.treatment?.class}</div>
        <div><strong>Medication key:</strong> {c.treatment?.medicationKey || 'None'}</div>
        <div><strong>Evidence lock:</strong> {c.evidenceLockTriggered ? 'ON' : 'OFF'}</div>
      </div>

      {c.evidenceRequirements?.length > 0 && (
        <div className="mt-4">
          <div className="font-medium">Evidence requirements</div>
          <ul className="list-disc pl-5 text-sm">
            {c.evidenceRequirements.map((r: any) => (
              <li key={r.evidenceKey}>{r.evidenceKey}: {r.met ? 'met' : 'missing'}</li>
            ))}
          </ul>
        </div>
      )}

      {result?.variance?.length > 0 && (
        <div className="mt-4 rounded-xl border border-amber-300 bg-amber-50 p-3">
          <div className="font-medium text-amber-900">Variance warnings</div>
          <ul className="list-disc pl-5 text-sm text-amber-900">
            {result.variance.map((v: string, i: number) => <li key={i}>{v}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}
