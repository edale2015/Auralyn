import React from 'react';

export default function VarianceLeaderboardTable({ items }: { items: any[] }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm overflow-auto">
      <div className="text-lg font-semibold mb-3">Variance Leaderboard</div>
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="text-left border-b">
            <th className="py-2">Complaint</th>
            <th>Clinician</th>
            <th>Total</th>
            <th>Variance</th>
            <th>Rate</th>
            <th>Medication</th>
            <th>Disposition</th>
          </tr>
        </thead>
        <tbody>
          {items.map((row, idx) => (
            <tr key={`${row.complaint}-${row.clinicianId ?? idx}`} className="border-b last:border-0">
              <td className="py-2">{row.complaint}</td>
              <td>{row.clinicianName || row.clinicianId || 'Unknown'}</td>
              <td>{row.totalCases}</td>
              <td>{row.varianceCases}</td>
              <td>{(row.varianceRate * 100).toFixed(1)}%</td>
              <td>{row.medicationVarianceCases}</td>
              <td>{row.dispositionVarianceCases}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
