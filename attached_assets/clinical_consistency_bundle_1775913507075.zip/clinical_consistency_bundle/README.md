# Clinical Consistency Bundle

This bundle turns a medical workflow into a **Clinical Consistency Engine**.

## What it solves
- Same phenotype -> same canonical diagnosis/disposition/treatment ceiling
- Stops shotgun prescribing
- Makes variance visible
- Requires minimum evidence before escalating therapy
- Forces disposition-first workflow

## Included upgrades
1. **Phenotype registry table / repository**
2. **Canonical pathway editor**
3. **Variance leaderboard**
4. **Evidence lock mode**
5. **Disposition-first enforcement**

## Files
- `shared/clinicalConsistency.ts`: shared types
- `server/services/*`: core engine and upgrade services
- `server/routes/clinicalConsistencyRoutes.ts`: API routes
- `server/db/clinicalConsistency.sql`: Postgres schema starter
- `client/src/components/*`: dashboard components
- `client/src/pages/ClinicalConsistencyDashboard.tsx`: dashboard page

## Minimal integration
Register:

```ts
import clinicalConsistencyRoutes from './server/routes/clinicalConsistencyRoutes';
app.use('/api/clinical-consistency', clinicalConsistencyRoutes);
```

Render the dashboard page inside your React router or dashboard shell.

## Dev run
```bash
npm install
npm run dev
```

## Notes
- The repositories in this bundle default to JSON file storage in `./data` so you can test immediately.
- For production, swap repository functions to Postgres/Drizzle using `server/db/clinicalConsistency.sql` as the shape reference.
- This bundle is intentionally opinionated toward narrow treatment, evidence-gated escalation, and consistent disposition.
