# Auralyn World B Pipeline DDX Patch

Apply from the Auralyn repo root:

```bash
git apply patch.diff
npm run check
```

This patch refreshes the clinical pipeline to:

1. Complaint Identification
2. Differential Diagnosis / Rule-Out Targets
3A. Modifier Collection
3B. Question Engine
4. Workup Selection
5. Medication Selection / Safety
6. Safety Screen (Red Flags)
7. Cluster Scoring
8. Diagnosis Ranking / Differential Refinement
9. Disposition + Plan
13. Audit Trail

It maps each stage to the normalized World B Google Sheets source tables and adds `docs/GOOGLE_SHEETS_WORLD_B_PIPELINE_MAP.md`.
