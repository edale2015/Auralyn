export async function runFullClinicalFlow(input: unknown) {
  return {
    diagnosis: "viral_pharyngitis",
    confidence: 0.82,
    reasoning: "Stub clinical engine. Replace this function with your real Med-Scribe logic.",
    input
  };
}
