import express from "express";
import unifiedRoutes from "./routes/unifiedRoutes.js";
import controlTowerRoutes from "./routes/controlTowerRoutes.js";
import executiveRoutes from "./routes/executiveRoutes.js";

const app = express();
app.use(express.json());

app.use("/api", unifiedRoutes);
app.use("/api", controlTowerRoutes);
app.use("/api", executiveRoutes);

app.get("/health", (_req, res) => {
  res.json({ ok: true, uptime: process.uptime(), timestamp: Date.now() });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`MedScribe server running on port ${port}`);
});
