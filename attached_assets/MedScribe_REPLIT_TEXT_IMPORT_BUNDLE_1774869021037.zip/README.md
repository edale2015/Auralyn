# MedScribe Replit Import Bundle

This bundle is text-first so Replit can read and implement it.

## Quick start
1. Create a new Replit Node.js project
2. Upload all files from this folder, or paste the contents using `replit_import_bundle.sh`
3. Run:
   ```bash
   npm install
   npm run dev
   ```

## Endpoints
- `POST /api/run`
- `GET /api/control-tower`
- `GET /api/executive`
- `GET /health`

## Critical next integration
Replace the stub implementation in:
- `server/system/runFullClinicalFlow.ts`

with your real Med-Scribe engine.
