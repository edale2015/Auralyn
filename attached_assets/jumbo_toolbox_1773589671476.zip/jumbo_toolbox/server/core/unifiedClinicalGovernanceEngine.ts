import { GovernanceResult, SeverityScoreResult, CompletenessResult, VarianceResult, DriftResult } from '../../shared/clinicalEngineTypes';

export function runUnifiedClinicalGovernance(input: {
  severity: SeverityScoreResult;
  completeness: CompletenessResult;
  variance: VarianceResult;
  drift: DriftResult;
  guidelineIssues?: string[];
}): GovernanceResult {
  const rationale: string[] = [];
  if (input.severity.severityLevel === 'critical') rationale.push('Critical severity score.');
  if (input.completeness.level === 'missing_critical') rationale.push('Critical complaint questions are unanswered.');
  if (input.variance.hasMajorVariance) rationale.push(...input.variance.findings);
  if (input.drift.hasMajorDrift) rationale.push(...input.drift.findings);
  if ((input.guidelineIssues?.length ?? 0) > 0) rationale.push(...(input.guidelineIssues ?? []));

  if (rationale.some((r) => /Critical|Unsafe|Major drift/.test(r))) return { decision: 'BLOCK', rationale };
  if (rationale.length > 0) return { decision: 'NEEDS_PHYSICIAN_REVIEW', rationale };
  return { decision: 'APPROVE', rationale: ['No governance blockers detected.'] };
}
