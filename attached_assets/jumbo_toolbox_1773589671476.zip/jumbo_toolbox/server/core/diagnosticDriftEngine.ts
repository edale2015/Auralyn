import { DifferentialSnapshot, DriftResult, RankedScore } from '../../shared/clinicalEngineTypes';

export function detectDiagnosticDrift(priorSnapshots: DifferentialSnapshot[] = [], current: RankedScore[]): DriftResult {
  const prev = priorSnapshots[priorSnapshots.length - 1];
  const now = current[0];
  const findings: string[] = [];
  if (!prev || !now) return { hasMajorDrift: false, hasMinorDrift: false, findings };
  const topChanged = prev.topDifferential && prev.topDifferential !== now.key;
  const scoreShift = Math.abs((prev.topScore ?? 0) - now.score);
  if (topChanged && scoreShift >= 0.25) findings.push(`Major drift: ${prev.topDifferential} → ${now.key} with score shift ${scoreShift.toFixed(2)}`);
  else if (topChanged || scoreShift >= 0.15) findings.push(`Minor drift detected in leading differential.`);
  return {
    hasMajorDrift: findings.some((f) => f.startsWith('Major drift')),
    hasMinorDrift: findings.length > 0,
    findings,
  };
}
