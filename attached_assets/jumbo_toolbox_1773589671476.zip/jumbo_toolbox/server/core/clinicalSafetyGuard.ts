import { BrainCaseInput, CalibrationResult } from '../../shared/clinicalEngineTypes';

interface SafetyRule {
  id: string;
  when: (input: BrainCaseInput) => boolean;
  disposition: CalibrationResult['disposition'];
  rationale: string;
}

const RULES: SafetyRule[] = [
  {
    id: 'RULE_ACS',
    when: (i) => has(i, 'chest_pain') && (has(i, 'diaphoresis') || has(i, 'shortness_of_breath')),
    disposition: 'ER_NOW',
    rationale: 'Possible acute coronary syndrome.',
  },
  {
    id: 'RULE_STROKE',
    when: (i) => has(i, 'facial_droop') || has(i, 'one_sided_weakness') || has(i, 'aphasia'),
    disposition: 'CALL_911',
    rationale: 'Possible stroke symptoms.',
  },
  {
    id: 'RULE_PE',
    when: (i) => has(i, 'shortness_of_breath') && has(i, 'pleuritic_chest_pain') && has(i, 'tachycardia'),
    disposition: 'ER_NOW',
    rationale: 'Possible pulmonary embolism.',
  },
  {
    id: 'RULE_MENINGITIS',
    when: (i) => has(i, 'fever') && has(i, 'neck_stiffness') && has(i, 'headache'),
    disposition: 'ER_NOW',
    rationale: 'Possible meningitis.',
  },
];

function has(input: BrainCaseInput, token: string): boolean {
  return input.symptoms.includes(token);
}

export function runClinicalSafetyGuard(input: BrainCaseInput): { triggeredRuleId?: string; result?: CalibrationResult } {
  const hit = RULES.find((r) => r.when(input));
  if (!hit) return {};
  return {
    triggeredRuleId: hit.id,
    result: { disposition: hit.disposition, rationale: [hit.rationale, `Triggered ${hit.id}`] },
  };
}
