import { RankedScore } from '../../shared/clinicalEngineTypes';

const MAP: Record<string, string[]> = {
  uti: ['nitrofurantoin', 'cephalexin', 'hydration'],
  pyelonephritis: ['ceftriaxone', 'ciprofloxacin', 'fluids'],
  flu: ['oseltamivir', 'fluids', 'rest'],
  pharyngitis: ['penicillin', 'amoxicillin', 'analgesics'],
};

export function getTreatmentsForDifferentials(dx: RankedScore[]): RankedScore[] {
  const items = [...new Set(dx.slice(0, 3).flatMap((d) => MAP[d.key] ?? []))];
  return items.map((key, idx) => ({ key, score: 1 - idx * 0.05 }));
}
