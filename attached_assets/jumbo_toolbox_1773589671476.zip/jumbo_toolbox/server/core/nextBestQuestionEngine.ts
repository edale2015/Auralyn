import { BrainCaseInput, NextQuestionResult } from '../../shared/clinicalEngineTypes';

const QUESTION_BANK: Record<string, string[]> = {
  chest_pain: ['Is the pain exertional?', 'Any shortness of breath?', 'Any radiation to arm or jaw?'],
  sore_throat: ['Any fever?', 'Any muffled voice?', 'Any trouble swallowing?'],
  dysuria: ['Any flank pain?', 'Any fever?', 'Any vaginal discharge or testicular pain?'],
};

export function rankNextBestQuestion(input: BrainCaseInput): NextQuestionResult {
  const questions = QUESTION_BANK[input.complaint] ?? [];
  const unanswered = new Set(input.unansweredQuestions ?? questions);
  const ranked = questions.filter((q) => unanswered.has(q)).map((key, idx) => ({ key, score: 1 - idx * 0.1 }));
  return { nextBestQuestion: ranked[0]?.key, questionRankings: ranked };
}
