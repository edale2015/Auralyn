import { AggregatedEvidenceResult, RankedScore } from '../../shared/clinicalEngineTypes';

function rescale(items: RankedScore[]): Map<string, number> {
  const max = Math.max(0.0001, ...items.map((i) => i.score));
  return new Map(items.map((i) => [i.key, i.score / max]));
}

export function aggregateEvidence(params: {
  bayesian: RankedScore[];
  similarity: RankedScore[];
  graph: RankedScore[];
  weights?: { bayesian: number; similarity: number; graph: number };
}): AggregatedEvidenceResult {
  const weights = params.weights ?? { bayesian: 0.5, similarity: 0.3, graph: 0.2 };
  const b = rescale(params.bayesian);
  const s = rescale(params.similarity);
  const g = rescale(params.graph);
  const keys = new Set([...b.keys(), ...s.keys(), ...g.keys()]);
  const components: AggregatedEvidenceResult['components'] = {};
  for (const key of keys) {
    const bayesian = b.get(key) ?? 0;
    const similarity = s.get(key) ?? 0;
    const graph = g.get(key) ?? 0;
    components[key] = { bayesian, similarity, graph, total: bayesian * weights.bayesian + similarity * weights.similarity + graph * weights.graph };
  }
  const rankedDiagnoses = Object.entries(components).map(([key, c]) => ({ key, score: c.total })).sort((a, b) => b.score - a.score);
  return { rankedDiagnoses, components };
}
