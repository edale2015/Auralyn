import { BrainCaseInput, BrainOutput } from '../../shared/clinicalEngineTypes';
import { normalizeSymptoms } from './symptomNormalizationEngine';
import { runContradictionEngine } from './contradictionEngine';
import { runClinicalSafetyGuard } from './clinicalSafetyGuard';
import { runCaseSimilarityEngine } from './caseSimilarityEngine';
import { runBayesianDifferentialEngine } from './differentialProbabilityEngine';
import { runKnowledgeGraphEngine } from './knowledgeGraphEngine';
import { aggregateEvidence } from './evidenceAggregatorEngine';
import { computeUncertainty } from './uncertaintyEngine';
import { rankNextBestQuestion } from './nextBestQuestionEngine';
import { getTreatmentsForDifferentials } from './treatmentEngine';
import { getRecommendedTests } from './testRecommendationEngine';
import { getReturnPrecautions } from './returnPrecautionEngine';
import { appendCaseToMemory, retrieveSimilarMemory } from './clinicalMemoryEngine';
import { runClinicalIntelligenceCoordinationLayer } from './clinicalIntelligenceCoordinationLayer';

export function runClinicalBrainEngine(input: BrainCaseInput): BrainOutput {
  const normalizedSymptoms = normalizeSymptoms(input.symptoms);
  const normalizedInput: BrainCaseInput = { ...input, symptoms: normalizedSymptoms };

  const contradiction = runContradictionEngine(normalizedInput);
  if (contradiction.hasErrors) {
    return {
      normalizedSymptoms,
      contradiction,
      finalDisposition: { disposition: 'NEEDS_WORKUP', rationale: ['Contradictory clinical inputs require clarification.'] },
    };
  }

  const safety = runClinicalSafetyGuard(normalizedInput);
  if (safety.result) {
    return {
      normalizedSymptoms,
      contradiction,
      safetyDecision: safety.result,
      finalDisposition: safety.result,
    };
  }

  const memory = retrieveSimilarMemory(normalizedInput);
  const similarity = runCaseSimilarityEngine(normalizedInput);
  const graph = runKnowledgeGraphEngine(normalizedInput);
  const bayesian = runBayesianDifferentialEngine(normalizedInput);
  const aggregatedEvidence = aggregateEvidence({
    bayesian: bayesian.rankedDiagnoses,
    similarity: similarity.rankedDiagnoses,
    graph: graph.rankedDiagnoses,
  });
  const uncertainty = computeUncertainty(aggregatedEvidence.rankedDiagnoses);
  const nextQuestion = rankNextBestQuestion(normalizedInput);
  const treatments = getTreatmentsForDifferentials(aggregatedEvidence.rankedDiagnoses);
  const tests = getRecommendedTests(aggregatedEvidence.rankedDiagnoses);
  const precautions = getReturnPrecautions(aggregatedEvidence.rankedDiagnoses[0]?.key);

  const coordination = runClinicalIntelligenceCoordinationLayer({
    input: normalizedInput,
    aggregatedDifferentials: aggregatedEvidence.rankedDiagnoses,
    tests,
    draftDisposition: uncertainty.recommendation === 'adequate_confidence' ? 'HOME_CARE' : 'NEEDS_WORKUP',
  });

  appendCaseToMemory(normalizedInput, aggregatedEvidence.rankedDiagnoses[0]?.key, coordination.calibratedDisposition.disposition);

  return {
    normalizedSymptoms,
    contradiction,
    memory,
    similarity,
    graph,
    bayesian,
    aggregatedEvidence,
    uncertainty,
    nextQuestion,
    treatments,
    tests,
    precautions,
    severity: coordination.severity,
    completeness: coordination.completeness,
    variance: coordination.variance,
    drift: coordination.drift,
    governance: coordination.governance,
    finalDisposition: coordination.calibratedDisposition,
  };
}
