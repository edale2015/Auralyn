import { UncertaintyResult, RankedScore } from '../../shared/clinicalEngineTypes';

export function computeUncertainty(ranked: RankedScore[]): UncertaintyResult {
  const top = ranked.slice(0, 5);
  const total = top.reduce((a, b) => a + b.score, 0) || 1;
  const entropy = -top.reduce((sum, r) => {
    const p = r.score / total;
    return sum + (p > 0 ? p * Math.log2(p) : 0);
  }, 0);
  if (entropy > 1.0) return { entropy, recommendation: 'needs_workup' };
  if (entropy > 0.65) return { entropy, recommendation: 'ask_more_questions' };
  return { entropy, recommendation: 'adequate_confidence' };
}
