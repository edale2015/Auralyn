import { RankedScore } from '../../shared/clinicalEngineTypes';

const URGENT: Record<string, string[]> = {
  acs: ['ecg', 'troponin'],
  pe: ['ctpa', 'ddimer'],
  pyelonephritis: ['urinalysis', 'urine_culture', 'cbc'],
};

export function getRecommendedTests(dx: RankedScore[]): RankedScore[] {
  const tests = dx.slice(0, 3).flatMap((d) => URGENT[d.key] ?? []);
  return [...new Set(tests)].map((key, idx) => ({ key, score: 1 - idx * 0.05 }));
}
