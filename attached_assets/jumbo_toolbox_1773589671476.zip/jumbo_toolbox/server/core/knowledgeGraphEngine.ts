import { BrainCaseInput, GraphResult, RedFlagHit } from '../../shared/clinicalEngineTypes';

const SYMPTOM_TO_DX: Record<string, Array<{ dx: string; score: number }>> = {
  dysuria: [{ dx: 'uti', score: 0.6 }, { dx: 'pyelonephritis', score: 0.2 }],
  urinary_frequency: [{ dx: 'uti', score: 0.3 }],
  urinary_urgency: [{ dx: 'uti', score: 0.3 }],
  fever: [{ dx: 'flu', score: 0.3 }, { dx: 'pyelonephritis', score: 0.35 }],
  chest_pain: [{ dx: 'acs', score: 0.5 }, { dx: 'pe', score: 0.25 }],
  diaphoresis: [{ dx: 'acs', score: 0.35 }],
  sore_throat: [{ dx: 'pharyngitis', score: 0.55 }, { dx: 'flu', score: 0.2 }],
};

const DX_TO_TESTS: Record<string, string[]> = {
  acs: ['ecg', 'troponin'],
  pe: ['ddimer', 'ctpa'],
  uti: ['urinalysis', 'urine_culture'],
  pyelonephritis: ['urinalysis', 'urine_culture', 'cmp', 'cbc'],
  pharyngitis: ['rapid_strep'],
};

const DX_TO_TX: Record<string, string[]> = {
  uti: ['nitrofurantoin', 'cephalexin'],
  pyelonephritis: ['ceftriaxone', 'ciprofloxacin'],
  pharyngitis: ['penicillin', 'amoxicillin'],
  flu: ['oseltamivir', 'fluids', 'rest'],
};

const RED_FLAG_MAP: Record<string, RedFlagHit[]> = {
  sore_throat: [
    { id: 'RF_ST_AIRWAY', label: 'Airway concern', severity: 'critical', rationale: 'Possible airway compromise' },
    { id: 'RF_ST_PERITONSILLAR', label: 'Peritonsillar abscess risk', severity: 'high', rationale: 'Severe unilateral sore throat or muffled voice' },
  ],
};

export function runKnowledgeGraphEngine(input: BrainCaseInput): GraphResult {
  const dxScores = new Map<string, number>();
  for (const symptom of input.symptoms) {
    for (const edge of SYMPTOM_TO_DX[symptom] ?? []) {
      dxScores.set(edge.dx, (dxScores.get(edge.dx) ?? 0) + edge.score);
    }
  }
  const rankedDiagnoses = [...dxScores.entries()].map(([key, score]) => ({ key, score })).sort((a, b) => b.score - a.score);
  const tests = [...new Set(rankedDiagnoses.flatMap((r) => DX_TO_TESTS[r.key] ?? []))].map((key, i) => ({ key, score: 1 - i * 0.05 }));
  const treatments = [...new Set(rankedDiagnoses.flatMap((r) => DX_TO_TX[r.key] ?? []))].map((key, i) => ({ key, score: 1 - i * 0.05 }));
  const redFlags = input.symptoms.flatMap((s) => RED_FLAG_MAP[s] ?? []);
  return { rankedDiagnoses, tests, treatments, redFlags };
}
