import fs from 'fs';
import path from 'path';
import { BrainCaseInput } from '../../shared/clinicalEngineTypes';

const MEMORY_PATH = path.join(process.cwd(), 'clinical_memory.ndjson');

interface MemoryRow {
  caseId: string;
  complaint: string;
  symptoms: string[];
  diagnosis?: string;
  disposition?: string;
  createdAt: string;
}

function readRows(): MemoryRow[] {
  if (!fs.existsSync(MEMORY_PATH)) return [];
  return fs.readFileSync(MEMORY_PATH, 'utf8')
    .split('\n')
    .filter(Boolean)
    .map((line) => JSON.parse(line) as MemoryRow);
}

export function appendCaseToMemory(input: BrainCaseInput, diagnosis?: string, disposition?: string): void {
  const row: MemoryRow = {
    caseId: input.caseId,
    complaint: input.complaint,
    symptoms: input.symptoms,
    diagnosis,
    disposition,
    createdAt: new Date().toISOString(),
  };
  fs.appendFileSync(MEMORY_PATH, JSON.stringify(row) + '\n');
}

export function retrieveSimilarMemory(input: BrainCaseInput) {
  const rows = readRows();
  const set = new Set(input.symptoms);
  return rows
    .map((r) => {
      const overlap = r.symptoms.filter((s) => set.has(s)).length;
      const union = new Set([...r.symptoms, ...input.symptoms]).size || 1;
      return { caseId: r.caseId, diagnosis: r.diagnosis, disposition: r.disposition, score: overlap / union };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
}
