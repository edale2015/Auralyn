import { BrainCaseInput } from '../../shared/clinicalEngineTypes';

const HARD_RULES: Array<(input: BrainCaseInput) => string | null> = [
  (i) => i.sex === 'male' && i.pregnancy ? 'Male patient cannot be pregnant.' : null,
  (i) => has(i, 'no_fever') && has(i, 'high_fever') ? 'Patient cannot simultaneously have no fever and high fever.' : null,
  (i) => has(i, 'no_cough') && has(i, 'productive_cough') ? 'Patient cannot simultaneously have no cough and productive cough.' : null,
  (i) => has(i, 'no_shortness_of_breath') && has(i, 'shortness_of_breath') ? 'Patient cannot simultaneously deny and endorse shortness of breath.' : null,
];

const SOFT_RULES: Array<(input: BrainCaseInput) => string | null> = [
  (i) => has(i, 'uti') && has(i, 'testicular_pain') ? 'Symptoms cross GU buckets. Consider more than one complaint pathway.' : null,
  (i) => has(i, 'headache') && has(i, 'abdominal_pain') ? 'Broad symptom spread may indicate missing context or multi-complaint case.' : null,
];

function has(input: BrainCaseInput, token: string): boolean {
  return input.symptoms.includes(token);
}

export function runContradictionEngine(input: BrainCaseInput) {
  const errors = HARD_RULES.map((r) => r(input)).filter(Boolean) as string[];
  const warnings = SOFT_RULES.map((r) => r(input)).filter(Boolean) as string[];
  return {
    hasErrors: errors.length > 0,
    hasWarnings: warnings.length > 0,
    findings: [...errors, ...warnings],
  };
}
