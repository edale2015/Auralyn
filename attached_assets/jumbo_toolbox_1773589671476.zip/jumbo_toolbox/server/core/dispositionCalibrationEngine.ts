import { CalibrationResult, GovernanceResult, SeverityLevel } from '../../shared/clinicalEngineTypes';

export function calibrateDisposition(params: {
  topDiagnosis?: string;
  topScore?: number;
  uncertaintyRecommendation?: string;
  governance?: GovernanceResult;
  contradictionErrors?: boolean;
  severityLevel?: SeverityLevel;
  completenessPassed?: boolean;
  redFlags?: string[];
}): CalibrationResult {
  const rationale: string[] = [];
  if (params.contradictionErrors) return { disposition: 'NEEDS_WORKUP', rationale: ['Contradiction errors present.'] };
  if ((params.redFlags?.length ?? 0) > 0) return { disposition: 'ER_NOW', rationale: ['Red flags present.'] };
  if (params.governance?.decision === 'BLOCK') return { disposition: 'ER_NOW', rationale: [...params.governance.rationale, 'Governance block overrides.'] };
  if (params.governance?.decision === 'NEEDS_PHYSICIAN_REVIEW') return { disposition: 'URGENT_CARE', rationale: [...params.governance.rationale] };
  if (!params.completenessPassed) rationale.push('Complaint evaluation incomplete.');
  if (params.severityLevel === 'critical') return { disposition: 'ER_NOW', rationale: [...rationale, 'Critical severity score.'] };
  if (params.severityLevel === 'high') return { disposition: 'URGENT_CARE', rationale: [...rationale, 'High severity score.'] };
  if (params.uncertaintyRecommendation === 'needs_workup') return { disposition: 'NEEDS_WORKUP', rationale: [...rationale, 'High uncertainty.'] };
  if ((params.topScore ?? 0) > 0.75 && ['uti', 'pharyngitis', 'flu'].includes(params.topDiagnosis ?? '')) {
    return { disposition: 'HOME_CARE', rationale: [...rationale, 'High-confidence benign pattern.'] };
  }
  return { disposition: 'NEEDS_WORKUP', rationale: [...rationale, 'Default cautious calibration.'] };
}
