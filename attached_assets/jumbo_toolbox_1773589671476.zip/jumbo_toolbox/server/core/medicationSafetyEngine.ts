import { BrainCaseInput, MedicationSafetyResult } from '../../shared/clinicalEngineTypes';

export function screenMedicationSafety(input: BrainCaseInput, treatments: string[]): MedicationSafetyResult {
  const warnings: string[] = [];
  const saferAlternatives: string[] = [];
  let blocked = false;

  if (input.pregnancy && treatments.includes('ciprofloxacin')) {
    blocked = true;
    warnings.push('Avoid ciprofloxacin in pregnancy unless specifically indicated.');
    saferAlternatives.push('cephalexin');
  }
  if ((input.ageYears ?? 99) < 8 && treatments.includes('doxycycline')) {
    blocked = true;
    warnings.push('Avoid doxycycline in young children in routine settings.');
    saferAlternatives.push('amoxicillin');
  }
  if ((input.comorbidities ?? []).includes('ckd') && treatments.includes('nitrofurantoin')) {
    warnings.push('Nitrofurantoin may be suboptimal in reduced renal function.');
    saferAlternatives.push('cephalexin');
  }

  return { blocked, warnings, saferAlternatives: [...new Set(saferAlternatives)] };
}
