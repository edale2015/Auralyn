export function getReturnPrecautions(topDiagnosis?: string): string[] {
  const common = ['Return for worsening symptoms.', 'Seek urgent help for trouble breathing, chest pain, confusion, or dehydration.'];
  const map: Record<string, string[]> = {
    uti: ['Return for fever, back pain, vomiting, or inability to keep fluids down.'],
    pharyngitis: ['Return for muffled voice, neck swelling, or trouble swallowing saliva.'],
    flu: ['Return for shortness of breath, chest pain, or persistent high fever.'],
  };
  return [...common, ...(topDiagnosis ? map[topDiagnosis] ?? [] : [])];
}
