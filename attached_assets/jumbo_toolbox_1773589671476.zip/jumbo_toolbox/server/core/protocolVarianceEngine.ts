import { RankedScore, VarianceResult } from '../../shared/clinicalEngineTypes';

const REQUIRED_TESTS: Record<string, string[]> = {
  acs: ['ecg', 'troponin'],
  pe: ['ddimer', 'ctpa'],
  uti: ['urinalysis'],
};

export function detectProtocolVariance(topDx: RankedScore[], tests: RankedScore[], disposition: string): VarianceResult {
  const findings: string[] = [];
  const top = topDx[0]?.key;
  if (top) {
    const required = REQUIRED_TESTS[top] ?? [];
    const have = new Set(tests.map((t) => t.key));
    for (const t of required) {
      if (!have.has(t)) findings.push(`Missing expected test for ${top}: ${t}`);
    }
    if ((top === 'acs' || top === 'pe') && ['HOME_CARE'].includes(disposition)) {
      findings.push(`Unsafe low-acuity disposition for high-risk diagnosis: ${top}`);
    }
  }
  return {
    hasMajorVariance: findings.some((f) => /Unsafe|Missing expected test/.test(f)),
    hasMinorVariance: findings.length > 0,
    findings,
  };
}
