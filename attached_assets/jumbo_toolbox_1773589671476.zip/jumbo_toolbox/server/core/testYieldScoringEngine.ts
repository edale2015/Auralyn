import { RankedScore } from '../../shared/clinicalEngineTypes';

const YIELD_MAP: Record<string, Record<string, 'high' | 'moderate' | 'low'>> = {
  acs: { ecg: 'high', troponin: 'high', cxr: 'low' },
  pe: { ctpa: 'high', ddimer: 'high', cxr: 'low' },
  uti: { urinalysis: 'high', urine_culture: 'moderate', ct_abdomen: 'low' },
};

const SCORE: Record<'high' | 'moderate' | 'low', number> = { high: 1, moderate: 0.6, low: 0.2 };

export function scoreTestYield(differentials: RankedScore[], candidateTests: string[]) {
  return candidateTests.map((test) => {
    let score = 0;
    const reasons: string[] = [];
    for (const dx of differentials.slice(0, 5)) {
      const y = YIELD_MAP[dx.key]?.[test];
      if (y) {
        score += SCORE[y] * dx.score;
        reasons.push(`${test} is ${y}-yield for ${dx.key}`);
      }
    }
    return { key: test, score, reasons };
  }).sort((a, b) => b.score - a.score);
}
