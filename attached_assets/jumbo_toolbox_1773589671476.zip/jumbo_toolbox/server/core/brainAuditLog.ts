import fs from 'fs';
import path from 'path';

const FILE = path.join(process.cwd(), 'brain_decisions.ndjson');

export function appendBrainDecision(payload: unknown) {
  fs.appendFileSync(FILE, JSON.stringify({ at: new Date().toISOString(), payload }) + '\n');
}
