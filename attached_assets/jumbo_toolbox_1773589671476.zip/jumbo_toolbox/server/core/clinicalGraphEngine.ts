export interface GraphNode { id: string; kind: string; }
export interface GraphEdge { from: string; to: string; relation: string; weight?: number; }

export class ClinicalGraphEngine {
  private nodes = new Map<string, GraphNode>();
  private edges: GraphEdge[] = [];

  addNode(node: GraphNode) { this.nodes.set(node.id, node); }
  addEdge(edge: GraphEdge) { this.edges.push(edge); }
  getNeighbors(id: string) { return this.edges.filter((e) => e.from === id || e.to === id); }
  scoreDiagnoses(symptoms: string[]) {
    const scores = new Map<string, number>();
    for (const symptom of symptoms) {
      for (const e of this.edges.filter((x) => x.from === symptom && x.relation === 'suggests')) {
        scores.set(e.to, (scores.get(e.to) ?? 0) + (e.weight ?? 1));
      }
    }
    return [...scores.entries()].map(([key, score]) => ({ key, score })).sort((a, b) => b.score - a.score);
  }
  getRedFlags(diagnosis: string) { return this.edges.filter((e) => e.from === diagnosis && e.relation === 'red_flag').map((e) => e.to); }
  getTests(diagnosis: string) { return this.edges.filter((e) => e.from === diagnosis && e.relation === 'test').map((e) => e.to); }
  getTreatments(diagnosis: string) { return this.edges.filter((e) => e.from === diagnosis && e.relation === 'treatment').map((e) => e.to); }
  toJSON() { return { nodes: [...this.nodes.values()], edges: this.edges }; }
  static fromJSON(json: { nodes: GraphNode[]; edges: GraphEdge[] }) {
    const g = new ClinicalGraphEngine();
    json.nodes.forEach((n) => g.addNode(n));
    json.edges.forEach((e) => g.addEdge(e));
    return g;
  }
}
