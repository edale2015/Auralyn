import { BrainCaseInput, BayesianResult } from '../../shared/clinicalEngineTypes';

const PRIORS: Record<string, number> = {
  pharyngitis: 0.18,
  flu: 0.15,
  uti: 0.12,
  pyelonephritis: 0.05,
  acs: 0.03,
  pe: 0.02,
  migraine: 0.08,
};

const LR: Record<string, Record<string, number>> = {
  sore_throat: { pharyngitis: 3.5, flu: 2.0 },
  fever: { flu: 2.5, pharyngitis: 1.8, pyelonephritis: 2.2 },
  dysuria: { uti: 4.2, pyelonephritis: 2.0 },
  urinary_frequency: { uti: 3.0 },
  urinary_urgency: { uti: 3.0 },
  flank_pain: { pyelonephritis: 4.0 },
  chest_pain: { acs: 3.6, pe: 2.1 },
  diaphoresis: { acs: 3.2 },
  pleuritic_chest_pain: { pe: 3.9 },
  thunderclap_headache: { migraine: 0.3 },
};

function normalize(scores: Record<string, number>) {
  const total = Object.values(scores).reduce((a, b) => a + b, 0) || 1;
  return Object.fromEntries(Object.entries(scores).map(([k, v]) => [k, v / total]));
}

export function runBayesianDifferentialEngine(input: BrainCaseInput): BayesianResult {
  const posteriors: Record<string, number> = { ...PRIORS };
  for (const symptom of input.symptoms) {
    const map = LR[symptom] ?? {};
    for (const dx of Object.keys(posteriors)) {
      posteriors[dx] *= map[dx] ?? 0.9;
    }
  }
  const norm = normalize(posteriors);
  const rankedDiagnoses = Object.entries(norm)
    .map(([key, score]) => ({ key, score }))
    .sort((a, b) => b.score - a.score);
  const entropy = -rankedDiagnoses.reduce((sum, r) => sum + (r.score > 0 ? r.score * Math.log2(r.score) : 0), 0);
  return { rankedDiagnoses, entropy };
}
