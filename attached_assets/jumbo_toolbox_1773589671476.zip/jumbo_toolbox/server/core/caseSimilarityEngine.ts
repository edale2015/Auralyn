import { BrainCaseInput, SimilarityResult } from '../../shared/clinicalEngineTypes';
import { retrieveSimilarMemory } from './clinicalMemoryEngine';

export function runCaseSimilarityEngine(input: BrainCaseInput): SimilarityResult {
  const matchedCases = retrieveSimilarMemory(input);
  const votes = new Map<string, number>();
  for (const m of matchedCases) {
    if (!m.diagnosis) continue;
    votes.set(m.diagnosis, (votes.get(m.diagnosis) ?? 0) + m.score);
  }
  const rankedDiagnoses = [...votes.entries()]
    .map(([key, score]) => ({ key, score }))
    .sort((a, b) => b.score - a.score);
  return { matchedCases, rankedDiagnoses };
}
