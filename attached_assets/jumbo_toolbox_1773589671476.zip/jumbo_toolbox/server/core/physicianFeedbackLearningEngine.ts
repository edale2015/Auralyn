import fs from 'fs';
import path from 'path';

const FILE = path.join(process.cwd(), 'physician_feedback.ndjson');

export function appendPhysicianFeedback(row: {
  caseId: string;
  agreed: boolean;
  modelDisposition?: string;
  physicianDisposition?: string;
  note?: string;
}) {
  fs.appendFileSync(FILE, JSON.stringify({ ...row, createdAt: new Date().toISOString() }) + '\n');
}

export function getPhysicianFeedbackStats() {
  if (!fs.existsSync(FILE)) return { total: 0, agreementRate: 0, recentDisagreements: [] as any[] };
  const rows = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  const total = rows.length;
  const agreementRate = total ? rows.filter((r) => r.agreed).length / total : 0;
  const recentDisagreements = rows.filter((r) => !r.agreed).slice(-10).reverse();
  return { total, agreementRate, recentDisagreements };
}
