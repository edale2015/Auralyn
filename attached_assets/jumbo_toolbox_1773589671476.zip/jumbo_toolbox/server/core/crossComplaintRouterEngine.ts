import { BrainCaseInput } from '../../shared/clinicalEngineTypes';

const ROUTES: Array<{ when: (i: BrainCaseInput) => boolean; addComplaint: string; reason: string }> = [
  { when: (i) => i.symptoms.includes('syncope'), addComplaint: 'chest_pain', reason: 'Syncope can overlap cardiac evaluation.' },
  { when: (i) => i.symptoms.includes('flank_pain') && i.symptoms.includes('dysuria'), addComplaint: 'uti', reason: 'Flank pain plus dysuria crosses into GU/UTI pathway.' },
  { when: (i) => i.symptoms.includes('neck_stiffness') && i.symptoms.includes('headache'), addComplaint: 'headache', reason: 'Neck stiffness + headache suggests neuro pathway.' },
  { when: (i) => i.symptoms.includes('shortness_of_breath') && i.symptoms.includes('leg_swelling'), addComplaint: 'chest_pain', reason: 'SOB + leg swelling may warrant PE/cardiopulmonary branch.' },
];

export function routeCrossComplaints(input: BrainCaseInput) {
  return ROUTES.filter((r) => r.when(input)).map((r) => ({ complaint: r.addComplaint, reason: r.reason }));
}
