import { BrainCaseInput, CompletenessResult } from '../../shared/clinicalEngineTypes';

const REQUIRED: Record<string, string[]> = {
  chest_pain: ['Is the pain exertional?', 'Any shortness of breath?', 'Any radiation to arm or jaw?'],
  sore_throat: ['Any fever?', 'Any muffled voice?', 'Any trouble swallowing?'],
  dysuria: ['Any flank pain?', 'Any fever?', 'Any discharge or testicular pain?'],
};

export function checkComplaintCompleteness(input: BrainCaseInput): CompletenessResult {
  const needed = REQUIRED[input.complaint] ?? [];
  const answered = new Set(input.answeredQuestions ?? []);
  const missingQuestions = needed.filter((q) => !answered.has(q));
  const level = missingQuestions.length === 0 ? 'complete' : missingQuestions.length === 1 ? 'missing_minor' : missingQuestions.length === 2 ? 'missing_major' : 'missing_critical';
  return { passed: missingQuestions.length === 0, level, missingQuestions };
}
