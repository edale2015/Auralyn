import { BrainCaseInput, SeverityScoreResult } from '../../shared/clinicalEngineTypes';

export function scoreSeverity(input: BrainCaseInput): SeverityScoreResult {
  let score = 0;
  const contributors: string[] = [];
  const add = (n: number, why: string) => { score += n; contributors.push(why); };

  for (const s of input.symptoms) {
    if (['chest_pain', 'shortness_of_breath', 'one_sided_weakness', 'thunderclap_headache'].includes(s)) add(3, `High-risk symptom: ${s}`);
    if (['diaphoresis', 'fever', 'flank_pain', 'syncope'].includes(s)) add(2, `Concerning symptom: ${s}`);
  }

  const v = input.vitals ?? {};
  if ((v.spo2 ?? 100) < 90) add(4, 'SpO2 < 90');
  if ((v.systolicBP ?? 120) < 90) add(4, 'Hypotension');
  if ((v.heartRate ?? 80) > 130) add(3, 'Marked tachycardia');
  if ((v.temperatureF ?? 98.6) >= 103) add(2, 'High fever');

  const severityLevel = score >= 9 ? 'critical' : score >= 6 ? 'high' : score >= 3 ? 'moderate' : 'low';
  return { score, severityLevel, contributors };
}
