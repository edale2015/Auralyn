import { CoordinationOutput, RankedScore } from '../../shared/clinicalEngineTypes';
import { scoreSeverity } from './severityScoringEngine';
import { checkComplaintCompleteness } from './complaintCompletenessEngine';
import { detectProtocolVariance } from './protocolVarianceEngine';
import { detectDiagnosticDrift } from './diagnosticDriftEngine';
import { runUnifiedClinicalGovernance } from './unifiedClinicalGovernanceEngine';
import { calibrateDisposition } from './dispositionCalibrationEngine';

export function runClinicalIntelligenceCoordinationLayer(params: {
  input: any;
  aggregatedDifferentials: RankedScore[];
  tests: RankedScore[];
  draftDisposition: string;
}): CoordinationOutput {
  const severity = scoreSeverity(params.input);
  const completeness = checkComplaintCompleteness(params.input);
  const variance = detectProtocolVariance(params.aggregatedDifferentials, params.tests, params.draftDisposition);
  const drift = detectDiagnosticDrift(params.input.priorSnapshots ?? [], params.aggregatedDifferentials);
  const governance = runUnifiedClinicalGovernance({ severity, completeness, variance, drift });
  const calibratedDisposition = calibrateDisposition({
    topDiagnosis: params.aggregatedDifferentials[0]?.key,
    topScore: params.aggregatedDifferentials[0]?.score,
    governance,
    severityLevel: severity.severityLevel,
    completenessPassed: completeness.passed,
  });
  return { severity, completeness, variance, drift, governance, calibratedDisposition };
}
