import fs from 'fs';
import path from 'path';

const FILE = path.join(process.cwd(), 'outcome_learning.ndjson');

export function logOutcome(row: { caseId: string; complaint: string; predictedDisposition?: string; finalDisposition?: string; predictedDiagnosis?: string; finalDiagnosis?: string }) {
  fs.appendFileSync(FILE, JSON.stringify({ ...row, createdAt: new Date().toISOString() }) + '\n');
}

export function getOutcomeStats() {
  if (!fs.existsSync(FILE)) return { total: 0, byComplaint: {} };
  const rows = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  const byComplaint: Record<string, { total: number; agreement: number }> = {};
  for (const r of rows) {
    byComplaint[r.complaint] ??= { total: 0, agreement: 0 };
    byComplaint[r.complaint].total += 1;
    if (r.predictedDisposition === r.finalDisposition) byComplaint[r.complaint].agreement += 1;
  }
  return { total: rows.length, byComplaint };
}
