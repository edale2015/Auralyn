const SYNONYMS: Record<string, string> = {
  'burning urination': 'dysuria',
  'burning with urination': 'dysuria',
  'throwing up': 'vomiting',
  'vomitting': 'vomiting',
  'worst headache of my life': 'thunderclap_headache',
  'sob': 'shortness_of_breath',
  'peeing a lot': 'urinary_frequency',
  'pee urgency': 'urinary_urgency',
  'passed out': 'syncope',
  'fainted': 'syncope',
  'stiff neck': 'neck_stiffness'
};

export function normalizeSymptoms(symptoms: string[]): string[] {
  const canonical = symptoms.map((s) => {
    const key = s.trim().toLowerCase();
    return SYNONYMS[key] ?? key.replace(/\s+/g, '_');
  });
  return [...new Set(canonical)];
}
