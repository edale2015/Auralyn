import fs from 'fs';
import path from 'path';
import { ClinicalGraphEngine } from '../core/clinicalGraphEngine';

export function loadClinicalGraph() {
  const file = path.join(process.cwd(), 'clinical_reasoning_graph.json');
  if (!fs.existsSync(file)) {
    console.warn('[clinicalGraph] Missing clinical_reasoning_graph.json, loading empty graph.');
    return new ClinicalGraphEngine();
  }
  const json = JSON.parse(fs.readFileSync(file, 'utf8'));
  return ClinicalGraphEngine.fromJSON(json);
}
