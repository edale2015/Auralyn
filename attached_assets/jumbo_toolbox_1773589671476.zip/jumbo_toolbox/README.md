# Jumbo Toolbox Reconstruction

This ZIP is a reconstructed bundle of the engine and layer families described in the chat.
It is designed to be copied into a TypeScript/Node urgent-care telemedicine codebase and adapted,
not assumed to be a byte-perfect export from prior hidden turns.

## Included families

### Core reasoning
- clinicalBrainEngine.ts
- symptomNormalizationEngine.ts
- contradictionEngine.ts
- clinicalSafetyGuard.ts
- caseSimilarityEngine.ts
- differentialProbabilityEngine.ts
- knowledgeGraphEngine.ts
- evidenceAggregatorEngine.ts
- uncertaintyEngine.ts
- nextBestQuestionEngine.ts
- treatmentEngine.ts
- testRecommendationEngine.ts
- returnPrecautionEngine.ts
- brainAuditLog.ts

### Memory / learning
- clinicalMemoryEngine.ts
- outcomeLearningEngine.ts
- physicianFeedbackLearningEngine.ts

### Governance / coordination / Wave 7
- severityScoringEngine.ts
- crossComplaintRouterEngine.ts
- protocolVarianceEngine.ts
- diagnosticDriftEngine.ts
- complaintCompletenessEngine.ts
- testYieldScoringEngine.ts
- medicationSafetyEngine.ts
- dispositionCalibrationEngine.ts
- unifiedClinicalGovernanceEngine.ts
- clinicalIntelligenceCoordinationLayer.ts
- supervisorEngine.ts
- expansionEngine.ts

### Graph tooling
- clinicalGraphEngine.ts
- server/data/clinicalGraph.ts
- scripts/buildClinicalReasoningGraph.ts

### Generalization / telepresence scaffolding
- server/core/generalization/domainGeneralizationEngine.ts
- server/services/telepresence/telepresenceOrchestrator.ts

## Suggested integration order
1. Drop the files into your `server/core`, `server/data`, `server/services`, `scripts`, and `shared` folders.
2. Wire `runClinicalBrainEngine()` into your existing pipeline after symptom intake normalization.
3. Point your review queue / physician UI to:
   - physicianFeedbackLearningEngine
   - outcomeLearningEngine
   - brainAuditLog
4. Use `buildClinicalReasoningGraph.ts` after exporting fresh CSVs from Google Sheets.
5. Expand complaint coverage by feeding complaint slugs from sheets into `planComplaintExpansion()`.

## Notes
- These files are intentionally dependency-light.
- Several maps are starter maps and should be replaced with your real Google Sheet content.
- The telepresence and generalization pieces are scaffolds, not production device-control code.
