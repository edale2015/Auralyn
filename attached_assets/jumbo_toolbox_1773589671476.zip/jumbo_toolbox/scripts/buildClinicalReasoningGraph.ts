import fs from 'fs';
import path from 'path';
import { ClinicalGraphEngine } from '../server/core/clinicalGraphEngine';

function safeReadCsv(file: string): string[][] {
  if (!fs.existsSync(file)) return [];
  return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => l.split(','));
}

export function buildClinicalReasoningGraph() {
  const graph = new ClinicalGraphEngine();
  const root = process.cwd();
  const complaint = safeReadCsv(path.join(root, 'COMPLAINT_REGISTRY.csv'));
  const scoring = safeReadCsv(path.join(root, 'CLUSTER_SCORING_RULES.csv'));
  const redFlags = safeReadCsv(path.join(root, 'RED_FLAG_RULES.csv'));
  const dx = safeReadCsv(path.join(root, 'DX_CANDIDATES.csv'));

  for (const row of complaint.slice(1)) {
    const [complaintSlug] = row;
    if (complaintSlug) graph.addNode({ id: complaintSlug, kind: 'complaint' });
  }
  for (const row of scoring.slice(1)) {
    const [symptom, diagnosis, weight] = row;
    if (symptom && diagnosis) {
      graph.addNode({ id: symptom, kind: 'symptom' });
      graph.addNode({ id: diagnosis, kind: 'diagnosis' });
      graph.addEdge({ from: symptom, to: diagnosis, relation: 'suggests', weight: Number(weight || 1) });
    }
  }
  for (const row of redFlags.slice(1)) {
    const [diagnosis, redFlagId] = row;
    if (diagnosis && redFlagId) graph.addEdge({ from: diagnosis, to: redFlagId, relation: 'red_flag', weight: 1 });
  }
  for (const row of dx.slice(1)) {
    const [diagnosis, test, treatment] = row;
    if (diagnosis && test) graph.addEdge({ from: diagnosis, to: test, relation: 'test', weight: 1 });
    if (diagnosis && treatment) graph.addEdge({ from: diagnosis, to: treatment, relation: 'treatment', weight: 1 });
  }

  fs.writeFileSync(path.join(root, 'clinical_reasoning_graph.json'), JSON.stringify(graph.toJSON(), null, 2));
  return graph.toJSON();
}

if (require.main === module) {
  buildClinicalReasoningGraph();
  console.log('clinical_reasoning_graph.json written');
}
