import { Router, Request, Response } from "express";
import { requireRole } from "../middleware/requireRole";
import { db } from "../db";
import { desc, eq } from "drizzle-orm";
import { kbComplaints, kbKnowledgeChanges } from "../../shared/schema";
import type { CaseState } from "../../shared/agentTypes";
import {
  listAvailableComplaints,
  loadComplaintConfig,
  type ComplaintConfig,
  type WorldBRow,
} from "../services/complaintConfigLoader";
import {
  findTemplate,
  renderTemplate,
  runDisposition,
  runRedFlagsComplaint,
} from "../services/complaintEngines";
import { computeScoresFromRules } from "../engines/genericComplaintEngineV1";

const router = Router();

router.use(requireRole(["admin", "physician", "clinician"]));

type LayerRow = {
  count: number;
  rows: any[];
  sourceTables: string[];
  unit: string;
};

function layer(rows: any[], sourceTables: string[], unit: string): LayerRow {
  return { count: rows.length, rows, sourceTables, unit };
}

function uniqueSources(rows: Array<WorldBRow | Record<string, any>>, fallback: string[]): string[] {
  const sources = rows
    .map(row => String((row as WorldBRow).__sourceTable ?? "").trim())
    .filter(Boolean);
  return Array.from(new Set(sources.length > 0 ? sources : fallback));
}

function rowId(row: Record<string, any>): string {
  return String(
    row.RULE_ID ?? row.ruleId ?? row.RF_ID ?? row.DISP_RULE_ID ?? row.TEMPLATE_ID ??
    row.Q_ID ?? row.QUESTION_ID ?? row.DX_ID ?? row.Diagnosis_ID ?? row.INTERVENTION_ID ??
    row.MEDICATION_ID ?? row.Medication_Name ?? row.MEDICATION_NAME ?? row.__sourceTable ?? "row"
  );
}

function rowLabel(row: Record<string, any>): string {
  return String(
    row.LABEL ?? row.label ?? row.DESCRIPTION ?? row.description ?? row.QUESTION_TEXT ??
    row.DX_LABEL ?? row.Diagnosis_Name ?? row.DIAGNOSIS_NAME ?? row.Medication_Name ??
    row.MEDICATION_NAME ?? row.INTERVENTION_LABEL ?? row.TITLE ?? row.BODY ?? rowId(row)
  );
}

function summarizeRows(rows: any[], max = 5): any[] {
  return rows.slice(0, max).map(row => ({
    id: rowId(row),
    label: rowLabel(row),
    sourceTable: row.__sourceTable,
    raw: row,
  }));
}

function normalizeFeature(input: string): string {
  return input.trim().toLowerCase().replace(/[\s-]+/g, "_");
}

function buildCaseState(complaintId: string, symptoms: string[], freeText: string, answers: Record<string, any>): CaseState {
  const normalizedSymptoms = symptoms.map(normalizeFeature).filter(Boolean);
  const answerMap: Record<string, any> = { ...answers };

  for (const symptom of normalizedSymptoms) {
    answerMap[symptom] = answerMap[symptom] ?? true;
    answerMap[`Q_${symptom.toUpperCase()}`] = answerMap[`Q_${symptom.toUpperCase()}`] ?? true;
  }

  if (freeText) {
    answerMap.free_text = freeText;
  }

  return {
    caseId: `trace-${Date.now()}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    chiefComplaint: complaintId,
    normalizedComplaint: normalizeFeature(complaintId),
    answers: answerMap,
    scores: {},
    activeClusters: [],
    diagnosisClusterIds: [],
    dispositionReasonCodes: [],
    candidateMeds: [],
    candidateDiagnoses: [],
    ruleTrace: [],
    scoringSystems: [],
    redFlags: [],
    requiredQuestionIdsMissing: [],
    recommendedActions: [],
    questionQueue: [],
    modifierAnswers: {},
    spotInterventions: [],
    confidence: { global: "MODERATE", by_inference: [] },
    normalizedSymptoms,
  } as CaseState;
}

function buildWorldBLayers(config: ComplaintConfig): Record<string, LayerRow> {
  const diagnosisRows = [
    ...config.dxCandidates,
    ...config.clusterPrimaryDiagnosis,
    ...config.globalClusterMaster,
  ];
  const clusterScoringRows = [
    ...config.clusterScoringRules,
    ...config.scoringDefs,
    ...config.scoringSystems,
  ];
  const medicationRows = [
    ...config.globalMedicationsMaster,
    ...config.medConditionIntelligenceRules,
  ];
  const dispositionPlanRows = [
    ...config.dispositionRules,
    ...config.outputTemplates,
  ];

  // User-requested display/order model:
  // Step 4 = workup, Step 5 = medication, Step 6 = red flags.
  // Red flags still force final disposition in trace output below.
  return {
    complaintIdentification: layer([config.registry], ["COMPLAINT_REGISTRY"], "complaint"),
    modifiers: layer(config.modifiers, uniqueSources(config.modifiers, ["MODIFIERS", "GLOBAL_MODIFIERS", "GLOBAL_MODIFIERS_CLEAN", "CARDS_MODIFIER_MASTER"]), "modifier"),
    questions: layer(config.coreQuestions, ["CORE_QUESTIONS"], "question"),
    workup: layer(config.urgentCareSpotInterventions, uniqueSources(config.urgentCareSpotInterventions, ["URGENT_CARE_SPOT_INTERVENTIONS"]), "workup"),
    medication: layer(medicationRows, uniqueSources(medicationRows, ["GLOBAL_MEDICATIONS_MASTER", "MED_CONDITION_INTELLIGENCE_RULES"]), "medication"),
    redFlags: layer(config.redFlagRules, ["RED_FLAG_RULES"], "red flag"),
    clusterScoring: layer(clusterScoringRows, uniqueSources(clusterScoringRows, ["CLUSTER_SCORING_RULES", "SCORING_DEFS", "SCORING_SYSTEMS"]), "cluster scoring"),
    diagnosis: layer(diagnosisRows, uniqueSources(diagnosisRows, ["DX_CANDIDATES", "CLUSTER_PRIMARY_DIAGNOSIS", "GLOBAL_CLUSTER_MASTER"]), "diagnosis"),
    dispositionPlan: layer(dispositionPlanRows, ["DISPOSITION_RULES", "OUTPUT_TEMPLATES"], "disposition/plan"),
    audit: layer([], ["audit_logs", "appendAuditEvent"], "audit event"),
  };
}

async function loadChangeHistory(complaintId: string): Promise<any[]> {
  try {
    return await db
      .select()
      .from(kbKnowledgeChanges)
      .where(eq(kbKnowledgeChanges.complaintId, complaintId))
      .orderBy(desc(kbKnowledgeChanges.createdAt))
      .limit(20);
  } catch {
    return [];
  }
}

// ── World B complaint bundle — one call returns all normalized Google Sheets layers ──
router.get("/:complaintId/bundle", async (req: Request, res: Response) => {
  const { complaintId } = req.params;
  try {
    const config = await loadComplaintConfig(complaintId, { strict: false });
    if (!config) return res.status(404).json({ error: "Complaint not found in COMPLAINT_REGISTRY" });

    const layers = buildWorldBLayers(config);
    const changes = await loadChangeHistory(config.registry.ccId);

    res.json({
      complaint: {
        complaintId: config.registry.ccId,
        label: config.registry.label || config.registry.ccId,
        category: config.registry.system,
        urgencyLevel: config.registry.defaultCluster || undefined,
        engineType: config.registry.engineType,
        sourceTable: "COMPLAINT_REGISTRY",
      },
      layers,
      changeHistory: changes,
      summary: {
        totalRules: Object.values(layers).reduce((sum, current) => sum + current.count, 0),
        hasModifiers: layers.modifiers.count > 0,
        hasQuestions: layers.questions.count > 0,
        hasWorkup: layers.workup.count > 0,
        hasMedication: layers.medication.count > 0,
        hasRedFlags: layers.redFlags.count > 0,
        hasClusterScoring: layers.clusterScoring.count > 0,
        hasDispositionPlan: layers.dispositionPlan.count > 0,
        hasDisposition: layers.dispositionPlan.count > 0,
        hasDiagnosis: layers.diagnosis.count > 0,
        lastChanged: changes[0]?.createdAt ?? null,
        source: "WORLD_B_GOOGLE_SHEETS",
      },
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ── Live clinical trace — World B provenance and requested stage order ─────────
router.post("/:complaintId/trace", async (req: Request, res: Response) => {
  const { complaintId } = req.params;
  const { symptoms = [], freeText = "", answers = {} } = req.body;

  if (!Array.isArray(symptoms) || symptoms.length === 0) {
    return res.status(400).json({ error: "symptoms must be a non-empty array of strings" });
  }

  try {
    const config = await loadComplaintConfig(complaintId, { strict: false });
    if (!config) return res.status(404).json({ error: "Complaint not found in COMPLAINT_REGISTRY" });

    const state = buildCaseState(config.registry.ccId, symptoms, String(freeText ?? ""), answers ?? {});
    const layers = buildWorldBLayers(config);

    const questionResults = config.coreQuestions.slice(0, 8).map(q => ({
      questionId: q.qId,
      question: q.questionText,
      required: q.required,
      askIf: q.askIf,
      tableName: "CORE_QUESTIONS",
    }));

    const scoringResult = computeScoresFromRules(config.clusterScoringRules, state, config.registry.ccId);
    state.scores = { ...state.scores, ...scoringResult.scores };
    state.activeClusters = scoringResult.ranked.slice(0, 3).map(r => r.clusterId);

    const rfResult = runRedFlagsComplaint(state, config.redFlagRules);
    state.redFlagGate = {
      evaluated: true,
      flagsFound: rfResult.triggeredFlags.map(f => ({
        flagId: f.rfId,
        label: f.label,
        severity: f.severity,
        action: f.action,
        reasons: [f.rationale],
        immediateActions: f.immediateActions,
        source: "RED_FLAG_RULES",
      })),
      gateResult: rfResult.gateResult,
    } as any;
    state.redFlags = rfResult.triggeredFlags.map(f => f.rfId);

    const dispResult = runDisposition(state, config.dispositionRules);
    const forcedByRedFlagGate = rfResult.gateResult !== "PASS";
    const finalDisposition = forcedByRedFlagGate
      ? rfResult.gateResult
      : dispResult.dispositionLevel;
    state.disposition = finalDisposition;

    const planTemplate = findTemplate(config.outputTemplates, dispResult.rationaleTemplateId);
    const renderedPlan = planTemplate
      ? renderTemplate(planTemplate, state, {
          disposition: finalDisposition,
          red_flag_gate: rfResult.gateResult,
          top_cluster: scoringResult.topCluster || "none",
        })
      : null;

    const diagnosisResults = [
      ...config.dxCandidates.slice(0, 8).map((d, index) => ({
        rank: d.RANK || index + 1,
        diagnosis: d.DX_LABEL,
        diagnosisId: d.DX_ID,
        clusterId: d.BEST_CLUSTER_ID,
        baseScore: d.BASE_SCORE,
        sourceTable: "DX_CANDIDATES",
      })),
      ...config.clusterPrimaryDiagnosis.slice(0, Math.max(0, 8 - Math.min(8, config.dxCandidates.length))).map(row => ({
        diagnosis: rowLabel(row),
        diagnosisId: rowId(row),
        sourceTable: row.__sourceTable,
      })),
    ].slice(0, 8);

    const workupResults = summarizeRows(config.urgentCareSpotInterventions, 6);
    const medicationRows = [...config.globalMedicationsMaster, ...config.medConditionIntelligenceRules];
    const medicationResults = summarizeRows(medicationRows, 6);

    res.json({
      ok: true,
      complaintId: config.registry.ccId,
      symptoms,
      freeText,
      engineSource: "WORLD_B_GOOGLE_SHEETS",
      activeRuleCount: Object.values(layers).reduce((sum, current) => sum + current.count, 0),
      pipeline: [
        {
          stage: "complaint_identification",
          stepNumber: 1,
          label: "Step 1 — Complaint Identification",
          triggered: true,
          results: [{ complaintId: config.registry.ccId, label: config.registry.label, sourceTable: "COMPLAINT_REGISTRY" }],
          allRuleCount: layers.complaintIdentification.count,
          sourceTables: layers.complaintIdentification.sourceTables,
        },
        {
          stage: "modifier_collection",
          stepNumber: 2,
          label: "Step 2 — Modifier Collection",
          triggered: layers.modifiers.count > 0,
          results: summarizeRows(config.modifiers, 6),
          allRuleCount: layers.modifiers.count,
          sourceTables: layers.modifiers.sourceTables,
        },
        {
          stage: "question_engine",
          stepNumber: 3,
          label: "Step 3 — Question Engine",
          triggered: config.coreQuestions.length > 0,
          results: questionResults,
          allRuleCount: layers.questions.count,
          sourceTables: layers.questions.sourceTables,
        },
        {
          stage: "workup_selection",
          stepNumber: 4,
          label: "Step 4 — Workup Selection",
          triggered: workupResults.length > 0,
          results: workupResults,
          allRuleCount: layers.workup.count,
          sourceTables: layers.workup.sourceTables,
        },
        {
          stage: "medication_safety",
          stepNumber: 5,
          label: "Step 5 — Medication Selection / Safety",
          triggered: medicationResults.length > 0,
          results: medicationResults,
          allRuleCount: layers.medication.count,
          sourceTables: layers.medication.sourceTables,
        },
        {
          stage: "safety_screen",
          stepNumber: 6,
          label: "Step 6 — Safety Screen (Red Flags)",
          triggered: rfResult.triggeredFlags.length > 0,
          results: rfResult.triggeredFlags.map(rf => ({
            ruleId: rf.rfId,
            description: rf.label,
            severity: rf.severity,
            action: rf.action,
            rationale: rf.rationale,
            immediateActions: rf.immediateActions,
            tableName: "RED_FLAG_RULES",
          })),
          allRuleCount: layers.redFlags.count,
          sourceTables: layers.redFlags.sourceTables,
        },
        {
          stage: "cluster_scoring",
          stepNumber: 7,
          label: "Step 7 — Cluster Scoring",
          triggered: scoringResult.ranked.length > 0,
          results: scoringResult.ranked.slice(0, 6).map(r => ({
            clusterId: r.clusterId,
            points: r.points,
            evidence: r.evidence,
            tableName: "CLUSTER_SCORING_RULES",
          })),
          allRuleCount: layers.clusterScoring.count,
          sourceTables: layers.clusterScoring.sourceTables,
        },
        {
          stage: "diagnosis_ranking",
          stepNumber: 8,
          label: "Step 8 — Diagnosis Ranking",
          triggered: diagnosisResults.length > 0,
          results: diagnosisResults,
          allRuleCount: layers.diagnosis.count,
          sourceTables: layers.diagnosis.sourceTables,
        },
        {
          stage: "disposition_plan",
          stepNumber: 9,
          label: "Step 9 — Disposition + Plan",
          triggered: true,
          results: [{
            ruleId: dispResult.matchedRuleId,
            disposition: finalDisposition,
            priority: config.dispositionRules.find(r => r.dispRuleId === dispResult.matchedRuleId)?.priority ?? null,
            confidenceHint: forcedByRedFlagGate ? "HIGH" : dispResult.confidenceHint,
            planTemplateId: renderedPlan?.templateId ?? dispResult.rationaleTemplateId ?? null,
            plan: renderedPlan?.rendered ?? null,
            forcedByRedFlagGate,
            redFlagGate: rfResult.gateResult,
            sourceTables: ["DISPOSITION_RULES", "OUTPUT_TEMPLATES"],
          }],
          allRuleCount: layers.dispositionPlan.count,
          sourceTables: layers.dispositionPlan.sourceTables,
        },
        {
          stage: "audit_trail",
          stepNumber: 13,
          label: "Step 13 — Audit Trail",
          triggered: true,
          results: [{
            mode: "trace_only",
            note: "Live pipeline trace is returned to the UI. Persisted clinical decisions must append an audit event during physician review.",
            sourceTable: "audit_logs",
          }],
          allRuleCount: 1,
          sourceTables: layers.audit.sourceTables,
        },
      ],
      finalDisposition,
      isEscalated: forcedByRedFlagGate,
      topDiagnosis: diagnosisResults[0] ?? null,
      tracedAt: new Date().toISOString(),
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ── All complaints list (World B selector, with legacy DB fallback) ────────────
router.get("/", async (_req: Request, res: Response) => {
  try {
    const worldBRows = await listAvailableComplaints();
    if (worldBRows.length > 0) {
      return res.json(worldBRows.map(row => ({
        complaintId: row.ccId,
        label: row.label || row.ccId,
        category: row.system,
        urgencyLevel: row.defaultCluster || undefined,
        engineType: row.engineType,
        sourceTable: "COMPLAINT_REGISTRY",
      })));
    }

    const rows = await db.select({
      complaintId: kbComplaints.complaintId,
      label: kbComplaints.label,
      category: kbComplaints.category,
      urgencyLevel: kbComplaints.urgencyLevel,
    }).from(kbComplaints).orderBy(kbComplaints.label);
    res.json(rows.map(row => ({ ...row, sourceTable: "kb_complaints" })));
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
