# Auralyn World B Clinical Pipeline Patch

This package updates the Clinical Decision Pipeline to use the normalized World B Google Sheets model.

## What changed

- Adds MODIFIERS / GLOBAL_MODIFIERS / GLOBAL_MODIFIERS_CLEAN / CARDS_MODIFIER_MASTER as first-class sources.
- Builds the pipeline from COMPLAINT_REGISTRY, CORE_QUESTIONS, RED_FLAG_RULES, SCORING_DEFS, DISPOSITION_RULES, OUTPUT_TEMPLATES, CLUSTER_SCORING_RULES, SCORING_SYSTEMS, GLOBAL_SECONDARY, GLOBAL_CLUSTER_MASTER, CLUSTER_PRIMARY_DIAGNOSIS, RED_FLAGS_MASTER, GLOBAL_MEDICATIONS_MASTER, URGENT_CARE_SPOT_INTERVENTIONS, and MED_CONDITION_INTELLIGENCE_RULES.
- Merges Disposition and Plan into one stage: `disposition_plan`.
- Uses the requested step order:
  - Step 1 — Complaint Identification
  - Step 2 — Modifier Collection
  - Step 3 — Question Engine
  - Step 4 — Workup Selection
  - Step 5 — Medication Selection / Safety
  - Step 6 — Safety Screen (Red Flags)
  - Step 7 — Cluster Scoring
  - Step 8 — Diagnosis Ranking
  - Step 9 — Disposition + Plan
  - Step 13 — Audit Trail

## Apply with git

```bash
git apply AURALYN_WORLD_B_PIPELINE_PATCH.diff
npm run check
```

## Manual copy option

Copy files from `files/` into the matching repo paths.

## Safety note

The displayed trace order moves workup and medication before red flags as requested, but red flags still force `finalDisposition` in the returned trace. AI still cannot approve clinical decisions.
