#!/usr/bin/env python3
"""
validate_tabs.py

Usage:
  python validate_tabs.py --core CORE_QUESTIONS.csv --rf RED_FLAG_RULES.csv --disp DISPOSITION_RULES.csv --cluster CLUSTER_SCORING_RULES.csv --templates OUTPUT_TEMPLATES.csv
Optional:
  --write-stubs OUTPUT_TEMPLATES_STUBBED.csv   # add stub templates for missing references
  --report report.json                        # write JSON report
  --fail-on-issues                            # exit non-zero if issues found

What it checks:
- Required columns exist
- Duplicate keys (core: CC_ID+VERSION+QUESTION_ID)
- Malformed CC_IDs (tabs / multi-space)
- CC_ID referenced in RF/DISP/CLUSTER exists in CORE
- OUTPUT_TEMPLATE_ID / RATIONALE_TEMPLATE_ID exists in templates (or can be stubbed)
- Question IDs referenced in expressions exist in CORE for that CC_ID
"""

import argparse, json, re, sys
import pandas as pd

ANSWER_TYPES = {"yesno","choice","number","single_select","multi_select","text","date","time"}

def load_csv(path):
    return pd.read_csv(path)

def validate(core_df, rf_df, disp_df, cluster_df, templates_df):
    issues = []

    # core duplicates
    key = core_df[["CC_ID","VERSION","QUESTION_ID"]].astype(str).agg("|".join, axis=1)
    dup_mask = key.duplicated(keep=False)
    if dup_mask.any():
        issues.append({"type":"DUP_CORE_QUESTION_ID", "count": int(dup_mask.sum())})

    # malformed CC_ID
    malformed_cc = core_df["CC_ID"].astype(str).str.contains(r"\s{2,}|\t", regex=True, na=False)
    if malformed_cc.any():
        sample = core_df.loc[malformed_cc, "CC_ID"].head(10).tolist()
        issues.append({"type":"MALFORMED_CC_ID_CORE", "count": int(malformed_cc.sum()), "sample": sample})

    # REQUIRED sanity
    bad_required = ~core_df["REQUIRED"].astype(str).isin(["TRUE","FALSE","true","false"])
    if bad_required.any():
        issues.append({
            "type":"BAD_REQUIRED_VALUES",
            "count": int(bad_required.sum()),
            "sample": core_df.loc[bad_required, ["CC_ID","QUESTION_ID","REQUIRED"]].head(10).to_dict("records")
        })

    core_cc = set(core_df["CC_ID"].astype(str))
    for name, df, col in [("rf", rf_df, "CC_ID"), ("disp", disp_df, "CC_ID"), ("cluster_scoring", cluster_df, "CC_ID")]:
        missing = df[~df[col].astype(str).isin(core_cc)]
        if len(missing) > 0:
            issues.append({
                "type": f"MISSING_CC_ID_IN_CORE_{name.upper()}",
                "count": int(len(missing)),
                "sample": missing[[col]].drop_duplicates().head(10)[col].tolist()
            })

    tmpl_ids = set(templates_df["TEMPLATE_ID"].astype(str))
    rf_missing_t = rf_df[~rf_df["OUTPUT_TEMPLATE_ID"].astype(str).isin(tmpl_ids) & (rf_df["OUTPUT_TEMPLATE_ID"].astype(str) != "")]
    if len(rf_missing_t)>0:
        issues.append({"type":"MISSING_RF_TEMPLATE", "count": int(len(rf_missing_t)),
                       "sample": rf_missing_t[["RF_ID","OUTPUT_TEMPLATE_ID"]].head(10).to_dict("records")})
    disp_missing_t = disp_df[~disp_df["RATIONALE_TEMPLATE_ID"].astype(str).isin(tmpl_ids) & (disp_df["RATIONALE_TEMPLATE_ID"].astype(str) != "")]
    if len(disp_missing_t)>0:
        issues.append({"type":"MISSING_DISP_TEMPLATE", "count": int(len(disp_missing_t)),
                       "sample": disp_missing_t[["DISP_RULE_ID","RATIONALE_TEMPLATE_ID"]].head(10).to_dict("records")})

    # question refs in expressions
    q_by_cc = core_df.groupby("CC_ID")["QUESTION_ID"].apply(lambda s: set(map(str, s))).to_dict()
    qid_regex = re.compile(r"\b(Q_[A-Z0-9_]+|ST_[A-Z0-9_]+)\b")
    def check_expr(df, expr_col, cc_col, id_col, kind):
        bad = []
        for _, row in df.iterrows():
            cc = str(row[cc_col])
            expr = str(row[expr_col])
            if not expr or expr == "":
                continue
            refs = set(qid_regex.findall(expr))
            if not refs:
                continue
            allowed = q_by_cc.get(cc, set())
            missing = sorted([r for r in refs if r not in allowed])
            if missing:
                bad.append({"id": row[id_col], "cc": cc, "missing_question_ids": missing[:20]})
        if bad:
            issues.append({"type": f"MISSING_QUESTION_IDS_IN_{kind}", "count": len(bad), "sample": bad[:10]})
    check_expr(rf_df, "TRIGGER_EXPR", "CC_ID", "RF_ID", "RF_RULES")
    check_expr(disp_df, "WHEN_EXPR", "CC_ID", "DISP_RULE_ID", "DISPOSITION_RULES")
    check_expr(cluster_df, "WHEN_EXPR", "CC_ID", "CLUSTER_ID", "CLUSTER_SCORING_RULES")

    return issues

def add_stub_templates(templates_df, needed_ids):
    tmpl_ids = set(templates_df["TEMPLATE_ID"].astype(str))
    missing = sorted([t for t in needed_ids if t and t not in tmpl_ids])
    if not missing:
        return templates_df, 0
    rows = []
    for tid in missing:
        rows.append({
            "TEMPLATE_SET_ID": "STUB_AUTO_v1",
            "TEMPLATE_ID": tid,
            "TITLE": f"[STUB] {tid}",
            "BODY": "Template stub auto-generated during validation. Replace with clinical wording.",
            "SAFETY_NET": "If symptoms worsen or you develop emergency warning signs, seek urgent care or call emergency services.",
            "CHANNEL_CONSTRAINTS": "ALL",
        })
    out = pd.concat([templates_df, pd.DataFrame(rows, columns=templates_df.columns)], ignore_index=True)
    out = out.drop_duplicates(subset=["TEMPLATE_ID"], keep="first")
    return out, len(missing)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--core", required=True)
    ap.add_argument("--rf", required=True)
    ap.add_argument("--disp", required=True)
    ap.add_argument("--cluster", required=True)
    ap.add_argument("--templates", required=True)
    ap.add_argument("--write-stubs", default="")
    ap.add_argument("--report", default="")
    ap.add_argument("--fail-on-issues", action="store_true")
    args = ap.parse_args()

    core = load_csv(args.core)
    rf = load_csv(args.rf)
    disp = load_csv(args.disp)
    cluster = load_csv(args.cluster)
    templates = load_csv(args.templates)

    # optionally stub templates
    if args.write_stubs:
        needed = set(rf["OUTPUT_TEMPLATE_ID"].astype(str)) | set(disp["RATIONALE_TEMPLATE_ID"].astype(str))
        needed = {t for t in needed if t and t != ""}
        templates2, n = add_stub_templates(templates, needed)
        templates2.to_csv(args.write_stubs, index=False)
        templates = templates2
        print(f"Added {n} stub templates -> {args.write_stubs}")

    issues = validate(core, rf, disp, cluster, templates)
    out = {"issues": issues, "issue_count": len(issues)}
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2)
        print(f"Wrote report: {args.report}")
    if issues:
        print(json.dumps(out, indent=2))
        if args.fail_on_issues:
            sys.exit(2)
    else:
        print("OK: no validation issues found.")

if __name__ == "__main__":
    main()
