
export function handleWhatsAppMessage(msg:string){
 console.log("WhatsApp received:", msg)
}
