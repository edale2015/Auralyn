
export function handleTelegramMessage(msg:string){
 console.log("Telegram received:", msg)
}
