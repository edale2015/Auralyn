
export function telepresenceOrchestrator(symptoms:string[]){

 const devices=[]

 if(symptoms.includes('ear_pain'))
  devices.push('otoscope')

 if(symptoms.includes('sore_throat'))
  devices.push('camera_throat')

 if(symptoms.includes('chest_pain'))
  devices.push('ekg_device')

 return devices
}
