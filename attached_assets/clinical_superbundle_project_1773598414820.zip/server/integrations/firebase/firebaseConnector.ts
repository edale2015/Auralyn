
export function storeCaseFirebase(caseData:any){
 console.log("Saving case to Firebase")
}
