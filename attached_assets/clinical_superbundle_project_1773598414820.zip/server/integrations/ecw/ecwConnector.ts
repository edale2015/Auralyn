
export function sendToECW(caseData:any){
 console.log("Sending case to eClinicalWorks")
}
