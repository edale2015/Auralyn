
export function langchainReasoning(input:any){
 return { explanation: "LangChain reasoning placeholder" }
}
