
export function scenarioGenerator(){
 const symptoms=['fever','cough','dysuria']
 const cases=[]
 for(let i=0;i<1000;i++){
  const s=symptoms[Math.floor(Math.random()*symptoms.length)]
  cases.push({symptoms:[s]})
 }
 return cases
}
