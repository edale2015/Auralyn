
import { runClinicalBrain } from "../core/clinicalSuperBrain"

export async function massSimulationEngine(cases:any[]){

 const results=[]
 for(const c of cases){
  const r=await runClinicalBrain(c)
  results.push(r)
 }
 return results
}
