
const synonyms:Record<string,string>={
 'sob':'shortness_of_breath',
 'throwing up':'vomiting'
}

export function normalizeSymptoms(symptoms:string[]){
 return symptoms.map(s=>synonyms[s] || s)
}
