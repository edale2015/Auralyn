
export function severityScoringEngine(input:any){
 let score=0

 if(input.symptoms?.includes('chest_pain')) score+=3
 if(input.vitals?.oxygenSaturation && input.vitals.oxygenSaturation < 90) score+=4

 return score
}
