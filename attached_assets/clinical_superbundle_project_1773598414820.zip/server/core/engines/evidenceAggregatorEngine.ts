
export function evidenceAggregator(bayes:any[], similarity:any[]){
 const scores:Record<string,number>={}

 function add(list:any[],w:number){
   for(const d of list){
     scores[d.diagnosis]=(scores[d.diagnosis]||0)+d.score*w
   }
 }

 add(bayes,0.7)
 add(similarity,0.3)

 return Object.entries(scores).map(([diagnosis,score])=>({diagnosis,score}))
}
