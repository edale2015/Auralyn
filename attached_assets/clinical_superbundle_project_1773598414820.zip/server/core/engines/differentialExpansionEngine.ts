
export function differentialExpansionEngine(primary:any[]){
 const expansions={
  uti:['pyelonephritis'],
  pneumonia:['covid','bronchitis']
 }
 const expanded=[...primary]

 for(const d of primary){
  const extra=expansions[d.diagnosis]||[]
  for(const e of extra)
   expanded.push({diagnosis:e,score:d.score*0.4})
 }

 return expanded
}
