
export function similarityEngine(symptoms:string[]){
 return []
}
