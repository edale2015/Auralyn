
export function diagnosticConfidenceEngine(differential:any[],entropy:number){

 const top=differential[0]?.score||0

 if(entropy<0.4 && top>0.7) return 'high'
 if(entropy<0.9) return 'moderate'
 return 'low'
}
