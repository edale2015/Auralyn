
export function bayesianEngine(symptoms:string[]){
 const map:any={
  dysuria:['uti'],
  cough:['pneumonia']
 }

 const scores:any={}

 for(const s of symptoms){
  const dx = map[s] || []
  for(const d of dx){
    scores[d]=(scores[d]||0)+1
  }
 }

 return Object.entries(scores).map(([diagnosis,score])=>({diagnosis,score}))
}
