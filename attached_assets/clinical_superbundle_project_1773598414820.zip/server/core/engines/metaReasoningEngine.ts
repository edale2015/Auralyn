
export function metaReasoningEngine(state:any){
 const issues=[]
 if(state.entropy>1) issues.push("high_uncertainty")
 if(!state.tests?.length) issues.push("no_tests")
 return issues
}
