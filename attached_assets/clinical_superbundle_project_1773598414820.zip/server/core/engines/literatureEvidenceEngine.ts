
export function literatureEvidenceEngine(symptoms:string[]){

 const map:any={
  pleuritic_pain:['pulmonary_embolism']
 }

 const scores:any={}

 for(const s of symptoms){
  const dx=map[s]||[]
  for(const d of dx) scores[d]=(scores[d]||0)+1
 }

 return Object.entries(scores).map(([diagnosis,score])=>({diagnosis,score}))
}
