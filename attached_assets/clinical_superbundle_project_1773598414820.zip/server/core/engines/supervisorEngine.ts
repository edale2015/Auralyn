
export function supervisorEngine({entropy,severity}:{entropy:number,severity:number}){

 if(severity>=4)
  return {decision:'ESCALATE'}

 if(entropy>1.2)
  return {decision:'REVIEW'}

 return {decision:'PASS'}
}
