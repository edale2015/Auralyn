
export function actionPlanningEngine(diagnosis:string){

 const plans:any={
  pneumonia:{tests:['chest_xray'],treatments:['antibiotics']},
  myocardial_infarction:{tests:['ecg'],treatments:['aspirin']}
 }

 return plans[diagnosis] || {}
}
