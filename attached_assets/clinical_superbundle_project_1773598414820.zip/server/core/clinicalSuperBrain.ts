
import { normalizeSymptoms } from "./engines/symptomNormalizationEngine"
import { bayesianEngine } from "./engines/bayesianEngine"
import { similarityEngine } from "./engines/similarityEngine"
import { evidenceAggregator } from "./engines/evidenceAggregatorEngine"
import { entropy } from "./engines/uncertaintyEngine"
import { severityScoringEngine } from "./engines/severityScoringEngine"
import { supervisorEngine } from "./engines/supervisorEngine"

export async function runClinicalBrain(input:any){

 const normalized = normalizeSymptoms(input.symptoms)

 const bayes = bayesianEngine(normalized)
 const similarity = similarityEngine(normalized)

 const differential = evidenceAggregator(bayes, similarity)

 const entropyScore = entropy(differential.map(d=>d.score))

 const severity = severityScoringEngine(input)

 const governance = supervisorEngine({
   entropy: entropyScore,
   severity
 })

 return {
   normalizedSymptoms: normalized,
   differential,
   entropy: entropyScore,
   severity,
   governance
 }
}
