import express from 'express';
import { mapLegacyTabs, LegacyTabData } from '../engines/legacyTabMapper';

const router = express.Router();

router.post('/dry-run', async (req, res) => {
  const tabs = (req.body?.tabs || []) as LegacyTabData[];
  const result = mapLegacyTabs(tabs);
  res.json({ ok: true, ...result, counts: {
    symptomPackRows: result.symptomPackRows.length,
    modifierPackRows: result.modifierPackRows.length,
    questionRows: result.questionRows.length,
    algorithmRows: result.algorithmRows.length,
    planTemplateRows: result.planTemplateRows.length,
    issues: result.issues.length,
  }});
});

export default router;
