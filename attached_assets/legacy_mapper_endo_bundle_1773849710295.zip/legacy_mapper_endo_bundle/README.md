# Legacy Tab Mapper + Endocrinology Expansion

## What was added
- `server/engines/legacyTabMapper.ts`
  - Maps legacy/raw workbook tabs into normalized canonical rows
  - Supports complaint/symptom tabs, secondary question tabs, modifier tabs, and triage tabs
- `server/routes/legacyTabMapperRoutes.ts`
  - `POST /api/legacy-tab-mapper/dry-run`
- `server/config/systemContent/endocrinologyExpansion.ts`
  - Expanded endocrinology symptom packs, question rows, modifiers, clinician algorithms

## Route registration
Add this to `server/index.ts`:

```ts
import legacyTabMapperRoutes from './routes/legacyTabMapperRoutes';
app.use('/api/legacy-tab-mapper', legacyTabMapperRoutes);
```

## Dry-run payload example
```json
{
  "tabs": [
    {
      "tabName": "Endocrinology Complaints",
      "rows": [
        {
          "Complaint": "Hyperglycemia",
          "Disposition": "telemed_now",
          "Red Flags": "vomiting|confusion",
          "AutoEscalateRules": "vomiting=yes|confusion=yes"
        }
      ]
    },
    {
      "tabName": "Endocrinology Secondary Questions",
      "rows": [
        {
          "Complaint": "Hyperglycemia",
          "Question": "Any vomiting?",
          "Priority": 1
        }
      ]
    }
  ]
}
```

## Notes
- This mapper is heuristic. It gets you a strong first-pass normalization.
- For workbook-specific tabs with unusual columns, add a custom mapper branch in `legacyTabMapper.ts`.
- Endocrinology expansion is starter-to-mid depth, not the final full 15-pack library yet.
