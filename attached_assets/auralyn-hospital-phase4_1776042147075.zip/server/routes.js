
const express = require("express");
const db = require("./db");
const { lactateTrend, bayesianRisk } = require("./predictiveEngine");
const { vote } = require("./agents");
const { intervention } = require("./intervention");
const { writeObservation } = require("./fhir");

const router = express.Router();

router.post("/patient", async (req,res)=>{
  const { name, age, vitals } = req.body;

  const p = await db("INSERT INTO patients(name,age,vitals) VALUES($1,$2,$3) RETURNING *",
    [name,age,vitals]);

  await db("INSERT INTO vitals_history(patient_id,vitals) VALUES($1,$2)",
    [p.rows[0].id, vitals]);

  const hist = await db("SELECT * FROM vitals_history WHERE patient_id=$1",[p.rows[0].id]);

  const trend = lactateTrend(hist.rows);
  const risk = bayesianRisk(vitals, trend);
  const council = vote(vitals);
  const action = intervention(risk);

  await db("INSERT INTO predictions(patient_id,sepsis_risk,trend) VALUES($1,$2,$3)",
    [p.rows[0].id, risk, trend]);

  await db("INSERT INTO interventions(patient_id,recommendation) VALUES($1,$2)",
    [p.rows[0].id, action]);

  await writeObservation(p.rows[0].id, vitals);

  res.json({ patient:p.rows[0], risk, trend, council, action });
});

router.get("/dashboard", async (req,res)=>{
  const data = await db("SELECT * FROM predictions ORDER BY sepsis_risk DESC");
  res.json(data.rows);
});

module.exports = router;
