
function ICU(v) { return v.bp < 90 ? 0.9 : 0.3; }
function ED(v) { return v.temp > 38 ? 0.7 : 0.2; }
function ID(v) { return v.wbc > 12000 ? 0.8 : 0.3; }

function vote(vitals) {
  const scores = {
    ICU: ICU(vitals),
    ED: ED(vitals),
    ID: ID(vitals)
  };
  const avg = (scores.ICU + scores.ED + scores.ID)/3;
  return { scores, avg };
}

module.exports = { vote };
