
const { Server } = require("ws");
const db = require("./db");

module.exports = function(server){
  const wss = new Server({ server });
  wss.on("connection", ws=>{
    setInterval(async ()=>{
      const r = await db("SELECT * FROM predictions ORDER BY created_at DESC LIMIT 10");
      ws.send(JSON.stringify(r.rows));
    },2000);
  });
};
