
const axios = require("axios");

async function writeObservation(patientId, vitals) {
  try {
    await axios.post(process.env.FHIR_BASE_URL + "/Observation", {
      subject: { reference: "Patient/" + patientId },
      valueString: JSON.stringify(vitals)
    });
  } catch(e) {
    console.log("FHIR error");
  }
}

module.exports = { writeObservation };
