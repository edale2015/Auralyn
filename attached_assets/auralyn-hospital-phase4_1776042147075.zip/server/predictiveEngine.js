
function lactateTrend(history) {
  if (history.length < 2) return "stable";
  const last = history[history.length-1].vitals.lactate || 1;
  const prev = history[history.length-2].vitals.lactate || 1;
  if (last > prev) return "rising";
  return "stable";
}

function bayesianRisk(vitals, trend) {
  let risk = 0.2;
  if (vitals.bp < 90) risk += 0.3;
  if (vitals.o2 < 92) risk += 0.2;
  if (trend === "rising") risk += 0.3;
  return Math.min(risk,1);
}

module.exports = { lactateTrend, bayesianRisk };
