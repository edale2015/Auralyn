
function intervention(risk) {
  if (risk > 0.8) return "Sepsis bundle + ICU + broad antibiotics";
  if (risk > 0.5) return "Labs, IV fluids, monitor lactate";
  return "Outpatient follow-up";
}
module.exports = { intervention };
