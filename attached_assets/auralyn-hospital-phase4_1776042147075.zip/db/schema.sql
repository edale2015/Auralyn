
CREATE TABLE patients (
  id SERIAL PRIMARY KEY,
  name TEXT,
  age INT,
  vitals JSONB,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE vitals_history (
  id SERIAL PRIMARY KEY,
  patient_id INT,
  vitals JSONB,
  recorded_at TIMESTAMP DEFAULT now()
);

CREATE TABLE predictions (
  id SERIAL PRIMARY KEY,
  patient_id INT,
  sepsis_risk FLOAT,
  trend TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE interventions (
  id SERIAL PRIMARY KEY,
  patient_id INT,
  recommendation TEXT,
  created_at TIMESTAMP DEFAULT now()
);
