import path from 'node:path';
import { Worker } from 'node:worker_threads';
import { logger } from '../utils/logger';

export interface BackgroundWorkerHandle {
  name: string;
  stop?: () => Promise<void>;
}

function spawnWorker(scriptName: string, name: string): BackgroundWorkerHandle | null {
  const workerPath = path.resolve(process.cwd(), 'dist', 'workers', scriptName);
  try {
    const worker = new Worker(workerPath);
    worker.on('error', (err) => logger.error(`[workerBootstrap] ${name} worker error`, { error: err.message }));
    worker.on('exit', (code) => logger.info(`[workerBootstrap] ${name} worker exited`, { code }));
    return {
      name,
      stop: async () => {
        await worker.terminate();
      },
    };
  } catch (error: any) {
    logger.warn(`[workerBootstrap] Failed to spawn ${name} worker`, { error: error?.message });
    return null;
  }
}

export function startBackgroundWorkers(): BackgroundWorkerHandle[] {
  if (process.env.NODE_ENV !== 'production') {
    logger.info('[workerBootstrap] Background workers disabled outside compiled production build');
    return [];
  }
  return [
    spawnWorker('goldenCaseWorker.js', 'golden-case'),
    spawnWorker('autoHealingWorker.js', 'auto-healing'),
  ].filter(Boolean) as BackgroundWorkerHandle[];
}
