# Auralyn Full-Spectrum Upgrade Bundle

This bundle implements the highest-priority remediations and architectural upgrades recommended in the review:

1. Acuity fast-path pre-classifier
2. Durable BullMQ/Redis queues with idempotency
3. PostgreSQL row-level security and tenant session binding
4. Unified PostgreSQL-backed agent registry
5. Evolution proposal -> staging -> approval -> canary -> promotion workflow
6. External write-once audit sink adapter
7. Route decomposition into 8 domain routers
8. Tenant config persistence
9. Background loop isolation with worker threads
10. Frontend-backend correlation IDs and physician override audit events
11. Golden-case escalation test scaffolding

## Important
This is a production-oriented integration bundle, not a blind line-by-line merge into your real repository. The code is designed to drop into an existing Node.js + TypeScript + Express + React/Vite + Drizzle stack with minimal reshaping.

## Files
- `server/clinical/acuityPreClassifier.ts`
- `server/clinical/fastPathRouter.ts`
- `server/queue/queueFactory.ts`
- `server/queue/clinicalPipelineQueue.ts`
- `server/middleware/tenantContext.ts`
- `server/middleware/correlation.ts`
- `server/agents/unifiedAgentRegistry.ts`
- `server/evolution/evolutionService.ts`
- `server/observability/externalAuditSink.ts`
- `server/tenancy/tenantConfigService.ts`
- `server/workers/*.ts`
- `server/routes/*.ts`
- `sql/*.sql`
- `tests/*.test.ts`
- `web/src/lib/correlation.ts`
- `web/src/components/PhysicianOverrideDialog.tsx`

## Integration order
1. Run SQL migrations in `sql/`.
2. Install BullMQ/Redis/S3 SDK dependencies.
3. Mount the new routers in `server/routes/index.ts`.
4. Insert the correlation and tenant middleware before protected routes.
5. Replace in-memory queue usage with `clinicalPipelineQueue` enqueue calls.
6. Move background loops into `worker_threads` via `workerBootstrap.ts`.
7. Add correlation headers from the React frontend.
8. Run the included tests and extend the golden cases.
