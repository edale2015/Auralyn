CREATE TABLE IF NOT EXISTS agent_registry (
  agent_id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'healthy',
  last_heartbeat TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  circuit_breaker_state TEXT NOT NULL DEFAULT 'closed',
  p95_latency_ms DOUBLE PRECISION NOT NULL DEFAULT 0,
  success_rate DOUBLE PRECISION NOT NULL DEFAULT 1,
  version TEXT NOT NULL
);
