ALTER TABLE encounters ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY encounters_tenant_isolation ON encounters
USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

CREATE POLICY tenant_configs_isolation ON tenant_configs
USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

CREATE POLICY audit_events_isolation ON audit_events
USING (tenant_id = current_setting('app.current_tenant_id')::uuid);
