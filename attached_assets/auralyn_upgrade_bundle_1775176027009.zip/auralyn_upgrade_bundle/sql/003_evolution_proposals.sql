CREATE TABLE IF NOT EXISTS evolution_proposals (
  proposal_id TEXT PRIMARY KEY,
  target_agent TEXT NOT NULL,
  parameter_change JSONB NOT NULL,
  rationale TEXT NOT NULL,
  urgency TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  proposed_by TEXT NOT NULL,
  approved_by TEXT,
  rollback_reason TEXT,
  proposed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  approved_at TIMESTAMPTZ,
  staged_at TIMESTAMPTZ,
  canary_started_at TIMESTAMPTZ,
  rolled_back_at TIMESTAMPTZ,
  rejected_at TIMESTAMPTZ
);
