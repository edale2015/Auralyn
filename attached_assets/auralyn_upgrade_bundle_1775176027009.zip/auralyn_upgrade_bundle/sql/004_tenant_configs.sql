CREATE TABLE IF NOT EXISTS tenant_configs (
  tenant_id UUID PRIMARY KEY,
  feature_flags JSONB NOT NULL DEFAULT '{}'::jsonb,
  capacity_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  case_mix_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by TEXT NOT NULL
);
