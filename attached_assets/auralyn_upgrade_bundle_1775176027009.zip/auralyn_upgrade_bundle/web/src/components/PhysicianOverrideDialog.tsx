import { useState } from 'react';
import { apiFetch, getOrCreateCorrelationId } from '../lib/correlation';

export default function PhysicianOverrideDialog(props: {
  encounterId: string;
  originalRecommendation: string;
  onSaved?: () => void;
}) {
  const [overrideValue, setOverrideValue] = useState('');
  const [rationale, setRationale] = useState('');
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    try {
      await apiFetch(`/api/clinical/encounters/${props.encounterId}/override`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          originalRecommendation: props.originalRecommendation,
          overrideValue,
          rationale,
          correlationId: getOrCreateCorrelationId(),
          timestamp: new Date().toISOString(),
        }),
      });
      props.onSaved?.();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-2xl border p-4 space-y-3">
      <div className="text-lg font-semibold">Physician Override</div>
      <div className="text-sm">Original AI recommendation: {props.originalRecommendation}</div>
      <input className="w-full border rounded p-2" value={overrideValue} onChange={e => setOverrideValue(e.target.value)} placeholder="Override value" />
      <textarea className="w-full border rounded p-2" value={rationale} onChange={e => setRationale(e.target.value)} placeholder="Required rationale" />
      <button className="border rounded px-4 py-2" disabled={!overrideValue || !rationale || saving} onClick={submit}>
        {saving ? 'Saving...' : 'Save Override'}
      </button>
    </div>
  );
}
