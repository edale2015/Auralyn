import { describe, expect, it } from 'vitest';
import { classifyAcuity } from '../server/clinical/acuityPreClassifier';

describe('classifyAcuity', () => {
  it('routes high-risk chest pain to ER_NOW', () => {
    const result = classifyAcuity({ symptoms: ['chest pain', 'diaphoresis', 'jaw pain'] });
    expect(result.disposition).toBe('ER_NOW');
    expect(result.signal).toBe('possible_stemi');
  });

  it('routes classic stroke pattern to ER_NOW', () => {
    const result = classifyAcuity({ symptoms: ['facial droop', 'left arm weakness', 'slurred speech'] });
    expect(result.disposition).toBe('ER_NOW');
    expect(result.signal).toBe('possible_stroke');
  });
});
