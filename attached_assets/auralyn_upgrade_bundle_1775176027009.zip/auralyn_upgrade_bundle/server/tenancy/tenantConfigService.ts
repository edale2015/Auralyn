import { and, eq } from 'drizzle-orm';

export interface TenantConfigRecord {
  tenantId: string;
  featureFlags: Record<string, boolean>;
  capacityRules: Record<string, unknown>;
  caseMixConfig: Record<string, unknown>;
  version: number;
  updatedAt: Date;
  updatedBy: string;
}

export class TenantConfigService {
  constructor(private readonly db: any, private readonly tenantConfigsTable: any) {}

  async getTenantConfig(tenantId: string): Promise<TenantConfigRecord | null> {
    const rows = await this.db.select().from(this.tenantConfigsTable).where(eq(this.tenantConfigsTable.tenantId, tenantId)).limit(1);
    return rows[0] ?? null;
  }

  async upsertTenantConfig(input: Omit<TenantConfigRecord, 'updatedAt' | 'version'> & { version?: number }): Promise<TenantConfigRecord> {
    const existing = await this.getTenantConfig(input.tenantId);
    const version = (existing?.version ?? 0) + 1;
    const payload = { ...input, version, updatedAt: new Date() };
    await this.db.insert(this.tenantConfigsTable).values(payload).onConflictDoUpdate({
      target: this.tenantConfigsTable.tenantId,
      set: payload,
    });
    const latest = await this.getTenantConfig(input.tenantId);
    if (!latest) throw new Error(`Tenant config write failed for ${input.tenantId}`);
    return latest;
  }
}
