import { Queue, Worker, JobsOptions, type Processor } from 'bullmq';
import IORedis from 'ioredis';

const redisUrl = process.env.UPSTASH_REDIS_URL || process.env.REDIS_URL;
if (!redisUrl) {
  throw new Error('Missing REDIS_URL or UPSTASH_REDIS_URL for BullMQ queue initialization');
}

export const redisConnection = new IORedis(redisUrl, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
  lazyConnect: true,
});

export interface QueueFactoryOptions<T = unknown> {
  name: string;
  processor?: Processor<T>;
  defaultJobOptions?: JobsOptions;
}

export function createDurableQueue<T = unknown>(options: QueueFactoryOptions<T>): {
  queue: Queue<T>;
  worker?: Worker<T>;
} {
  const queue = new Queue<T>(options.name, {
    connection: redisConnection,
    defaultJobOptions: options.defaultJobOptions ?? {
      removeOnComplete: 1000,
      removeOnFail: 5000,
      attempts: 5,
      backoff: { type: 'exponential', delay: 2000 },
    },
  });

  const worker = options.processor
    ? new Worker<T>(options.name, options.processor, { connection: redisConnection, concurrency: 10 })
    : undefined;

  return { queue, worker };
}
