import crypto from 'node:crypto';
import { createDurableQueue } from './queueFactory';

export interface ClinicalPipelineJob {
  encounterId: string;
  tenantId: string;
  correlationId: string;
  stage: 'intake' | 'triage' | 'reasoning' | 'output' | 'claim_submission';
  payload: Record<string, unknown>;
}

function buildIdempotencyKey(job: ClinicalPipelineJob): string {
  return crypto
    .createHash('sha256')
    .update(`${job.encounterId}:${job.tenantId}:${job.stage}:${job.correlationId}`)
    .digest('hex');
}

export const { queue: clinicalPipelineQueue, worker: clinicalPipelineWorker } = createDurableQueue<ClinicalPipelineJob>({
  name: 'clinical_pipeline',
  processor: async job => {
    // Replace these comments with your real orchestrator calls.
    // await setTenantContext(job.data.tenantId);
    // await runClinicalStage(job.data.stage, job.data.payload, { correlationId: job.data.correlationId });
    return { ok: true, processedStage: job.data.stage, encounterId: job.data.encounterId };
  },
});

export async function enqueueClinicalJob(job: ClinicalPipelineJob): Promise<string> {
  const idempotencyKey = buildIdempotencyKey(job);
  await clinicalPipelineQueue.add(job.stage, job, { jobId: idempotencyKey });
  return idempotencyKey;
}
