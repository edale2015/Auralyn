import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

export interface AuditEvent {
  auditId: string;
  tenantId: string;
  correlationId: string;
  actorId?: string;
  eventType: string;
  payload: Record<string, unknown>;
  hash: string;
  prevHash: string;
  createdAt: string;
}

const bucket = process.env.AUDIT_S3_BUCKET;
const region = process.env.AWS_REGION || 'us-east-1';
const client = new S3Client({ region });

export async function writeAuditEventToExternalStore(event: AuditEvent): Promise<void> {
  if (!bucket) throw new Error('Missing AUDIT_S3_BUCKET for external audit sink');
  const key = `audit/${new Date(event.createdAt).toISOString().slice(0, 10)}/${event.auditId}.json`;
  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: JSON.stringify(event),
      ContentType: 'application/json',
      ObjectLockMode: 'COMPLIANCE',
      ObjectLockRetainUntilDate: new Date(Date.now() + 3650 * 24 * 60 * 60 * 1000),
    }),
  );
}
