import type { Request, Response } from 'express';
import { classifyAcuity, type IntakeSnapshot } from './acuityPreClassifier';

export interface FastPathResult {
  status: 'fast_path_er_now' | 'continue_pipeline';
  message: string;
  instructions?: string[];
  acuitySignal?: string;
  rationale?: string[];
}

export function runFastPath(snapshot: IntakeSnapshot): FastPathResult {
  const decision = classifyAcuity(snapshot);
  if (!decision.matched) {
    return { status: 'continue_pipeline', message: 'No immediate fast-path escalation triggered.' };
  }

  return {
    status: 'fast_path_er_now',
    acuitySignal: decision.signal,
    rationale: decision.rationale,
    message: 'This presentation may represent a medical emergency. Seek emergency care now.',
    instructions: [
      'Call 911 or go to the nearest emergency department immediately.',
      'Do not drive yourself if you feel unsafe, weak, dizzy, or short of breath.',
      'If symptoms worsen while waiting, call emergency services now.',
    ],
  };
}

export async function fastPathExpressHandler(req: Request, res: Response): Promise<void> {
  const snapshot = req.body as IntakeSnapshot;
  const result = runFastPath(snapshot);
  res.status(result.status === 'fast_path_er_now' ? 200 : 202).json(result);
}
