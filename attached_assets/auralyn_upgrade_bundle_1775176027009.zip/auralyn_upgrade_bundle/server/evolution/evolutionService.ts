export type ProposalStatus = 'pending' | 'staging' | 'approved' | 'rejected' | 'canary' | 'promoted' | 'rolled_back';

export interface EvolutionProposalInput {
  proposalId: string;
  targetAgent: string;
  parameterChange: Record<string, unknown>;
  rationale: string;
  urgency: 'low' | 'medium' | 'high';
  proposedBy: string;
}

export class EvolutionService {
  constructor(private readonly db: any, private readonly proposalsTable: any) {}

  async createProposal(input: EvolutionProposalInput): Promise<void> {
    await this.db.insert(this.proposalsTable).values({
      ...input,
      status: 'pending',
      proposedAt: new Date(),
    });
  }

  async approveProposal(proposalId: string, approvedBy: string): Promise<void> {
    await this.db.update(this.proposalsTable).set({ status: 'approved', approvedBy, approvedAt: new Date() }).where({ proposalId });
  }

  async moveToStaging(proposalId: string): Promise<void> {
    await this.db.update(this.proposalsTable).set({ status: 'staging', stagedAt: new Date() }).where({ proposalId });
  }

  async validateAndCanary(
    proposalId: string,
    validator: () => Promise<{ escalationCasesPass: boolean; overallPassRate: number }>,
  ): Promise<{ promoted: boolean; reason: string }> {
    const result = await validator();
    if (!result.escalationCasesPass || result.overallPassRate < 0.9) {
      await this.db.update(this.proposalsTable).set({ status: 'rejected', rejectedAt: new Date() }).where({ proposalId });
      return { promoted: false, reason: 'Validation thresholds not met' };
    }

    await this.db.update(this.proposalsTable).set({ status: 'canary', canaryStartedAt: new Date() }).where({ proposalId });
    return { promoted: true, reason: 'Ready for 10% canary rollout' };
  }

  async rollbackProposal(proposalId: string, reason: string): Promise<void> {
    await this.db.update(this.proposalsTable).set({ status: 'rolled_back', rollbackReason: reason, rolledBackAt: new Date() }).where({ proposalId });
  }
}
