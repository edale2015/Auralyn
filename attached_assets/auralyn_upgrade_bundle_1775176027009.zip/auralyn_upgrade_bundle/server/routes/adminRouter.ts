import { Router } from 'express';

const router = Router();

router.get('/health', (_req, res) => {
  res.json({ domain: 'admin', ok: true });
});

export default router;
