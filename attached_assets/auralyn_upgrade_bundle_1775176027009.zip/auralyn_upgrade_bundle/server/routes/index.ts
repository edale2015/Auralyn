import { Router } from 'express';
import clinicalRouter from './clinicalRouter';
import billingRouter from './billingRouter';
import learningRouter from './learningRouter';
import agentRouter from './agentRouter';
import adminRouter from './adminRouter';
import observabilityRouter from './observabilityRouter';
import authRouter from './authRouter';
import integrationsRouter from './integrationsRouter';

export function buildDomainRouters(): Router {
  const router = Router();
  router.use('/clinical', clinicalRouter);
  router.use('/billing', billingRouter);
  router.use('/learning', learningRouter);
  router.use('/agents', agentRouter);
  router.use('/admin', adminRouter);
  router.use('/observability', observabilityRouter);
  router.use('/auth', authRouter);
  router.use('/integrations', integrationsRouter);
  return router;
}
