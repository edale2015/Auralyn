import { eq } from 'drizzle-orm';

export type AgentStatus = 'healthy' | 'warning' | 'degraded' | 'critical' | 'disabled';
export type CircuitBreakerState = 'closed' | 'open' | 'half_open';

export interface AgentHeartbeatInput {
  agentId: string;
  type: 'coordinator' | 'task' | 'governance' | 'ms';
  version: string;
  p95LatencyMs?: number;
  successRate?: number;
  status?: AgentStatus;
  circuitBreakerState?: CircuitBreakerState;
}

export class UnifiedAgentRegistry {
  constructor(private readonly db: any, private readonly agentRegistryTable: any) {}

  async upsertHeartbeat(input: AgentHeartbeatInput): Promise<void> {
    await this.db.insert(this.agentRegistryTable).values({
      agentId: input.agentId,
      type: input.type,
      version: input.version,
      lastHeartbeat: new Date(),
      p95LatencyMs: input.p95LatencyMs ?? 0,
      successRate: input.successRate ?? 1,
      status: input.status ?? 'healthy',
      circuitBreakerState: input.circuitBreakerState ?? 'closed',
    }).onConflictDoUpdate({
      target: this.agentRegistryTable.agentId,
      set: {
        lastHeartbeat: new Date(),
        p95LatencyMs: input.p95LatencyMs ?? 0,
        successRate: input.successRate ?? 1,
        status: input.status ?? 'healthy',
        version: input.version,
        circuitBreakerState: input.circuitBreakerState ?? 'closed',
      },
    });
  }

  async markMissedHeartbeatsAsDegraded(maxAgeMs = 90_000): Promise<number> {
    const threshold = new Date(Date.now() - maxAgeMs);
    const result = await this.db.execute(
      `update agent_registry set status = 'degraded' where last_heartbeat < $1 and status not in ('disabled', 'critical')`,
      [threshold],
    );
    return Number(result.rowCount ?? 0);
  }

  async getAgent(agentId: string): Promise<any | null> {
    const rows = await this.db.select().from(this.agentRegistryTable).where(eq(this.agentRegistryTable.agentId, agentId)).limit(1);
    return rows[0] ?? null;
  }
}
