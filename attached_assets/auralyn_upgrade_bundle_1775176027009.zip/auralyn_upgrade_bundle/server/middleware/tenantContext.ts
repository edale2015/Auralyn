import type { NextFunction, Request, Response } from 'express';
import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import { sql } from 'drizzle-orm';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    role: string;
    tenantId: string;
  };
  tenantId?: string;
}

export function tenantContextMiddleware(db: NodePgDatabase) {
  return async function tenantContext(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    try {
      const tenantId = req.user?.tenantId || req.header('x-tenant-id');
      if (!tenantId) {
        res.status(401).json({ error: 'Missing tenant context' });
        return;
      }
      req.tenantId = tenantId;
      await db.execute(sql.raw(`select set_config('app.current_tenant_id', '${tenantId}', true)`));
      next();
    } catch (error) {
      next(error);
    }
  };
}
