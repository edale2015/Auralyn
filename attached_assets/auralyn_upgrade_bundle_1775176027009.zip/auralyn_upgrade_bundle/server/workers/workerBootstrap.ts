import path from 'node:path';
import { Worker } from 'node:worker_threads';

export function startBackgroundWorkers(): Worker[] {
  const workers = ['goldenCaseWorker.ts', 'autoHealingWorker.ts', 'learningWorker.ts'].map(file => {
    const worker = new Worker(path.join(__dirname, file));
    worker.on('message', msg => console.log('[worker]', file, msg));
    worker.on('error', err => console.error('[worker:error]', file, err));
    return worker;
  });
  return workers;
}
