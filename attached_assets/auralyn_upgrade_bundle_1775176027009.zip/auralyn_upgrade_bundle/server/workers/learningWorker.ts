import { parentPort } from 'node:worker_threads';

setInterval(async () => {
  parentPort?.postMessage({ type: 'learning_tick', at: new Date().toISOString() });
}, 60_000);
