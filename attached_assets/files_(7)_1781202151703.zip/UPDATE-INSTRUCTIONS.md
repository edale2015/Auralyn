# Story Studio — Apply Writing Coach Update

This zip contains 4 new files and 5 modified files that add a Writing Coach to Story Studio. All changes are additive — every existing page, device, and feature keeps working exactly as before. The code was written against the current source and all files parse clean; your job is to copy them in, build, and verify.

**Path note:** paths in this zip start at `story-studio/` and `api-server/`. In this Repl those live under `artifacts/story-studio/` and `artifacts/api-server/` — apply each file to the matching path.

## T001 — Apply the files

**Status:** ⏳ Not started

**Files to create** (copy verbatim from the zip — do NOT regenerate or summarize):
1. `artifacts/story-studio/src/data/coach-content.ts` (480 coach concepts; large file ~103 KB — copy it whole)
2. `artifacts/story-studio/src/data/writing-toolbox.ts`
3. `artifacts/story-studio/src/data/device-extras.ts`
4. `artifacts/story-studio/src/pages/Coach.tsx`

**Files to replace with the zip versions:**
5. `artifacts/story-studio/src/App.tsx` (adds /coach route)
6. `artifacts/story-studio/src/components/layout/Header.tsx` (adds Coach nav link)
7. `artifacts/story-studio/src/components/StoryBlueprint.tsx` (adds Storybook Worlds settings, Storybook Friends characters, 12 new plot chips — all existing chips kept)
8. `artifacts/story-studio/src/pages/Devices.tsx` (adds Spot it!/Try it! blocks to device cards)
9. `artifacts/api-server/src/routes/devices.ts` (adds one new device: Idiom, in Voice & Feeling — same shape as existing devices, no schema change)

**Acceptance criteria:**
1. All 9 files match the zip versions exactly.
2. No OpenAPI spec changes were made and no codegen is needed (the new device uses the existing schema shape).

**Verification:**
```bash
node -e "
const ts=require('typescript'),fs=require('fs');
const src=fs.readFileSync('artifacts/story-studio/src/data/coach-content.ts','utf8');
const js=ts.transpileModule(src,{compilerOptions:{module:1}}).outputText;
const m={exports:{}};new Function('exports','require','module',js)(m.exports,require,m);
const c=m.exports.COACH_BOOKS.reduce((n,b)=>n+b.chapters.reduce((x,ch)=>x+ch.concepts.length,0),0);
console.log('books='+m.exports.COACH_BOOKS.length,'concepts='+c);
"
grep -c '"idiom"' artifacts/api-server/src/routes/devices.ts
```

**Required output:** `books=4 concepts=480` and grep count `1`.

**Dependencies:** none

## T002 — Build and restart

**Status:** ⏳ Not started

**Files to create/modify:** none

**Acceptance criteria:**
1. Full typecheck and build pass with zero errors.
2. API server restarted (required after the devices.ts change — it builds with esbuild on startup).
3. Frontend workflow restarted only after the build is clean.

**Verification:**
```bash
pnpm run typecheck
pnpm run build
```

**Required output:** Both commands exit 0 with no errors. If typecheck fails, report the exact errors and stop — do not rewrite the new files to "fix" them by deleting content.

**Dependencies:** T001

## T003 — Smoke-test in the browser

**Status:** ⏳ Not started

**Acceptance criteria:**
1. Header shows a new "Coach" link; clicking it opens /coach.
2. Coach Tips tab: 4 books render; opening a book shows 24 numbered lessons; opening a lesson shows 5 tip cards each with a "Try it!" box; "Surprise me!" shows a random tip.
3. Toolbox tab: Three Kinds of Writing, Story Maps & Frames, Glue Words, The 5 Writer Steps, Sentence Fix-Up Tools, and Quick Start Prompts all render; a Quick Start "Write it!" button opens /write with the prompt as topic.
4. Magic Words (/devices): every existing device still renders; expanded device cards now also show a 🔍 Spot it! and ✏️ Try it! box for 10 of them; Voice & Feeling now lists 5 devices including Idiom 🐱; AI "Try it" example generation still works including for Idiom.
5. Home: story blueprint still works; Settings panel has a new "Storybook Worlds" group, Characters has "Storybook Friends", Plot's "More story ideas" reveals 12 new chips; selecting them and starting a story still navigates to /write correctly.
6. Write page and My Library behave exactly as before (untouched).

**Required output:** Screenshot or explicit confirmation of each numbered item. "Looks correct" is not acceptable — confirm each item individually.

**Dependencies:** T002

## Summary checklist

- [ ] T001 — Files applied verbatim (480 concepts verified, idiom present)
- [ ] T002 — Typecheck + build clean, workflows restarted in order
- [ ] T003 — All 6 smoke-test items individually confirmed

## Hard rules

1. Copy files verbatim. Any task is FAILED if coach-content.ts has fewer than 480 concepts.
2. Do not touch Write.tsx, Stories.tsx, SentenceLab.tsx, the OpenAPI spec, or the DB schema — this update doesn't need them.
3. Do not run codegen — the API contract is unchanged.
4. Do not mark a task complete without pasting the actual command output.

## Order

T001 → T002 → T003. Restart the API server before the frontend.

## Final gap closure verification

```bash
node -e "
const ts=require('typescript'),fs=require('fs');
function load(f){const js=ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:1}}).outputText;const m={exports:{}};new Function('exports','require','module',js)(m.exports,require,m);return m.exports;}
const c=load('artifacts/story-studio/src/data/coach-content.ts');
const t=load('artifacts/story-studio/src/data/writing-toolbox.ts');
const e=load('artifacts/story-studio/src/data/device-extras.ts');
const n=c.COACH_BOOKS.reduce((a,b)=>a+b.chapters.reduce((x,ch)=>x+ch.concepts.length,0),0);
const ok=c.COACH_BOOKS.length===4&&n===480&&t.STORY_FRAMES.length===4&&Object.keys(e.DEVICE_EXTRAS).length===10;
console.log(ok?'GAP CLOSURE VERIFIED':'GAPS REMAIN');
" && pnpm run build >/dev/null 2>&1 && echo "BUILD OK"
```

**Required output:** `GAP CLOSURE VERIFIED` and `BUILD OK`.
