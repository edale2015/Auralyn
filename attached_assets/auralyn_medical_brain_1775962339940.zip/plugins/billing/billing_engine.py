def generate_cpt():
    return "99284"
