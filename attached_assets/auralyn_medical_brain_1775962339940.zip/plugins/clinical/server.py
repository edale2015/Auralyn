from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class DiagnosisRequest(BaseModel):
    symptoms: list[str]

@app.post("/diagnosis")
def diagnose(req: DiagnosisRequest):
    return {"top": "viral_uri", "confidence": 0.82}
