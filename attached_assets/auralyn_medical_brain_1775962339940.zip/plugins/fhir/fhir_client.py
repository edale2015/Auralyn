def get_patient(patient_id, token):
    return {"id": patient_id, "name": "Test Patient"}
