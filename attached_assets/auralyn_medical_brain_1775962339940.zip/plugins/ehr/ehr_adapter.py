def push_note_to_ehr(note):
    return {"status": "sent"}
