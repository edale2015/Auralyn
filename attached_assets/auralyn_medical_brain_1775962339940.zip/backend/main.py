from fastapi import FastAPI
app = FastAPI(title="Auralyn Medical Brain")

@app.get("/health")
def health():
    return {"status": "ok"}
