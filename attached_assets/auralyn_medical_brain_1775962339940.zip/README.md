# Auralyn Medical Brain
Run backend and control tower